# Source and terminology provenance

The final manuscript exposure/outcome labels were explicitly confirmed by the author. Archived computational variable names are preserved so users can inspect what the code actually computes. The stored NHANES protein-output model hierarchy supplies only the verified covariate sets adopted by the author. A final-labelled fat regression rerun is not claimed. Model-specific samples must not be replaced by the baseline/XGBoost sample count.

Machine-specific roots were relocated, not individual variables or statistical values. Raw third-party datasets and vendor source code are not redistributed. The Python syntax checks do not establish numerical reproducibility.
