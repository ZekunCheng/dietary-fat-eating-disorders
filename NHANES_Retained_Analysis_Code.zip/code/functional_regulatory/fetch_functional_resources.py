import pathlib,sys,json,concurrent.futures,gzip,hashlib
sys.path.insert(0,r'./project/Workspaces\dietary_fat_AN_MR\runtime\python-deps')
import requests
root=pathlib.Path(r'./project/Workspaces\AN_functional_regulatory_20261013');raw=root/'raw';raw.mkdir(parents=True,exist_ok=True)
urls={
 'enrichr_libraries.json':'https://maayanlab.cloud/Enrichr/datasetStatistics',
 'encori_API.html':'https://rnasysu.com/encori/tutorialAPI.php',
 'BRETIGEA_brainCells.R':'https://raw.githubusercontent.com/andymckenzie/BRETIGEA/master/R/brainCells.R',
 'BRETIGEA_findCells.R':'https://raw.githubusercontent.com/andymckenzie/BRETIGEA/master/R/findCells.R',
 'BRETIGEA_DESCRIPTION':'https://raw.githubusercontent.com/andymckenzie/BRETIGEA/master/DESCRIPTION',
 'markers_df_human_brain.rda':'https://raw.githubusercontent.com/andymckenzie/BRETIGEA/master/data/markers_df_human_brain.rda',
 'markers_df_mouse_brain.rda':'https://raw.githubusercontent.com/andymckenzie/BRETIGEA/master/data/markers_df_mouse_brain.rda',
 'bioc_packages.gz':'https://bioconductor.org/packages/3.20/bioc/bin/windows/contrib/4.4/PACKAGES.gz',
 'kegg_hsa_names.txt':'https://rest.kegg.jp/list/pathway/hsa',
 'kegg_hsa_links.txt':'https://rest.kegg.jp/link/pathway/hsa',
}
def fetch(item):
 name,url=item;f=raw/name
 try:
  if f.exists():return {'file':name,'url':url,'cached':True,'bytes':f.stat().st_size}
  r=requests.get(url,timeout=50);r.raise_for_status();f.write_bytes(r.content)
  return {'file':name,'url':url,'bytes':len(r.content),'sha256':hashlib.sha256(r.content).hexdigest()}
 except Exception as e:return {'file':name,'url':url,'error':str(e)}
results=list(concurrent.futures.ThreadPoolExecutor(5).map(fetch,urls.items()))
(root/'resource_download_log.json').write_text(json.dumps(results,indent=2),encoding='utf8')
print(json.dumps(results,indent=2))
if (raw/'enrichr_libraries.json').exists():
 print('GO libraries',[x['libraryName'] for x in json.loads((raw/'enrichr_libraries.json').read_text())['statistics'] if 'GO_' in x['libraryName'] and '2025' in x['libraryName']])
if (raw/'bioc_packages.gz').exists():
 s=gzip.decompress((raw/'bioc_packages.gz').read_bytes()).decode();print('FGSEA',next((b for b in s.split('\n\n') if b.startswith('Package: fgsea\n')),'not found'))
