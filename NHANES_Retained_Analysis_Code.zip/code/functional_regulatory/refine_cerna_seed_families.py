import pathlib,pandas as pd,numpy as np,json,re
from scipy.stats import hypergeom
root=pathlib.Path(r'./project/Workspaces\AN_functional_regulatory_20261013');out=root/'results';raw=root/'raw'
l=pd.read_csv(raw/'ENCORI_lncRNA_all.tsv',sep='\t',comment='#',dtype=str)
l['miRNA_sequence']=l.miRseq.str.upper().str.replace('[^ACGU]','',regex=True);l['seed_2_to_8']=l.miRNA_sequence.str[1:8]
seed_counts=l.groupby('miRNAname').seed_2_to_8.nunique();assert seed_counts.max()==1
seed_table=l[['miRNAname','seed_2_to_8']].drop_duplicates();seed_table.to_csv(out/'ceRNA_miRNA_seed_family_audit.csv',index=False);seeds=dict(zip(seed_table.miRNAname,seed_table.seed_2_to_8))
m=pd.read_csv(out/'ENCORI_candidate_mRNA_site_evidence.csv');ll=pd.read_csv(out/'ENCORI_brain_expressed_lncRNA_site_evidence.csv')
ms={g:{seeds[v] for v in x.miRNAname if v in seeds} for g,x in m.groupby('geneID')};ls={g:{seeds[v] for v in x.miRNAname if v in seeds} for g,x in ll.groupby('geneID')}
M=len(set(seeds.values()));p=pd.read_csv(out/'ceRNA_all_shared_target_pair_tests.csv');rows=[]
for x in p.itertuples():
 a=ms[x.mRNA_id];b=ls[x.lncRNA_id];common=a&b;k=len(common)
 rows.append(dict(shared_seed_family_count=k,shared_seed_families=';'.join(sorted(common)),mRNA_seed_family_n=len(a),lncRNA_seed_family_n=len(b),seed_family_background_n=M,shared_seed_family_P=hypergeom.sf(k-1,M,len(a),len(b)) if k else 1))
p=pd.concat([p,pd.DataFrame(rows)],axis=1);v=p.shared_seed_family_P.to_numpy();order=np.argsort(v);q=np.minimum.accumulate((v[order]*len(v)/np.arange(1,len(v)+1))[::-1])[::-1];p['shared_seed_family_FDR']=np.empty(len(v));p.loc[order,'shared_seed_family_FDR']=np.minimum(q,1)
p.to_csv(out/'ceRNA_all_shared_target_pair_tests.csv',index=False)
stage=p[(p.shared_miRNA_count>=2)&(p.shared_seed_family_count>=2)&(p.shared_target_FDR<.05)&(p.shared_seed_family_FDR<.05)]
stage.to_csv(out/'ceRNA_shared_target_supported_pairs.csv',index=False)
audit=json.loads((out/'ceRNA_stage1_audit.json').read_text());audit.update(seed_sequence_source='ENCORI reported mature miRNA alignment sequence; gaps removed; positions 2-8; unique seed verified for each miRNA',miRBase_download_unavailable=True,shared_seed_family_min=2,seed_family_background_n=M,seed_family_multiple_test_family=len(p),supported_shared_pairs_after_seed_control=len(stage))
(out/'ceRNA_stage1_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
print('Seed families',M,'pairs after seed control',len(stage))
