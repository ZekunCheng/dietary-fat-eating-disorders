import pathlib,pandas as pd,json,hashlib,zipfile,shutil
root=pathlib.Path(r'./project/Workspaces\AN_functional_regulatory_20261013');out=pathlib.Path(r'./project/outputs\AN_functional_regulatory_20261013')
report='''# GO/KEGG、GSEA、预测性 ceRNA 与脑细胞组成分析

四个模块均已完成；原始输入、参考数据库快照、完整统计结果、绘图 CSV 与 R 代码均已保留。目录沿用本轮分析启动时的 20261013 命名。没有生成图片。

## 1. GO/KEGG 候选集富集

主候选集为 67 个跨物种可检验基因，补充为 84 个完整 AN 差异表达/TWAS 并集基因；没有按高脂饮食的 P 值进一步筛掉基因。背景遵循与候选相同的可检验条件：人体表达或完整 TWAS 模型可检验；67 集合背景还需高置信度一对一人鼠同源映射且在小鼠饮食主分析中可检验。每个注释库进一步限制到有注释的候选和背景。

GO 使用 Enrichr 的 GO Biological Process、Cellular Component、Molecular Function 2025 公共基因集；KEGG 使用官方 REST 人类通路成员和名称，结合 Ensembl BioMart 的 Entrez/基因符号注释。采用右尾超几何检验；仅检验背景内 10–500 个基因的条目，零重叠条目保留 P=1。主 FDR 在每个候选集内合并四个库的所有受检条目计算；同时保留库内 BH FDR。

主校正下，67 与 84 集合均无显著条目。67 集合的探索性库内结果包括：

| 条目 | 候选基因 | P | 库内 q | 四库合并 q |
|---|---|---:|---:|---:|
| Hormone activity | CRH、PNOC、SST、VGF | 7.29×10⁻⁵ | 0.0425 | 0.3105 |
| Vesicle | ARC、ATP1A4、CLIC1、MYO5A、RHOA、SYT12 | 1.52×10⁻⁴ | 0.0436 | 0.3249 |
| Neuroactive ligand–receptor interaction | CRH、PNOC、SST、TAC1、THRB、VGF | 5.28×10⁻⁴ | 0.0997 | 0.4934 |

不能混用不同家族的 q 值，也不能将这些条目表述为通过主校正的富集。候选集由 DE 或 TWAS 入选，存在表达和预测模型覆盖的选择偏倚；富集是功能描述，不是候选因果基因的验证。

## 2. 全量排序 GSEA

输入分别为人体 DLPFC 21,449 个符号、人体尾状核 23,109 个符号，以及小鼠 PFC 13,848 个高置信度一对一人类同源符号。上述是全部受检且可映射的基因，未按差异 P/FDR 筛选；没有用 67 个候选的内部排序替代全量排序。排名使用 limma moderated t；重复符号以 t 的中位数合并。

为统一跨物种注释，小鼠仅使用能映射到人类的高置信度一对一同源基因，占原小鼠受检 24,919 基因的一部分。这限制了可检验通路范围，不能称为未经过同源筛选的全小鼠转录组。

fgsea 1.32.4 多层算法，minSize=15、maxSize=500、nPermSimple=1000；随机种子记录在代码。初始达到 P 下限 10⁻⁶ 的 180 个条目用 eps=0 重新精化，不把截断值当作精确 P。BH 校正同时提供库内、数据集内全部通路、以及三数据集全部 10,212 项通路检验的统一家族结果。三个范围的显著条目数可以不同，不应认为统一校正必定是数据集内校正的严格子集。

统一家族 FDR <0.05：DLPFC 135 项、尾状核 784 项、小鼠 HFD PFC 152 项。GO 存在冗余条目、KEGG 存在共享成员，数量不等于独立机制数量。

| 通路 | 人体 DLPFC NES / q | 人体尾状核 NES / q | 小鼠 HFD PFC NES / q |
|---|---|---|---|
| Oxidative phosphorylation | −2.126 / 1.97×10⁻⁶ | −1.968 / 2.48×10⁻⁴ | −2.485 / 1.43×10⁻¹¹ |
| Ribosome | −1.667 / 0.00462 | +2.129 / 9.43×10⁻⁷ | −2.258 / 1.02×10⁻⁸ |
| GABAergic synapse | −1.258 / 0.369 | −2.416 / 2.62×10⁻⁷ | −1.472 / 0.0997 |

q 均为三数据集全部通路的统一校正。负 NES 对应 AN 相对对照、或 HFD 相对 chow 的较低表达排序富集。

氧化磷酸化在 AN 两个脑区和急性高脂饮食中同向向下，不支持饮食逆转该 AN 分子特征。Ribosome 在 AN 尾状核与小鼠 PFC 方向不同，但涉及不同脑区，不能直接写成尾状核的饮食验证。

67 候选作为自定义基因集，在独立小鼠全排序中检验：NES = −0.743，P = 0.901，未整体富集。标准通路 GSEA 的信号并不证明这 67 个候选获得了独立饮食验证。

## 3. 预测性 ceRNA 网络

GSE262138 原始基因计数确实包含可检测的 lncRNA，故不是完全依赖算法虚构 lncRNA 节点。使用 Ensembl gene_biotype 注释，并限定在人体任一脑区通过原表达过滤的 lncRNA。67 个候选均为蛋白编码基因，其中 46 个有符合筛选标准的 ENCORI mRNA 靶向记录；967 条已检测 lncRNA 有相应 ENCORI 靶向记录。

mRNA 边要求 AGO CLIP 支持至少 1 个实验、至少 2 个预测程序。lncRNA API 没有预测程序数字段，因此没有宣称它通过两程序过滤；要求 AGO CLIP ≥1 与 7mer-m8/8mer seed 匹配。所有 ENCORI 证据来源的 cellline/tissue 字段保留，很多来自非脑细胞系，不能当成 AN 脑组织中的靶向验证。

共享 miRNA 容易被同 seed 家族重复计数。MiRBase 官方下载在本环境失败，因此 seed 使用 ENCORI 自己报告的成熟 miRNA 比对序列：去除比对缺口，提取位置 2–8，并验证每个 miRNA 的 seed 一致性。共得到 565 个 seed 组。筛选要求共享至少 2 个 miRNA、至少 2 个不同 seed 家族；miRNA 共享和 seed 共享超几何检验均在全部 44,482 个配对内 BH q<0.05。保留 1,037 个序列证据配对用于表达支持检验。

表达支持分别在两脑区分析。先对 log2(TMM CPM+1) 表达取秩，再调整诊断、年龄、性别、种族、RIN、intronic/rRNA read fractions，以及六个 BRETIGEA SPV。使用残差相关；n=107、设计矩阵秩=16、检验 df=90。1,037 个候选中 DLPFC 980 对、尾状核 1,033 对可检验；2,013 个有效配对×脑区检验统一 BH。保留 rho≥0.30、q<0.05 的配对，另提供未加入细胞指标的相关系数供敏感性比较。

| 网络 | 支持配对 | mRNA 节点 | lncRNA 节点 | 预测 miRNA 节点 |
|---|---:|---:|---:|---:|
| DLPFC | 21 | 12 | 17 | 188 |
| Caudate | 17 | 13 | 15 | 189 |

两个网络合计 38 个脑区配对记录、20 个不同 mRNA。Triplet 表有 761 条记录，节点表 434 条、去重的靶向边表 1,241 条；脑区之间相同节点/边是分别记录，不可累计为独立验证。相同配对跨脑区出现来自同一批供者，不是独立供者复制。

较强的共表达配对例如尾状核 MYO5A–LINC01128（rho=0.666，q=8.78×10⁻¹⁰）、DLPFC SYNCRIP–OIP5-AS1（rho=0.611，q=9.72×10⁻⁸）。这些是计算与表达一致性证据，不能证明 RNA 竞争、miRNA 抑制方向或 AN 因果机制。没有匹配的 miRNA 表达、亚细胞定位或 RNA 丰度比例数据，网络必须称为 putative/predicted ceRNA network。未将 ANGPT2 强行加入候选集。

## 4. 脑细胞组成估计替代 LM22 免疫解卷积

使用 BRETIGEA 官方 human-only marker table 与官方 findCells 函数缓存，估计 astrocytes、endothelial、microglia、neurons、oligodendrocytes、OPCs 六类 SPV。它是脑组织相对细胞组成代理指标，不是分数和为 1 的绝对比例，不能用作饼图、100% 堆积图或免疫浸润百分比。

每个脑区使用完整通过表达过滤的 TMM log2(CPM+1) 表达；重复符号取均值。不使用 67 基因子矩阵进行解卷积。为避免候选基因与细胞指标的直接自相关，标记池排除全部 84 候选符号。每类选前 50 个实际可检测标记，SVD、按基因中心化；符号按与标记平均相关的方向统一。100 标记版本作敏感性分析。

AN 与对照比较按脑区单独进行：每区 22 AN、85 对照；输出每区 SPV 标准化后的 SD 单位差异。线性模型调整年龄、性别、种族、RIN、intronic/rRNA read fractions；不将 Neuronal 当作这些细胞指标的调整项。12 个细胞类型×脑区比较统一 BH。

前额叶 microglia、oligodendrocytes、OPCs 的指标较低，P 分别为 0.0141、0.0191、0.0149，三者统一 q 均为 0.0766。主分析与 100 标记敏感性分析均无 12 项校正后显著结果。因此不能写成已经证明胶质细胞减少，更不能继续采用原来的 NK 细胞攻击或免疫浸润机制描述。

50 与 100 标记指标的 Spearman 相关为 0.812–0.999。与作者补充表已有组成估计的相关为 0.565–0.972，OPC 没有作者对应指标。该比较使用同一批 bulk 数据，属于方法间一致性，不能当成独立真实细胞计数验证。

另提供 67 候选与各 SPV 的协变量调整 rank-residual 相关，共 798 个可检验基因×细胞×脑区记录；使用 df=96、全家族 BH。379 项达到 q<0.05，但这只能表示与细胞型标记变化相关，不能证明细胞型特异表达或基因由该细胞直接调控。

## 文件与作图

结果目录：./project/outputs/AN_functional_regulatory_20261013
工作目录与原始缓存：./project/Workspaces/AN_functional_regulatory_20261013

- GO_KEGG_ORA_all_results.csv、GO_KEGG_background_audit.csv：两个候选集完整富集与背景记录。
- GSEA_all_datasets.csv、GSEA_key_pathways.csv：完整 GSEA 与关键通路。
- GSEA_oxidative_phosphorylation_curve_data.csv：三数据集全排序的运行富集曲线，直接读取即可绘图。
- GSEA_candidate67_independent_mouse_test.csv：候选自定义集合检验。
- ceRNA_network_nodes.csv、ceRNA_network_edges.csv：可直接导入 Cytoscape；用 brain_region 区分两个网络。
- ceRNA_network_supported_triplets.csv、ceRNA_context_supported_pairs.csv：共享 miRNA、相关、FDR 和节点身份。
- ENCORI_*_site_evidence.csv：每条靶向位点的原始支持字段。
- Brain_cell_scores_plot_data.csv、Brain_cell_composition_group_comparisons.csv：样本指标与调整后的组间比较。
- Brain_cell_marker_audit.csv、Brain_cell_author_estimate_concordance.csv：实际标记与方法一致性。
- Candidate67_brain_cell_score_correlations.csv：候选–SPV 相关。
- plot_functional_results.R：CSV 驱动绘图代码。

```r
source("./project/outputs/AN_functional_regulatory_20261013/plot_functional_results.R")
functional_figures$save(functional_figures$gsea_heatmap(), "GSEA_KEGG_heatmap", height_mm=180)
functional_figures$save(functional_figures$oxidative_curve(), "GSEA_oxidative_phosphorylation", height_mm=85)
functional_figures$save(functional_figures$brain_forest(), "Brain_cell_composition", height_mm=95)
functional_figures$save(functional_figures$network(gene="MYO5A",label_miRNA=TRUE), "ceRNA_MYO5A_PFC")
```

默认无图标题；Source 只加载函数，save 才导出 SVG/PDF/TIFF。完整网络节点较多，默认不标注 miRNA 名称，所有节点仍显示；gene 参数可绘制一个指定基因的完整支持模块，不改变底层网络结果。Cytoscape 可查看全部节点标签。ORA 绘图默认展示各库最小 P 的前 8 条，明确用主 FDR q 着色，不宣称均显著。GSEA 热图显示各数据集最小 P 的前 8 个 KEGG 条目的并集，仅作为显示选择；完整结果 CSV 保留全部通路。灰色格表示不可检验/缺失，不设为零。

## 复现与验证

code/ 保存下载、ORA、GSEA、P 精化、脑组成、ceRNA 靶向/seed 筛选、表达支持与汇总脚本。运行输入路径指向现有 D 盘项目；无需重新计算 MR/TWAS。references/ 保留本次使用的 GMT、基因注释与 BRETIGEA 标记/函数。所有外部数据从公开数据库下载，没有联系作者或发送消息。

独立复核了各家族 BH q、候选背景包含关系、GSEA 曲线与 ES、网络边的双侧靶向位点证据、节点/边去重、样本和统计自由度。R Source/ggplot_build 检查了全部绘图函数；未打开图形设备，因此未进行最终导出后的视觉 QA，不将代码校验称作图像排版已验证。

## 来源

- Enrichr 公共基因集：https://maayanlab.cloud/Enrichr/
- KEGG REST：https://www.kegg.jp/kegg/rest/keggapi.html
- Ensembl BioMart：https://www.ensembl.org/biomart/martservice
- fgsea：https://bioconductor.org/packages/fgsea/
- ENCORI API：https://rnasysu.com/encori/tutorialAPI.php
- BRETIGEA 官方代码：https://github.com/andymckenzie/BRETIGEA
- BRETIGEA 原研究：https://pmc.ncbi.nlm.nih.gov/articles/PMC5995803/
'''
(out/'Analysis_report_CN.md').write_text(report,encoding='utf8')
methods='''Functional enrichment was assessed for the 67 cross-species-testable candidate genes, with the full 84-gene AN DE/TWAS union analysed as a supplementary set. Gene universes reflected expression/model eligibility and, for the 67-gene set, one-to-one orthology and eligibility in the mouse diet analysis. GO annotations were obtained from the Enrichr 2025 libraries and KEGG memberships from the official REST service. Right-tailed hypergeometric tests included terms containing 10–500 eligible background genes. Benjamini–Hochberg correction was applied across all tested GO/KEGG terms within each candidate set; library-specific corrections were additionally reported.

GSEA used complete available moderated-t rankings for human DLPFC, caudate and mouse PFC. Mouse genes were mapped to high-confidence one-to-one human orthologues for annotation consistency. Duplicate gene symbols were represented by the median t statistic. Analyses used fgseaMultilevel (minSize=15, maxSize=500); strong signals reaching the initial numerical P-value floor were refined with eps=0. Corrections were reported within annotation libraries, within datasets and across all three datasets. The 67-candidate set was separately tested in the independent mouse ranking.

A putative ceRNA network was constructed using ENCORI miRNA-target records and lncRNAs detectable in GSE262138. mRNA interactions required AGO CLIP support and predictions from at least two programs; lncRNA interactions required AGO CLIP support and a qualifying seed match. Shared-target screening required at least two shared miRNAs and two distinct seed groups, with adjusted hypergeometric support. Covariate-adjusted rank correlations were then assessed separately by brain region, accounting for diagnosis, age, sex, race, RIN, read fractions and six brain cell-type surrogate variables. Pairs with rho≥0.30 and FDR<0.05 were retained. Matched miRNA expression was unavailable, so retained triplets were treated as predictions with expression-context support, not validated RNA competition.

Brain cellular composition was estimated using human BRETIGEA markers and its official findCells SVD procedure applied to full normalized expression profiles. Candidate genes were excluded from marker panels to reduce direct self-correlation. Fifty detectable markers per cell type were used, with 100-marker estimates as a sensitivity analysis. Surrogate proportion variables were standardized within region and compared between 22 AN cases and 85 controls using covariate-adjusted linear models. FDR was controlled across the 12 cell-type-by-region comparisons. These outputs were interpreted as relative surrogate indices rather than absolute cell percentages.
'''
results='''No candidate-set GO/KEGG term survived the combined annotation-family correction. GSEA identified lower-ranked oxidative phosphorylation expression in AN DLPFC (NES=−2.126, q=1.97×10⁻⁶), AN caudate (NES=−1.968, q=2.48×10⁻⁴) and mouse PFC after acute high-fat feeding (NES=−2.485, q=1.43×10⁻¹¹). These concordant changes did not support reversal of the AN-associated pathway pattern by high-fat feeding. The 67-candidate set was not enriched in the independent mouse ranking (NES=−0.743, P=0.901).

The putative ceRNA analysis retained 21 expression-context-supported lncRNA–mRNA pairs in DLPFC and 17 in caudate, involving 20 distinct candidate mRNAs across regions. Shared miRNA-target predictions and adjusted coexpression supported these candidate relationships, but did not establish competition or AN-specific miRNA binding.

BRETIGEA yielded nominally lower microglial, oligodendrocyte and OPC surrogate scores in AN DLPFC; none survived correction across 12 cell-type-by-region comparisons (all three q=0.0766). The 100-marker sensitivity analysis likewise identified no corrected group differences. These results did not establish changes in absolute brain cell abundance.
'''
(out/'Methods_Results_EN_draft.txt').write_text(methods+'\nResults\n\n'+results,encoding='utf8')
readme='核心结果与每个文件的说明见 Analysis_report_CN.md。\n绘图读取 plot_functional_results.R；只 source 不导出，需调用 functional_figures$save()。\nceRNA 的节点与边可直接导入 Cytoscape。\n统计与数据完整性已核验，未生成图片。\n'
(out/'README.txt').write_text(readme,encoding='utf8')
shutil.copy2(pathlib.Path(__file__).parent/'check_functional_plots.R',out/'code/check_functional_plots.R');shutil.copy2(pathlib.Path(__file__),out/'code/write_functional_report.py')
manifest=[]
for f in (root/'raw').rglob('*'):
 if f.is_file():manifest.append(dict(file=str(f),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
for f in [pathlib.Path(r'./project/outputs\AN_TWAS_HFD_union_20261013\Union_candidates_all_evidence.csv'),pathlib.Path(r'./project/outputs\AN_brain_localization_20261013\AN_TWAS_complete_models.csv')]:manifest.append(dict(file=str(f),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
(out/'input_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
qa={'R_Source_and_ggplot_build':'PASS for all plot functions','source_preflight':'0 FAIL; R syntax confirmed by Source','plotting_backend':'R only','all_network_nodes_retained':True,'graphics_devices_opened':False,'images_generated':False,'visual_render_QA':'not performed per user preference'}
(out/'Plot_QA.json').write_text(json.dumps(qa,indent=2),encoding='utf8')
with zipfile.ZipFile(str(out)+'.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for f in out.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(out))
with zipfile.ZipFile(str(out)+'.zip') as z:assert z.testzip() is None
print('COMPLETE',str(out)+'.zip','bytes',pathlib.Path(str(out)+'.zip').stat().st_size)
