.libPaths(unique(c('./project/R/win-library/4.4',.libPaths())))
library(ggplot2)
library(patchwork)
root <- './project/outputs/AN_functional_regulatory_20261013'
out <- file.path(root,'ceRNA_figures')
dir.create(out,recursive=TRUE,showWarnings=FALSE)
pairs <- read.csv(file.path(root,'ceRNA_context_supported_pairs.csv'),check.names=FALSE)
nodes <- read.csv(file.path(root,'ceRNA_network_nodes.csv'),check.names=FALSE)
edges <- read.csv(file.path(root,'ceRNA_network_edges.csv'),check.names=FALSE)
triplets <- read.csv(file.path(root,'ceRNA_network_supported_triplets.csv'),check.names=FALSE)
original_lncRNA_names <- pairs$lncRNA_name
for(i in seq_len(nrow(pairs))) {
 nr <- nodes[nodes$brain_region==pairs$brain_region[i],]
 pairs$lncRNA_name[i] <- nr$label[match(paste0('lncRNA:',pairs$lncRNA_id[i]),nr$node_id)]
 pairs$mRNA_name[i] <- nr$label[match(paste0('mRNA:',pairs$mRNA_id[i]),nr$node_id)]
}
stopifnot(!anyNA(pairs$lncRNA_name),!anyNA(pairs$mRNA_name))
regions <- c('DLPFC','Caudate')
palette <- c(lncRNA='#8F82B1',miRNA='#DBAE55',mRNA='#438E93')
th <- theme_void(base_size=8,base_family='Arial')+
 theme(plot.title=element_text(size=9,face='bold',hjust=.5,margin=margin(b=4)),
       plot.subtitle=element_text(size=7,colour='#666666',hjust=.5,margin=margin(b=4)),
       legend.position='bottom',legend.title=element_text(size=7),legend.text=element_text(size=6.5),
       plot.margin=margin(8,6,4,6))
save_fig <- function(p,name,w,h) {
 svglite::svglite(file.path(out,paste0(name,'.svg')),width=w/25.4,height=h/25.4); print(p);dev.off()
 grDevices::cairo_pdf(file.path(out,paste0(name,'.pdf')),width=w/25.4,height=h/25.4,family='Arial');print(p);dev.off()
 ggsave(file.path(out,paste0(name,'.png')),p,device=ragg::agg_png,width=w,height=h,units='mm',dpi=300,bg='white')
 ggsave(file.path(out,paste0(name,'.tiff')),p,device=ragg::agg_tiff,width=w,height=h,units='mm',dpi=600,compression='lzw',bg='white')
}
# Deterministic barycentric ordering reduces crossings without excluding edges.
pair_layout <- function(p) {
 left <- sort(unique(p$lncRNA_name));right <- sort(unique(p$mRNA_name))
 for(k in 1:8) {
  score <- vapply(left,function(x)mean(match(p$mRNA_name[p$lncRNA_name==x],right)),numeric(1))
  left <- left[order(score,left)]
  score <- vapply(right,function(x)mean(match(p$lncRNA_name[p$mRNA_name==x],left)),numeric(1))
  right <- right[order(score,right)]
 }
 yl <- setNames(seq(.94,.06,length.out=length(left)),left)
 yr <- setNames(seq(.94,.06,length.out=length(right)),right)
 list(left=left,right=right,yl=yl,yr=yr)
}
layout_tables <- list(); summary_plots <- list(); full_plots <- list()
for(region in regions) {
 pp <- pairs[pairs$brain_region==region,]
 nn <- nodes[nodes$brain_region==region,]
 ee <- edges[edges$brain_region==region,]
 stopifnot(!anyDuplicated(nn$node_id),all(ee$source %in% nn$node_id),all(ee$target %in% nn$node_id))
 L <- pair_layout(pp)
 pp$y <- unname(L$yl[pp$lncRNA_name]); pp$yend <- unname(L$yr[pp$mRNA_name])
 lines <- do.call(rbind,lapply(seq_len(nrow(pp)),function(i) {
  t <- seq(0,1,length.out=61)
  data.frame(pair=i,x=3*t^2-2*t^3,y=(1-t)*pp$y[i]+t*pp$yend[i],
             shared_miRNA_count=pp$shared_miRNA_count[i],rho_adjusted=pp$rho_adjusted[i])
 }))
 ln <- data.frame(label=L$left,x=0,y=unname(L$yl),node_type='lncRNA')
 mr <- data.frame(label=L$right,x=1,y=unname(L$yr),node_type='mRNA')
 np <- rbind(ln,mr)
 summary_plots[[region]] <- ggplot()+
  geom_path(data=lines,aes(x,y,group=pair,linewidth=shared_miRNA_count,colour=rho_adjusted),alpha=.7,lineend='round')+
  geom_point(data=np,aes(x,y,fill=node_type,shape=node_type),size=2.9,stroke=.55,colour='white')+
  geom_text(data=ln,aes(x=-.045,y=y,label=label),hjust=1,size=2.45,family='Arial',colour='#3D3946')+
  geom_text(data=mr,aes(x=1.045,y=y,label=label),hjust=0,size=2.45,family='Arial',colour='#254F52')+
  annotate('text',x=c(0,1),y=1.015,label=c('lncRNA','mRNA'),size=2.9,fontface='bold',family='Arial')+
  scale_fill_manual(values=palette,guide='none')+scale_shape_manual(values=c(lncRNA=21,mRNA=22),guide='none')+
  scale_linewidth_continuous(name='Shared miRNAs',range=c(.35,1.65),limits=range(pairs$shared_miRNA_count),breaks=c(10,30,60))+
  scale_colour_gradient(name='Adjusted correlation',low='#C2D7DF',high='#305C80',limits=c(.30,.68),breaks=c(.3,.5,.65))+
  guides(linewidth=guide_legend(order=1),colour=guide_colourbar(order=2,barwidth=grid::unit(24,'mm'),barheight=grid::unit(2.5,'mm')))+
  coord_cartesian(xlim=c(-.62,1.53),ylim=c(.015,1.045),expand=FALSE)+
  labs(title=region,subtitle=sprintf('%d supported pairs | %d lncRNAs | %d mRNAs',nrow(pp),nrow(ln),nrow(mr)))+th
 # Full three-layer network: all miRNAs are shown, labels retained in node table.
 nn$x <- NA_real_;nn$y <- NA_real_
 il <- nn$node_type=='lncRNA';im <- nn$node_type=='mRNA';iu <- nn$node_type=='miRNA'
 nn$x[il] <- 0;nn$y[il] <- unname(L$yl[nn$label[il]])
 nn$x[im] <- 1;nn$y[im] <- unname(L$yr[nn$label[im]])
 mir <- nn$node_id[iu]
 target_y <- setNames(nn$y,nn$node_id)
 scores <- vapply(mir,function(id)mean(target_y[ee$target[ee$source==id]],na.rm=TRUE),numeric(1))
 mir <- mir[order(-scores,mir)]
 ncol_grid <- 9L;nrow_grid <- ceiling(length(mir)/ncol_grid)
 j <- seq_along(mir)-1L
 gx <- .32+(j%%ncol_grid)/max(1,ncol_grid-1)*.36
 gy <- .94-floor(j/ncol_grid)/max(1,nrow_grid-1)*.88
 nn$x[match(mir,nn$node_id)] <- gx;nn$y[match(mir,nn$node_id)] <- gy
 stopifnot(!anyNA(nn$x),!anyNA(nn$y))
 ee$x <- nn$x[match(ee$source,nn$node_id)];ee$y <- nn$y[match(ee$source,nn$node_id)]
 ee$xend <- nn$x[match(ee$target,nn$node_id)];ee$yend <- nn$y[match(ee$target,nn$node_id)]
 full_plots[[region]] <- ggplot()+
  geom_segment(data=ee,aes(x,y,xend=xend,yend=yend),colour='#8A9AA7',alpha=.14,linewidth=.18)+
  geom_point(data=nn[nn$node_type=='miRNA',],aes(x,y,fill=node_type),shape=21,size=1.05,stroke=.15,colour='white')+
  geom_point(data=nn[nn$node_type!='miRNA',],aes(x,y,fill=node_type,shape=node_type),size=2.9,stroke=.55,colour='white')+
  geom_text(data=nn[il,],aes(x=-.045,y=y,label=label),hjust=1,size=2.4,family='Arial',colour='#3D3946')+
  geom_text(data=nn[im,],aes(x=1.045,y=y,label=label),hjust=0,size=2.4,family='Arial',colour='#254F52')+
  annotate('text',x=c(0,.5,1),y=1.015,label=c('lncRNA','miRNA','mRNA'),size=2.9,fontface='bold',family='Arial')+
  scale_fill_manual(values=palette,guide='none')+scale_shape_manual(values=c(lncRNA=21,mRNA=22),guide='none')+
  coord_cartesian(xlim=c(-.62,1.53),ylim=c(.015,1.045),expand=FALSE)+
  labs(title=region,subtitle=sprintf('%d nodes | %d target edges',nrow(nn),nrow(ee)))+th
 layout_tables[[region]] <- nn
}
main <- wrap_plots(summary_plots,nrow=1,guides='collect') & theme(legend.position='bottom')
full <- wrap_plots(full_plots,nrow=1)
save_fig(main,'ceRNA_supported_pair_overview',220,140)
save_fig(full,'ceRNA_complete_tripartite_networks',220,135)
# SNX27 is selected because it has prior colocalization support, rather than by network degree.
# This module includes every supported SNX27 triplet in both regions.
module_plots <- list(); module_layouts <- list()
for(region in regions) {
 tt <- triplets[triplets$brain_region==region & triplets$mRNA_name=='SNX27',]
 if(!nrow(tt))next
 lnames <- sort(unique(tt$lncRNA_name));mir <- sort(unique(tt$miRNA))
 nn <- data.frame(node_id=c(paste0('lncRNA:',lnames),paste0('miRNA:',mir),'mRNA:SNX27'),
                  label=c(lnames,sub('^hsa-','',mir),'SNX27'),node_type=c(rep('lncRNA',length(lnames)),rep('miRNA',length(mir)),'mRNA'))
 nn$x <- c(rep(0,length(lnames)),rep(.5,length(mir)),1)
 nn$y <- c(seq(.85,.15,length.out=length(lnames)),seq(.96,.04,length.out=length(mir)),.5)
 ee <- unique(rbind(data.frame(source=paste0('lncRNA:',tt$lncRNA_name),target=paste0('miRNA:',tt$miRNA)),
                    data.frame(source=paste0('miRNA:',tt$miRNA),target='mRNA:SNX27')))
 ee$x <- nn$x[match(ee$source,nn$node_id)];ee$y <- nn$y[match(ee$source,nn$node_id)]
 ee$xend <- nn$x[match(ee$target,nn$node_id)];ee$yend <- nn$y[match(ee$target,nn$node_id)]
 # miRNA labels sit adjacent to the middle column, with a light panel background for readability.
 module_plots[[region]] <- ggplot()+
  geom_segment(data=ee,aes(x,y,xend=xend,yend=yend),colour='#A3B4BF',alpha=.55,linewidth=.25)+
  geom_point(data=nn,aes(x,y,fill=node_type,shape=node_type),size=2.8,stroke=.55,colour='white')+
  geom_label(data=nn[nn$node_type=='miRNA',],aes(x=.535,y=y,label=label),hjust=0,size=2.15,
             label.size=0,label.padding=grid::unit(.45,'mm'),fill='white',family='Arial',colour='#565044')+
  geom_text(data=nn[nn$node_type=='lncRNA',],aes(x=-.035,y=y,label=label),hjust=1,size=2.7,family='Arial',colour='#53456C')+
  geom_text(data=nn[nn$node_type=='mRNA',],aes(x=1.035,y=y,label=label),hjust=0,size=3,fontface='bold',family='Arial',colour='#254F52')+
  scale_fill_manual(values=palette,guide='none')+scale_shape_manual(values=c(lncRNA=21,miRNA=21,mRNA=22),guide='none')+
  coord_cartesian(xlim=c(-.47,1.35),ylim=c(0,1),expand=FALSE)+
  labs(title=region,subtitle=sprintf('SNX27 module | %d lncRNAs | %d shared miRNAs',length(lnames),length(mir)))+th
 module_layouts[[region]] <- cbind(brain_region=region,nn)
}
save_fig(wrap_plots(module_plots,nrow=1),'ceRNA_SNX27_complete_modules',220,165)
write.csv(do.call(rbind,layout_tables),file.path(out,'ceRNA_complete_network_layout.csv'),row.names=FALSE)
write.csv(do.call(rbind,module_layouts),file.path(out,'ceRNA_SNX27_module_layout.csv'),row.names=FALSE)
write.csv(data.frame(brain_region=pairs$brain_region,lncRNA_id=pairs$lncRNA_id,
 original_label=original_lncRNA_names,display_label=pairs$lncRNA_name),file.path(out,'ceRNA_gene_label_mapping.csv'),row.names=FALSE)
for(f in c('ceRNA_context_supported_pairs.csv','ceRNA_network_nodes.csv','ceRNA_network_edges.csv','ceRNA_network_supported_triplets.csv'))file.copy(file.path(root,f),out,overwrite=TRUE)
writeLines(c('Putative ceRNA network visualization; R backend; no overall figure titles or panel letters.',
 'Main overview: all 38 brain-region-specific supported lncRNA-mRNA pairs. miRNA nodes are collapsed into pair edges; edge width is the count of shared miRNAs, edge color is adjusted positive expression correlation. Edges do not imply direct lncRNA-mRNA binding.',
 'Complete tripartite networks: all 434 region-specific nodes and 1241 edges retained. Central gold dots show all miRNAs; names are in the layout/source CSV. No filtering based on aesthetics.',
 'SNX27 modules: all supported SNX27 triplets retained for each region. Selected for its prior colocalization support; not for highest network degree or an experimental ceRNA effect.',
 'Node colors: purple lncRNA, gold miRNA, teal mRNA. No arrows: experimental regulatory direction has not been established.',
 'Target evidence: public ENCORI AGO CLIP plus prediction/seed evidence, not necessarily AN brain-specific. miRNAs lack matched expression measurements.',
 'Pair expression support: adjusted rank correlation rho >= 0.30 and BH FDR < 0.05 across 2013 evaluable region-pair tests; n=107 donors, adjusted for diagnosis and available covariates including six brain cell-type SPVs. Shared-target and seed-family tests also pass prior filtering.',
 'Same donors contribute both brain regions; cross-region overlap is not independent replication.',
 'Summary edges count shared miRNAs, not unique seed families; seed-family redundancy was controlled during original pair selection.',
 'Labels matched by Ensembl gene IDs to the canonical network node table; older lncRNA aliases in pair CSV are retained in ceRNA_gene_label_mapping.csv.',
 'Outputs: editable PDF/SVG, PNG 300 dpi, TIFF 600 dpi. Source data and deterministic layouts included.',
 'Interpretation: prediction- and expression-supported candidates; not validated ceRNA competition or causal AN mechanism.'),file.path(out,'README.txt'))
stopifnot(nrow(nodes)==434,nrow(edges)==1241,nrow(pairs)==38,nrow(triplets)==761)
cat('Completed:',out,'\n')
