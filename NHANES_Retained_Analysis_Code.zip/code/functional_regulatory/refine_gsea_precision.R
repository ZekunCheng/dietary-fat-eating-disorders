.libPaths(c('./project/R/win-library/4.4',.libPaths()))
suppressPackageStartupMessages({library(fgsea);library(data.table)})
root<-'./project/Workspaces/AN_functional_regulatory_20261013';raw<-file.path(root,'raw');out<-file.path(root,'results')
gmt<-strsplit(readLines(file.path(raw,'GO_KEGG_human_combined.gmt')),'\t',fixed=TRUE);pathways<-setNames(lapply(gmt,function(x)x[-c(1,2)]),vapply(gmt,'[',character(1),1))
rankfiles<-c(DLPFC='GSEA_rank_DLPFC.csv',Caudate='GSEA_rank_Caudate.csv',Mouse_HFD_PFC='GSEA_rank_mouse_HFD_PFC_human_orthologues.csv')
all<-list()
for(i in seq_along(rankfiles)){
 dataset<-names(rankfiles)[i];x<-fread(file.path(out,paste0('GSEA_',dataset,'_all_results.csv')));idx<-x$pval<=1e-6 | is.na(x$log2err);d<-fread(file.path(raw,rankfiles[i]));stats<-sort(setNames(d$statistic,d$gene),decreasing=TRUE)
 set.seed(202610140+i);rr<-fgseaMultilevel(pathways[x$pathway[idx]],stats,minSize=15,maxSize=500,eps=0,nPermSimple=1000,nproc=1)
 for(k in seq_len(nrow(rr))){j<-match(rr$pathway[k],x$pathway);for(field in c('pval','log2err','ES','NES','size'))x[[field]][j]<-rr[[field]][k];x$leading_edge_genes[j]<-paste(rr$leadingEdge[[k]],collapse=';')}
 x$FDR_all_pathways_in_dataset<-p.adjust(x$pval,'BH')
 for(lib in unique(x$library)){ii<-x$library==lib;x$FDR_within_library[ii]<-p.adjust(x$pval[ii],'BH')}
 x$precision_refined<-idx
 fwrite(x,file.path(out,paste0('GSEA_',dataset,'_all_results.csv')));all[[i]]<-x;cat(dataset,'refined',sum(idx),'pathways\n');flush.console()
}
joined<-rbindlist(all);joined$FDR_all_three_datasets<-p.adjust(joined$pval,'BH');fwrite(joined,file.path(out,'GSEA_all_datasets.csv'));fwrite(joined[FDR_all_three_datasets<.05],file.path(out,'GSEA_FDR_significant_all_datasets.csv'))
audit<-joined[,.(tested_pathways=.N,FDR05_all_pathways=sum(FDR_all_pathways_in_dataset<.05),FDR05_global=sum(FDR_all_three_datasets<.05),precision_refined_n=sum(precision_refined)),by=dataset];fwrite(audit,file.path(out,'GSEA_precision_audit.csv'))
