import pathlib,sys,concurrent.futures,json,gzip
sys.path.insert(0,r'./project/Workspaces\dietary_fat_AN_MR\runtime\python-deps')
import requests
root=pathlib.Path(r'./project/Workspaces\AN_functional_regulatory_20261013');raw=root/'raw'
jobs={}
for name in ['GO_Biological_Process_2025','GO_Cellular_Component_2025','GO_Molecular_Function_2025']:
 jobs[name+'.gmt']='https://maayanlab.cloud/Enrichr/geneSetLibrary?mode=text&libraryName='+name
xml='''<?xml version="1.0" encoding="UTF-8"?><Query virtualSchemaName="default" formatter="TSV" header="1" uniqueRows="1" count="" datasetConfigVersion="0.6"><Dataset name="hsapiens_gene_ensembl" interface="default"><Attribute name="ensembl_gene_id"/><Attribute name="external_gene_name"/><Attribute name="gene_biotype"/><Attribute name="entrezgene_id"/></Dataset></Query>'''
from urllib.parse import urlencode
jobs['human_gene_annotation.tsv']='https://www.ensembl.org/biomart/martservice?'+urlencode({'query':xml})
jobs['fgsea_1.32.4.zip']='https://bioconductor.org/packages/3.20/bioc/bin/windows/contrib/4.4/fgsea_1.32.4.zip'
def run(item):
 n,url=item
 try:
  dest=raw/n
  if dest.exists():return dict(file=n,cached=True,bytes=dest.stat().st_size)
  r=requests.get(url,timeout=60);r.raise_for_status();dest.write_bytes(r.content)
  return dict(file=n,url=url,bytes=len(r.content),preview=r.text[:80] if not n.endswith('.zip') else 'binary package')
 except Exception as e:return dict(file=n,error=str(e),url=url)
res=list(concurrent.futures.ThreadPoolExecutor(5).map(run,jobs.items()));(root/'pathway_download_log.json').write_text(json.dumps(res,indent=2),encoding='utf8');print(json.dumps(res,indent=2))
