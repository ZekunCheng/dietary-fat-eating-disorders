import pathlib,json,re,pandas as pd,numpy as np
from scipy.stats import hypergeom
root=pathlib.Path(r'./project/Workspaces\AN_functional_regulatory_20261013');raw=root/'raw';out=root/'results';out.mkdir(exist_ok=True)
prior=pathlib.Path(r'./project/Workspaces\AN_diet_transcriptome_20261013\results')
def bh(p):
 p=np.asarray(p);order=np.argsort(p);q=np.minimum.accumulate((p[order]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1];v=np.empty(len(p));v[order]=np.minimum(q,1);return v
ann=pd.read_csv(raw/'human_gene_annotation.tsv',sep='\t',dtype=str);ann.columns=['gene_id','symbol','gene_type','entrez']
simple=ann[['gene_id','symbol','gene_type']].drop_duplicates();assert not simple.gene_id.duplicated().any()
symbol=dict(zip(simple.gene_id,simple.symbol));biotype=dict(zip(simple.gene_id,simple.gene_type))
u=pd.read_csv(r'./project/outputs\AN_TWAS_HFD_union_20261013\Union_candidates_all_evidence.csv')
c84=set(u.gene_id);c67=set(u.loc[u.HFD_testable,'gene_id'])
de=pd.read_csv(prior/'AN_DE_all_regions_primary.csv')
tw=pd.read_csv(r'./project/outputs\AN_brain_localization_20261013\AN_TWAS_complete_models.csv')
tw=tw[tw.tissue.isin(['Frontal_Cortex_BA9','Caudate_basal_ganglia'])]
eligible=set(de.gene_id)|set(tw.gene.str.split('.').str[0])
ort=pd.read_csv(r'./project/Workspaces\AN_diet_transcriptome_20261013\raw\human_mouse_ensembl_orthologs.tsv',sep='\t');ort.columns=['gene_id','human_symbol','mouse_id','mouse_symbol','type','confidence'];ort=ort[(ort.type=='ortholog_one2one')&(ort.confidence==1)]
mouse=pd.read_csv(prior/'HFD_vs_chow_PFC_cage_primary.csv');eligible67=eligible & set(ort.loc[ort.mouse_id.isin(mouse.mouse_gene_id),'gene_id'])
sets={}
for filename,lib in [('GO_Biological_Process_2025.gmt','GO_BP'),('GO_Cellular_Component_2025.gmt','GO_CC'),('GO_Molecular_Function_2025.gmt','GO_MF')]:
 for line in (raw/filename).read_text().splitlines():
  fields=line.split('\t');term=fields[0];go=re.search(r'GO:\d+',term).group();sets[lib+'|'+go]={'library':lib,'term_id':go,'term_name':term,'genes':set(x for x in fields[2:] if x)}
entrez2symbol={}
for row in ann.dropna(subset=['symbol','entrez']).itertuples():entrez2symbol.setdefault(row.entrez,set()).add(row.symbol)
names={line.split('\t')[0]:line.split('\t')[1] for line in (raw/'kegg_hsa_names.txt').read_text().splitlines()}
for line in (raw/'kegg_hsa_links.txt').read_text().splitlines():
 gene,path=line.split('\t');path=path.removeprefix('path:');key='KEGG|'+path
 if key not in sets:sets[key]={'library':'KEGG','term_id':path,'term_name':names.get(path,path),'genes':set()}
 sets[key]['genes'].update(entrez2symbol.get(gene.removeprefix('hsa:'),set()))
with (raw/'GO_KEGG_human_combined.gmt').open('w',encoding='utf8') as f:
 for key,value in sets.items():f.write(key+'\t'+value['term_name']+'\t'+'\t'.join(sorted(value['genes']))+'\n')
rows=[];counts=[]
for setname,ids,bgids in [('Union_67_cross_species',c67,eligible67),('Union_84_all_candidates',c84,eligible)]:
 bg=set(symbol[x] for x in bgids if isinstance(symbol.get(x),str));c=set(symbol[x] for x in ids if isinstance(symbol.get(x),str));assert c<=bg
 for lib in ['GO_BP','GO_CC','GO_MF','KEGG']:
  libterms={k:v for k,v in sets.items() if v['library']==lib};annotated=set().union(*(v['genes'] for v in libterms.values()))
  universe=bg&annotated;target=c&universe;M=len(universe);n=len(target)
  counts.append(dict(candidate_set=setname,library=lib,input_gene_ids=len(ids),input_symbols=len(c),background_symbols=len(bg),annotated_candidate_symbols=n,annotated_background_symbols=M))
  for key,val in libterms.items():
   members=val['genes']&universe;K=len(members)
   if K<10 or K>500:continue
   hits=target&members;k=len(hits);p=hypergeom.sf(k-1,M,K,n) if k else 1
   rows.append(dict(candidate_set=setname,library=lib,term_id=val['term_id'],term_name=val['term_name'],overlap=k,candidate_annotated_n=n,pathway_background_n=K,background_n=M,fold_enrichment=(k/n)/(K/M),P=p,genes=';'.join(sorted(hits))))
 frame=pd.DataFrame(rows);mask=frame.candidate_set.eq(setname)
 frame.loc[mask,'FDR_all_GO_KEGG_in_set']=bh(frame.loc[mask,'P'])
 for lib in ['GO_BP','GO_CC','GO_MF','KEGG']:
  m=mask&frame.library.eq(lib);frame.loc[m,'FDR_within_library']=bh(frame.loc[m,'P'])
 rows=frame.to_dict('records')
res=pd.DataFrame(rows).sort_values(['candidate_set','P']);res.to_csv(out/'GO_KEGG_ORA_all_results.csv',index=False);res[res.FDR_all_GO_KEGG_in_set<.05].to_csv(out/'GO_KEGG_ORA_FDR_significant.csv',index=False);pd.DataFrame(counts).to_csv(out/'GO_KEGG_background_audit.csv',index=False)
for reg in ['DLPFC','Caudate']:
 x=de[de.brain_region.eq(reg)].copy();x['symbol']=x.gene_id.map(symbol);x=x.dropna(subset=['symbol']);rank=x.groupby('symbol',sort=True)['t'].median().sort_values(ascending=False)
 rank.rename('statistic').reset_index().rename(columns={'symbol':'gene'}).to_csv(raw/('GSEA_rank_'+reg+'.csv'),index=False)
x=mouse.merge(ort,left_on='mouse_gene_id',right_on='mouse_id',validate='one_to_one');x['symbol']=x.gene_id.map(symbol);x=x.dropna(subset=['symbol']);rank=x.groupby('symbol',sort=True)['t'].median().sort_values(ascending=False);rank.rename('statistic').reset_index().rename(columns={'symbol':'gene'}).to_csv(raw/'GSEA_rank_mouse_HFD_PFC_human_orthologues.csv',index=False)
(raw/'Candidate67_custom_gene_set.gmt').write_text('AN_TWAS_DE_UNION_67\tIndependent_mouse_diet_response\t'+'\t'.join(sorted({symbol[x] for x in c67 if isinstance(symbol.get(x),str)}))+'\n',encoding='utf8')
audit=simple[simple.gene_id.isin(c84)].copy();audit['in_candidate67']=audit.gene_id.isin(c67);audit.to_csv(out/'Candidate_gene_biotype_audit.csv',index=False)
print('ORA significant',res[res.FDR_all_GO_KEGG_in_set<.05].groupby(['candidate_set','library']).size().to_dict());print(res[res.candidate_set.eq('Union_67_cross_species')].head(8)[['library','term_name','overlap','P','FDR_all_GO_KEGG_in_set']].to_string(index=False));print('Ranks mouse',len(rank),'candidate67',len(c67))
