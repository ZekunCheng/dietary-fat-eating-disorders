.libPaths(c('./project/R/win-library/4.4',.libPaths()))
suppressPackageStartupMessages(library(data.table))
root<-'./project/Workspaces/AN_functional_regulatory_20261013';out<-file.path(root,'results');raw<-file.path(root,'raw')
pairs<-fread(file.path(out,'ceRNA_shared_target_supported_pairs.csv'),data.table=FALSE)
scores<-fread(file.path(out,'Brain_cell_surrogate_scores_all_samples.csv'),data.table=FALSE)
all<-list();cell_tests<-list()
for(region in c('DLPFC','Caudate')){
 obj<-readRDS(file.path(raw,paste0('human_',region,'_expression_context.rds')));expr<-obj$expression;m<-obj$metadata
 ss<-scores[scores$brain_region==region,];ss<-ss[match(m$sample_id,ss$sample_id),];stopifnot(identical(ss$sample_id,m$sample_id))
 for(ct in c('ast','end','mic','neu','oli','opc'))m[[ct]]<-as.numeric(scale(ss[[ct]]))
 design<-model.matrix(~group+Age+Sex+Race+RIN+Perc.Intronic+Perc.rRNA+ast+end+mic+neu+oli+opc,m)
 minimal<-model.matrix(~group+Age+Sex+Race+RIN+Perc.Intronic+Perc.rRNA,m)
 genes<-intersect(unique(c(pairs$mRNA_id,pairs$lncRNA_id)),rownames(expr));ranks<-t(apply(expr[genes,,drop=FALSE],1,rank,ties.method='average'))
 residuals<-t(qr.resid(qr(design),t(ranks)));res_min<-t(qr.resid(qr(minimal),t(ranks)))
 normalized<-residuals/sqrt(rowSums(residuals^2));norm_min<-res_min/sqrt(rowSums(res_min^2))
 z<-pairs;z$brain_region<-region;z$expression_tested<-z$mRNA_id %in% genes & z$lncRNA_id %in% genes
 z$rho_adjusted<-NA_real_;z$rho_without_cell_scores<-NA_real_;z$P_expression<-NA_real_;z$n_samples<-nrow(m);z$covariate_rank<-qr(design)$rank;z$correlation_df<-nrow(m)-qr(design)$rank-1
 idx<-which(z$expression_tested)
 for(i in idx){a<-z$mRNA_id[i];b<-z$lncRNA_id[i];rho<-sum(normalized[a,]*normalized[b,]);rho<-max(-1,min(1,rho));z$rho_adjusted[i]<-rho;z$rho_without_cell_scores[i]<-sum(norm_min[a,]*norm_min[b,]);tval<-rho*sqrt(z$correlation_df[i]/max(1e-15,1-rho^2));z$P_expression[i]<-2*pt(-abs(tval),df=z$correlation_df[i])}
 all[[region]]<-z
 # Rank-based candidate / cell correlations with covariate-adjusted degrees of freedom.
 cand<-fread('./project/outputs/AN_TWAS_HFD_union_20261013/Union_candidates_all_evidence.csv');cg<-intersect(unique(cand[HFD_testable==TRUE,gene_id]),rownames(expr))
 rc<-t(apply(expr[cg,,drop=FALSE],1,rank,ties.method='average'));rc<-t(qr.resid(qr(minimal),t(rc)));rc<-rc/sqrt(rowSums(rc^2))
 sr<-apply(as.matrix(ss[,c('ast','end','mic','neu','oli','opc')]),2,rank,ties.method='average');sr<-qr.resid(qr(minimal),sr);sr<-sweep(sr,2,sqrt(colSums(sr^2)),'/')
 cm<-rc %*% sr;df<-nrow(m)-qr(minimal)$rank-1
 records<-list();for(g in rownames(cm))for(ct in colnames(cm)){
  rho<-cm[g,ct];p<-2*pt(-abs(rho*sqrt(df/max(1e-15,1-rho^2))),df=df)
  records[[length(records)+1]]<-data.frame(brain_region=region,gene_id=g,gene_name=obj$annotation$symbol[match(g,obj$annotation$gene_id)],cell_type=c(ast='Astrocytes',end='Endothelial',mic='Microglia',neu='Neurons',oli='Oligodendrocytes',opc='OPCs')[[ct]],rho=rho,P=p,n=nrow(m),df=df)
 }
 cell_tests[[region]]<-rbindlist(records)
 cat(region,'ceRNA expression-tested pairs',sum(z$expression_tested),'/',nrow(z),'df',unique(z$correlation_df),'\n');flush.console()
}
all<-rbindlist(all);all$FDR_expression_all_brain_pair_tests<-NA_real_;idx<-which(all$expression_tested);all$FDR_expression_all_brain_pair_tests[idx]<-p.adjust(all$P_expression[idx],'BH')
all$context_supported<-all$expression_tested & all$rho_adjusted>=.3 & all$FDR_expression_all_brain_pair_tests<.05
fwrite(all,file.path(out,'ceRNA_all_expression_context_tests.csv'));fwrite(all[context_supported==TRUE],file.path(out,'ceRNA_context_supported_pairs.csv'))
ct<-rbindlist(cell_tests);ct$FDR_all_candidate_cell_tests<-p.adjust(ct$P,'BH');fwrite(ct,file.path(out,'Candidate67_brain_cell_score_correlations.csv'))
cat('Context supported pairs',sum(all$context_supported,na.rm=TRUE),'\n')
