.libPaths(unique(c('./project/R/win-library/4.4',.libPaths())))
library(ggplot2)
library(patchwork)
root <- './project/outputs/AN_functional_regulatory_20261013'
out <- file.path(root,'brain_cell_figures','paired_regions')
dir.create(out,recursive=TRUE,showWarnings=FALSE)
d <- read.csv(file.path(root,'Brain_cell_scores_plot_data.csv'))
s <- read.csv(file.path(root,'Brain_cell_composition_group_comparisons.csv'))
cells <- c('Astrocytes','Endothelial','Microglia','Neurons','Oligodendrocytes','OPCs')
codes <- c('ast','end','mic','neu','oli','opc')
d$cell_type <- cells[match(d$cell_code,codes)]
d$group <- factor(d$group,levels=c('Control','AN'))
cols <- c(Control='#548AA5',AN='#C37C69')
th <- theme_classic(base_size=8,base_family='Arial')+
 theme(axis.text=element_text(size=7,colour='#333333'),axis.title=element_text(size=8),
       legend.position='bottom',legend.title=element_text(size=7),legend.text=element_text(size=7),
       plot.margin=margin(5,5,5,5),plot.tag=element_text(size=12,face='bold'),
       plot.tag.position=c(0,1))
save_fig <- function(p,name,width=180,height=100) {
 svglite::svglite(file.path(out,paste0(name,'.svg')),width=width/25.4,height=height/25.4);print(p);dev.off()
 grDevices::cairo_pdf(file.path(out,paste0(name,'.pdf')),width=width/25.4,height=height/25.4,family='Arial');print(p);dev.off()
 ggsave(file.path(out,paste0(name,'.png')),p,device=ragg::agg_png,width=width,height=height,units='mm',dpi=300,bg='white')
 ggsave(file.path(out,paste0(name,'.tiff')),p,device=ragg::agg_tiff,width=width,height=height,units='mm',dpi=600,compression='lzw',bg='white')
}
ctables <- list();sorder <- list(); panels <- list()
for(region in c('DLPFC','Caudate')) {
 dd <- d[d$brain_region==region,]
 ss <- s[s$brain_region==region,]
 sm <- unique(dd[,c('sample_id','donor_id','group')]);sm <- sm[order(sm$group,sm$donor_id),]
 sm$sample_order <- seq_len(nrow(sm));stopifnot(nrow(sm)==107)
 dd$sample_order <- sm$sample_order[match(dd$sample_id,sm$sample_id)]
 dd$cell_type <- factor(dd$cell_type,levels=cells)
 stripe <- ggplot(sm,aes(sample_order,1,fill=group))+geom_tile()+
  scale_fill_manual(values=cols,name=NULL)+scale_x_continuous(limits=c(.5,107.5),expand=c(0,0))+
  theme_void(base_size=8,base_family='Arial')+
  theme(legend.position='top',legend.text=element_text(size=7),legend.key.size=grid::unit(2.3,'mm'),
        plot.margin=margin(0,5,0,5))
 ah <- ggplot(dd,aes(sample_order,cell_type,fill=score_Z))+geom_tile()+
  scale_fill_gradient2(low='#5186AA',mid='white',high='#BE7967',midpoint=0,limits=c(-5,5),name='Cell score (Z)')+
  scale_x_continuous(limits=c(.5,107.5),expand=c(0,0),breaks=c(43,96.5),labels=c('Control (n = 85)','AN (n = 22)'))+
  scale_y_discrete(limits=rev(cells),expand=c(0,0))+
  geom_vline(xintercept=85.5,colour='white',linewidth=.6)+
  labs(x=NULL,y=NULL)+th+
  theme(axis.line=element_blank(),axis.ticks=element_blank(),legend.key.width=grid::unit(6,'mm'),
        legend.key.height=grid::unit(2,'mm'),plot.margin=margin(0,5,2,5))
 A <- (stripe/ah)+plot_layout(heights=c(.13,1))+plot_annotation(tag_levels=list('A'))
 ss$cell_type <- factor(ss$cell_type,levels=cells)
 ss$label <- sprintf('P = %.3f',ss$P)
 ss$label_face <- ifelse(ss$P<.05,'bold','plain')
 B <- ggplot(dd,aes(cell_type,score_Z,fill=group))+
  geom_violin(position=position_dodge(width=.78),trim=TRUE,scale='width',width=.75,alpha=.45,linewidth=.3)+
  geom_boxplot(position=position_dodge(width=.78),width=.13,outlier.shape=NA,linewidth=.25,alpha=.85)+
  geom_text(data=ss,aes(cell_type,6,label=label,fontface=label_face),inherit.aes=FALSE,size=2.15,family='Arial')+
  scale_fill_manual(values=cols,guide='none')+
  scale_y_continuous(limits=c(-5.2,6.7),breaks=c(-4,-2,0,2,4),expand=expansion(mult=c(0,0)))+
  labs(x=NULL,y='Cell surrogate score (Z)',tag='B')+th+
  theme(axis.text.x=element_text(angle=30,hjust=1),plot.margin=margin(10,5,5,5))
 wide <- reshape(dd[,c('sample_id','cell_code','score_Z')],idvar='sample_id',timevar='cell_code',direction='wide')
 mat <- as.matrix(wide[,paste0('score_Z.',codes)]);colnames(mat)<-cells
 stopifnot(nrow(mat)==107,!anyNA(mat))
 cr <- cor(mat,method='spearman')
 cc <- as.data.frame(as.table(cr),stringsAsFactors=FALSE);names(cc)<-c('cell_1','cell_2','rho')
 cc$brain_region <- region;cc$cell_1 <- factor(cc$cell_1,levels=cells);cc$cell_2 <- factor(cc$cell_2,levels=rev(cells))
 C <- ggplot(cc,aes(cell_1,cell_2,fill=rho))+geom_tile(colour='white',linewidth=.35)+
  geom_text(aes(label=sprintf('%.2f',rho)),size=2.35,family='Arial')+
  scale_fill_gradient2(low='#5186AA',mid='white',high='#BE7967',limits=c(-1,1),midpoint=0,name='Spearman rho')+
  coord_fixed()+labs(x=NULL,y=NULL,tag='C')+th+
  theme(axis.line=element_blank(),axis.ticks=element_blank(),axis.text.x=element_text(angle=45,hjust=1),
        legend.key.width=grid::unit(5,'mm'),legend.key.height=grid::unit(2,'mm'),plot.margin=margin(5,5,5,5))
 # A is one tagged heatmap with a group stripe; avoid nested tags on both stripe and heatmap.
 A <- wrap_plots(stripe,ah,ncol=1,heights=c(.13,1))+plot_annotation(tag_levels=NULL)
 A <- A + plot_annotation(title=NULL)
 # Tag the heatmap rather than the stripe, keeping one A label in the assembled panel.
 A <- wrap_plots(stripe,ah+labs(tag='A'),ncol=1,heights=c(.13,1))
 left <- wrap_plots(list(A,B),ncol=1,heights=c(1,1))
 fig <- wrap_plots(list(left,C),nrow=1,widths=c(1.35,1))
 title_theme <- theme(plot.title=element_text(size=9,face='bold',hjust=.5))
 panels[[region]] <- list(
  A=wrap_plots(list(stripe+labs(title=region)+title_theme,ah+labs(tag=NULL)+guides(fill=guide_colourbar(title.position='top'))),ncol=1,heights=c(.22,1))+
    plot_annotation(title=region,theme=title_theme),
  B=B+labs(tag=NULL,title=region)+title_theme+
    guides(fill=guide_legend(nrow=1,title=NULL)),
  C=C+labs(tag=NULL,title=region)+title_theme+guides(fill=guide_colourbar(title.position='top')))
 ctables[[region]] <- cc;sorder[[region]] <- cbind(brain_region=region,sm)
}
write.csv(do.call(rbind,ctables),file.path(out,'Brain_cell_cell_Spearman_correlations.csv'),row.names=FALSE)
write.csv(do.call(rbind,sorder),file.path(out,'Sample_display_order.csv'),row.names=FALSE)
for(f in c('Brain_cell_scores_plot_data.csv','Brain_cell_composition_group_comparisons.csv'))file.copy(file.path(root,f),out,overwrite=TRUE)
# Identical scales and source data are retained; only layout changes.
for (kind in c('A','B','C')) {
  paired <- wrap_plots(list(panels$DLPFC[[kind]],panels$Caudate[[kind]]),nrow=1)
  if(kind=='A') save_fig(paired,'Paired_A_sample_heatmaps',320,90)
  if(kind=='B') save_fig(paired,'Paired_B_group_distributions',320,105)
  if(kind=='C') save_fig(paired,'Paired_C_cell_correlations',280,135)
}
writeLines(c('Left: DLPFC; right: caudate. Same source data and analysis as the separate panels.',
 'A: BRETIGEA standardized scores, not cell fractions. Both regions retain all 107 donors.',
 'B: adjusted model P values, nominal P<0.05 in bold. No comparison passes BH q<0.05 across 12 comparisons.',
 'C: descriptive Spearman correlations, not evidence of physical cell interaction.',
 'No panel letters. Region labels retained for identification. PNG 300 dpi; TIFF 600 dpi; editable PDF and SVG.',
 'Layout sizes: A 320x90 mm; B 320x105 mm; C 280x135 mm. Avoid excessive reduction.'),file.path(out,'README.txt'))
cat('Completed:',out,'\n')
