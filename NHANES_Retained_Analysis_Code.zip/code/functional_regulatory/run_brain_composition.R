.libPaths(c('./project/R/win-library/4.4',.libPaths()))
suppressPackageStartupMessages({library(edgeR);library(limma);library(data.table)})
root<-'./project/Workspaces/AN_functional_regulatory_20261013';out<-file.path(root,'results');raw<-file.path(root,'raw')
source(file.path(raw,'BRETIGEA_findCells.R'));load(file.path(raw,'markers_df_human_brain.rda'))
annotation<-fread(file.path(raw,'human_gene_annotation.tsv'),data.table=FALSE);colnames(annotation)<-c('gene_id','symbol','gene_type','entrez')
annotation<-unique(annotation[,1:3]);stopifnot(!anyDuplicated(annotation$gene_id))
meta<-fread('./project/outputs/GSE262138_AN_sample_mapping_20261013/GSE262138_AN_and_controls_verified_mapping.csv',data.table=FALSE)
rc<-fread('./project/Workspaces/AN_diet_transcriptome_20261013/raw/GSE262138_Raw_count_data.txt',data.table=FALSE)
counts<-rowsum(as.matrix(rc[,-1]),sub('\\..*$','',rc[[1]]),reorder=FALSE);rm(rc)
candidates<-fread('./project/outputs/AN_TWAS_HFD_union_20261013/Union_candidates_all_evidence.csv',data.table=FALSE)
candidate_symbols<-unique(annotation$symbol[annotation$gene_id %in% candidates$gene_id])
marker_pool<-markers_df_human_brain[!markers_df_human_brain$markers %in% candidate_symbols,]
names_ct<-c(ast='Astrocytes',end='Endothelial',mic='Microglia',neu='Neurons',oli='Oligodendrocytes',opc='OPCs')
allstats<-list();allcells<-list();sensitivity<-list();marker_audit<-list();concordance<-list()
fit_scores<-function(scores,m,region,model){
 rows<-list()
 for(ct in colnames(scores)) {
  y<-as.numeric(scale(scores[,ct]));dd<-m;dd$score<-y
  fit<-lm(score~group+Age+Sex+Race+RIN+Perc.Intronic+Perc.rRNA,data=dd)
  cf<-summary(fit)$coefficients['groupAN',];ci<-confint(fit,'groupAN')
  rows[[ct]]<-data.frame(brain_region=region,cell_type=names_ct[[ct]],cell_code=ct,model=model,effect_SD=cf[1],SE=cf[2],t=cf[3],P=cf[4],CI_low=ci[1],CI_high=ci[2],n_AN=sum(m$group=='AN'),n_control=sum(m$group=='Control'))
 }
 do.call(rbind,rows)
}
for(region in c('DLPFC','Caudate')){
 m<-meta[meta$brain_region==region,];m$group<-factor(ifelse(m$AN_case==1,'AN','Control'),levels=c('Control','AN'));m$Sex<-factor(m$Sex);m$Race<-factor(m$Race)
 keep<-fread(paste0('./project/Workspaces/AN_diet_transcriptome_20261013/results/AN_vs_control_',region,'_primary.csv'))$gene_id
 y<-calcNormFactors(DGEList(counts[keep,m$sample_id]));expr<-log2(cpm(y)+1)
 saveRDS(list(expression=expr,metadata=m,annotation=annotation),file.path(raw,paste0('human_',region,'_expression_context.rds')))
 names<-annotation$symbol[match(rownames(expr),annotation$gene_id)];idx<-!is.na(names)&nzchar(names)
 mat<-rowsum(expr[idx,],names[idx],reorder=FALSE);ng<-table(names[idx]);mat<-mat/as.numeric(ng[rownames(mat)])
 # Mean normalized expression for duplicate symbols; never use only candidate genes.
 capture.output(scores<-findCells(mat,marker_pool,nMarker=50,method='SVD',scale=TRUE),file=file.path(out,paste0('BRETIGEA_',region,'_algorithm_log.txt')))
 capture.output(scores100<-findCells(mat,marker_pool,nMarker=100,method='SVD',scale=TRUE),file=file.path(out,paste0('BRETIGEA_',region,'_100markers_log.txt')))
 stopifnot(identical(rownames(scores),m$sample_id),all(is.finite(scores)),ncol(scores)==6)
 allstats[[region]]<-fit_scores(scores,m,region,'50markers_excluding_candidate84');sensitivity[[region]]<-fit_scores(scores100,m,region,'100markers_excluding_candidate84')
 cc<-data.frame(sample_id=m$sample_id,donor_id=m$donor_id,brain_region=region,group=as.character(m$group),scores,check.names=FALSE)
 cc100<-data.frame(sample_id=m$sample_id,brain_region=region,scores100,check.names=FALSE);fwrite(cc100,file.path(out,paste0('BRETIGEA_',region,'_100marker_scores.csv')))
 allcells[[region]]<-cc
 for(ct in names(names_ct)){
  mk<-marker_pool$markers[marker_pool$cell==ct];mk<-mk[mk %in% rownames(mat)];mk<-mk[vapply(mk,function(g)any(mat[g,]>0),logical(1))];marker_audit[[paste(region,ct)]]<-data.frame(brain_region=region,cell_type=names_ct[[ct]],marker=seq_len(min(100,length(mk))),gene=mk[seq_len(min(100,length(mk)))],used_primary=seq_len(min(100,length(mk)))<=50)
  author<-switch(ct,ast=m$Astrocyte,end=m$Endothelial,mic=m$Microglia,neu=m$Excitatory+m$Inhibitory,oli=m$Oligo,opc=rep(NA_real_,nrow(m)))
  rho<-if(all(is.na(author)) || sd(author,na.rm=TRUE)==0) NA_real_ else cor(scores[,ct],author,method='spearman',use='complete.obs')
  concordance[[paste(region,ct)]]<-data.frame(brain_region=region,cell_type=names_ct[[ct]],rho_with_author_estimate=rho,rho_50_vs_100_markers=cor(scores[,ct],scores100[,ct],method='spearman'))
 }
 # Candidate expression versus SPV association after removing diagnosis and covariates.
 residualize<-model.matrix(~group+Age+Sex+Race+RIN+Perc.Intronic+Perc.rRNA,m)
 residual_scores<-qr.resid(qr(residualize),scale(scores))
 cand<-unique(candidates$gene_id[candidates$HFD_testable]);cand<-intersect(cand,rownames(expr));res_expr<-t(qr.resid(qr(residualize),t(expr[cand,,drop=FALSE])))
 rows<-list()
 for(gene in cand)for(ct in colnames(scores)){
  test<-cor.test(res_expr[gene,],residual_scores[,ct],method='spearman',exact=FALSE)
  rows[[length(rows)+1]]<-data.frame(brain_region=region,gene_id=gene,gene_name=annotation$symbol[match(gene,annotation$gene_id)],cell_type=names_ct[[ct]],rho=unname(test$estimate),P=test$p.value,n=nrow(m))
 }
 fwrite(rbindlist(rows),file.path(out,paste0('Candidate67_cell_scores_',region,'.csv')))
 cat(region,'BRETIGEA complete; samples',nrow(m),'genes',nrow(mat),'\n');flush.console()
}
stats<-rbindlist(allstats);stats$FDR_12_brain_cell_tests<-p.adjust(stats$P,'BH');fwrite(stats,file.path(out,'Brain_cell_composition_group_comparisons.csv'))
sens<-rbindlist(sensitivity);sens$FDR_12_brain_cell_tests<-p.adjust(sens$P,'BH');fwrite(sens,file.path(out,'Brain_cell_composition_100marker_sensitivity.csv'))
fwrite(rbindlist(allcells),file.path(out,'Brain_cell_surrogate_scores_all_samples.csv'))
fwrite(rbindlist(marker_audit),file.path(out,'Brain_cell_marker_audit.csv'));fwrite(rbindlist(concordance),file.path(out,'Brain_cell_author_estimate_concordance.csv'))
cs<-rbindlist(lapply(c('DLPFC','Caudate'),function(reg)fread(file.path(out,paste0('Candidate67_cell_scores_',reg,'.csv')))));cs$FDR_all_candidate_cell_tests<-p.adjust(cs$P,'BH');fwrite(cs,file.path(out,'Candidate67_brain_cell_score_correlations.csv'))
capture.output(sessionInfo(),file=file.path(out,'Brain_composition_R_sessionInfo.txt'))
print(stats[,.(brain_region,cell_type,effect_SD,P,FDR_12_brain_cell_tests)])
