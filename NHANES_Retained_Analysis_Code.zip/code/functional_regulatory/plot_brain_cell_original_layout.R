.libPaths(unique(c('./project/R/win-library/4.4',.libPaths())))
library(ggplot2)
library(patchwork)
root <- './project/outputs/AN_functional_regulatory_20261013'
out <- file.path(root,'brain_cell_figures','original_style')
dir.create(out,recursive=TRUE,showWarnings=FALSE)
d <- read.csv(file.path(root,'Brain_cell_scores_plot_data.csv'))
s <- read.csv(file.path(root,'Brain_cell_composition_group_comparisons.csv'))
cells <- c('Astrocytes','Endothelial','Microglia','Neurons','Oligodendrocytes','OPCs')
codes <- c('ast','end','mic','neu','oli','opc')
d$cell_type <- cells[match(d$cell_code,codes)]
d$group <- factor(d$group,levels=c('Control','AN'))
cols <- c(Control='#548AA5',AN='#C37C69')
th <- theme_classic(base_size=8,base_family='Arial')+
 theme(axis.text=element_text(size=7,colour='#333333'),axis.title=element_text(size=8),
       legend.position='bottom',legend.title=element_text(size=7),legend.text=element_text(size=7),
       plot.margin=margin(5,5,5,5),plot.tag=element_text(size=12,face='bold'),
       plot.tag.position=c(0,1))
save_fig <- function(p,name) {
 svglite::svglite(file.path(out,paste0(name,'.svg')),width=240/25.4,height=150/25.4);print(p);dev.off()
 grDevices::cairo_pdf(file.path(out,paste0(name,'.pdf')),width=240/25.4,height=150/25.4,family='Arial');print(p);dev.off()
 ggsave(file.path(out,paste0(name,'.png')),p,device=ragg::agg_png,width=240,height=150,units='mm',dpi=300,bg='white')
 ggsave(file.path(out,paste0(name,'.tiff')),p,device=ragg::agg_tiff,width=240,height=150,units='mm',dpi=600,compression='lzw',bg='white')
}
ctables <- list();sorder <- list()
for(region in c('DLPFC','Caudate')) {
 dd <- d[d$brain_region==region,]
 ss <- s[s$brain_region==region,]
 sm <- unique(dd[,c('sample_id','donor_id','group')]);sm <- sm[order(sm$group,sm$donor_id),]
 sm$sample_order <- seq_len(nrow(sm));stopifnot(nrow(sm)==107)
 dd$sample_order <- sm$sample_order[match(dd$sample_id,sm$sample_id)]
 dd$cell_type <- factor(dd$cell_type,levels=cells)
 stripe <- ggplot(sm,aes(sample_order,1,fill=group))+geom_tile()+
  scale_fill_manual(values=cols,name=NULL)+scale_x_continuous(limits=c(.5,107.5),expand=c(0,0))+
  theme_void(base_size=8,base_family='Arial')+
  theme(legend.position='top',legend.text=element_text(size=7),legend.key.size=grid::unit(2.3,'mm'),
        plot.margin=margin(0,5,0,5))
 ah <- ggplot(dd,aes(sample_order,cell_type,fill=score_Z))+geom_tile()+
  scale_fill_gradient2(low='#5186AA',mid='white',high='#BE7967',midpoint=0,limits=c(-5,5),name='Cell score (Z)')+
  scale_x_continuous(limits=c(.5,107.5),expand=c(0,0),breaks=c(43,96.5),labels=c('Control (n = 85)','AN (n = 22)'))+
  scale_y_discrete(limits=rev(cells),expand=c(0,0))+
  geom_vline(xintercept=85.5,colour='white',linewidth=.6)+
  labs(x=NULL,y=NULL)+th+
  theme(axis.line=element_blank(),axis.ticks=element_blank(),legend.key.width=grid::unit(6,'mm'),
        legend.key.height=grid::unit(2,'mm'),plot.margin=margin(0,5,2,5))
 A <- (stripe/ah)+plot_layout(heights=c(.13,1))+plot_annotation(tag_levels=list('A'))
 ss$cell_type <- factor(ss$cell_type,levels=cells)
 ss$label <- sprintf('P = %.3f',ss$P)
 ss$label_face <- ifelse(ss$P<.05,'bold','plain')
 B <- ggplot(dd,aes(cell_type,score_Z,fill=group))+
  geom_violin(position=position_dodge(width=.78),trim=TRUE,scale='width',width=.75,alpha=.45,linewidth=.3)+
  geom_boxplot(position=position_dodge(width=.78),width=.13,outlier.shape=NA,linewidth=.25,alpha=.85)+
  geom_text(data=ss,aes(cell_type,6,label=label,fontface=label_face),inherit.aes=FALSE,size=2.15,family='Arial')+
  scale_fill_manual(values=cols,guide='none')+
  scale_y_continuous(limits=c(-5.2,6.7),breaks=c(-4,-2,0,2,4),expand=expansion(mult=c(0,0)))+
  labs(x=NULL,y='Cell surrogate score (Z)',tag='B')+th+
  theme(axis.text.x=element_text(angle=30,hjust=1),plot.margin=margin(10,5,5,5))
 wide <- reshape(dd[,c('sample_id','cell_code','score_Z')],idvar='sample_id',timevar='cell_code',direction='wide')
 mat <- as.matrix(wide[,paste0('score_Z.',codes)]);colnames(mat)<-cells
 stopifnot(nrow(mat)==107,!anyNA(mat))
 cr <- cor(mat,method='spearman')
 cc <- as.data.frame(as.table(cr),stringsAsFactors=FALSE);names(cc)<-c('cell_1','cell_2','rho')
 cc$brain_region <- region;cc$cell_1 <- factor(cc$cell_1,levels=cells);cc$cell_2 <- factor(cc$cell_2,levels=rev(cells))
 C <- ggplot(cc,aes(cell_1,cell_2,fill=rho))+geom_tile(colour='white',linewidth=.35)+
  geom_text(aes(label=sprintf('%.2f',rho)),size=2.35,family='Arial')+
  scale_fill_gradient2(low='#5186AA',mid='white',high='#BE7967',limits=c(-1,1),midpoint=0,name='Spearman rho')+
  coord_fixed()+labs(x=NULL,y=NULL,tag='C')+th+
  theme(axis.line=element_blank(),axis.ticks=element_blank(),axis.text.x=element_text(angle=45,hjust=1),
        legend.key.width=grid::unit(5,'mm'),legend.key.height=grid::unit(2,'mm'),plot.margin=margin(5,5,5,5))
 # A is one tagged heatmap with a group stripe; avoid nested tags on both stripe and heatmap.
 A <- wrap_plots(stripe,ah,ncol=1,heights=c(.13,1))+plot_annotation(tag_levels=NULL)
 A <- A + plot_annotation(title=NULL)
 # Tag the heatmap rather than the stripe, keeping one A label in the assembled panel.
 A <- wrap_plots(stripe,ah+labs(tag='A'),ncol=1,heights=c(.13,1))
 left <- wrap_plots(list(A,B),ncol=1,heights=c(1,1))
 fig <- wrap_plots(list(left,C),nrow=1,widths=c(1.35,1))
 save_fig(fig,paste0('Brain_cell_ABC_',region))
 ctables[[region]] <- cc;sorder[[region]] <- cbind(brain_region=region,sm)
}
write.csv(do.call(rbind,ctables),file.path(out,'Brain_cell_cell_Spearman_correlations.csv'),row.names=FALSE)
write.csv(do.call(rbind,sorder),file.path(out,'Sample_display_order.csv'),row.names=FALSE)
for(f in c('Brain_cell_scores_plot_data.csv','Brain_cell_composition_group_comparisons.csv'))file.copy(file.path(root,f),out,overwrite=TRUE)
writeLines(c('Three-panel layout adapted to brain cell surrogate scores, not immune fractions.',
 'Two independent figure files display DLPFC and caudate; these regions come from the same 107 donors (22 AN, 85 control).',
 'A: complete sample-by-six-cell heatmap of region-standardized BRETIGEA scores. No percentage normalization or conversion of scores to fractions. All 642 score records retained per region. Sample order: group then donor ID; top stripe denotes group.',
 'B: violin density and boxplot distribution of raw standardized scores. Box: median/IQR; whiskers 1.5 IQR. Outlying score values remain represented in violin density; individual dots omitted for the requested compact style. Only covariate-adjusted model P values are displayed; bold means nominal P<0.05. These are not FDR significance claims. Full q values remain in the source CSV.',
 'Group model: age, sex, race, RIN, intronic fraction, rRNA fraction; BH q across 12 region-cell comparisons. No group difference passes q<0.05.',
 'C: descriptive, unadjusted Spearman correlations of cell surrogate scores across all 107 samples in each region. All 36 matrix entries displayed, including the diagonal. No inferential P values or claims of cell-cell interaction.',
 'Scores may reflect marker coexpression and technical variation; correlation is not evidence of physical interaction. Neuronal correlations with glial markers are not immune infiltration results.',
 'All drawing/export performed in R. PNG 300 dpi, TIFF 600 dpi, editable PDF/SVG. 240x150 mm assembly assets; preserve text readability on resizing.'),file.path(out,'README.txt'))
cat('Completed:',out,'\n')
