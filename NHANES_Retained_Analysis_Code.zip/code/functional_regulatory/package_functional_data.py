import pathlib,pandas as pd,numpy as np,json,shutil,hashlib
root=pathlib.Path(r'./project/Workspaces\AN_functional_regulatory_20261013');raw=root/'raw';r=root/'results';out=pathlib.Path(r'./project/outputs\AN_functional_regulatory_20261013');out.mkdir(exist_ok=True)
def bh(p):
 p=np.asarray(p);order=np.argsort(p);q=np.minimum.accumulate((p[order]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1];res=np.empty(len(p));res[order]=np.minimum(q,1);return res
pairs=pd.read_csv(r/'ceRNA_context_supported_pairs.csv');mr=pd.read_csv(r/'ENCORI_candidate_mRNA_site_evidence.csv');ln=pd.read_csv(r/'ENCORI_brain_expressed_lncRNA_site_evidence.csv')
candidate=pd.read_csv(r'./project/outputs\AN_TWAS_HFD_union_20261013\Union_candidates_all_evidence.csv')
annotation=pd.read_csv(raw/'human_gene_annotation.tsv',sep='\t',dtype=str);annotation.columns=['gene_id','symbol','gene_type','entrez'];annotation=annotation[['gene_id','symbol','gene_type']].drop_duplicates();names=dict(zip(annotation.gene_id,annotation.symbol))
nodes=[];edges=[];triplets=[]
for region,pp in pairs.groupby('brain_region'):
 seen=set();eds={}
 def add_node(node_id,label,kind,gene_id='',measured=False):
  if node_id in seen:return
  seen.add(node_id);nodes.append(dict(brain_region=region,node_id=node_id,label=label,node_type=kind,gene_id=gene_id,expression_measured_in_GSE262138=measured))
 for pair in pp.itertuples():
  mg=pair.mRNA_id;lg=pair.lncRNA_id;ml=names.get(mg) if isinstance(names.get(mg),str) else pair.mRNA_name;ll=names.get(lg) if isinstance(names.get(lg),str) else pair.lncRNA_name
  add_node('mRNA:'+mg,ml,'mRNA',mg,True);add_node('lncRNA:'+lg,ll,'lncRNA',lg,True)
  for mir in pair.shared_miRNAs.split(';'):
   add_node('miRNA:'+mir,mir,'miRNA','',False)
   msites=mr[(mr.geneID==mg)&(mr.miRNAname==mir)];lsites=ln[(ln.geneID==lg)&(ln.miRNAname==mir)];assert len(msites) and len(lsites)
   for kind,gid,site in [('miRNA_mRNA',mg,msites),('miRNA_lncRNA',lg,lsites)]:
    target=('mRNA:' if kind=='miRNA_mRNA' else 'lncRNA:')+gid;key=(mir,target)
    if key not in eds:
     eds[key]=dict(brain_region=region,source='miRNA:'+mir,target=target,edge_type=kind,evidence='ENCORI_AGO_CLIP_plus_prediction' if kind=='miRNA_mRNA' else 'ENCORI_AGO_CLIP_plus_seed_match',max_CLIP_experiments=int(pd.to_numeric(site.clipExpNum).max()),max_prediction_programs=int(site.predicting_program_count.max()) if kind=='miRNA_mRNA' else '',cell_tissue_context=';'.join(sorted(set(site['cellline/tissue'].dropna()))),brain_AN_specific_binding_validated=False)
   triplets.append(dict(brain_region=region,mRNA_id=mg,mRNA_name=ml,lncRNA_id=lg,lncRNA_name=ll,miRNA=mir,shared_seed_family_count=pair.shared_seed_family_count,shared_target_FDR=pair.shared_target_FDR,shared_seed_family_FDR=pair.shared_seed_family_FDR,rho_adjusted=pair.rho_adjusted,FDR_expression=pair.FDR_expression_all_brain_pair_tests,predicted_competition_only=True))
 edges.extend(eds.values())
pd.DataFrame(nodes).to_csv(r/'ceRNA_network_nodes.csv',index=False);pd.DataFrame(edges).to_csv(r/'ceRNA_network_edges.csv',index=False);pd.DataFrame(triplets).to_csv(r/'ceRNA_network_supported_triplets.csv',index=False)
summary=pd.DataFrame(nodes).groupby(['brain_region','node_type']).size().reset_index(name='n_nodes');summary.to_csv(r/'ceRNA_network_node_counts.csv',index=False)
# Plotting data include the complete ranked lists; only the display chooses named pathways.
gmt={}
for line in (raw/'GO_KEGG_human_combined.gmt').read_text().splitlines():
 f=line.split('\t');gmt[f[0]]=set(f[2:])
gsea=pd.read_csv(r/'GSEA_all_datasets.csv');curves=[]
rank_files={'DLPFC':'GSEA_rank_DLPFC.csv','Caudate':'GSEA_rank_Caudate.csv','Mouse_HFD_PFC':'GSEA_rank_mouse_HFD_PFC_human_orthologues.csv'}
for dataset,file in rank_files.items():
 ranks=pd.read_csv(raw/file).sort_values('statistic',ascending=False,kind='stable');hit=ranks.gene.isin(gmt['KEGG|hsa00190']).to_numpy();weights=np.abs(ranks.statistic.to_numpy());running=np.cumsum(np.where(hit,weights/weights[hit].sum(),-1/(~hit).sum()))
 rr=ranks.copy();rr['dataset']=dataset;rr['rank']=np.arange(1,len(rr)+1);rr['pathway_hit']=hit;rr['running_ES']=running;curves.append(rr)
 observed=gsea[(gsea.dataset==dataset)&(gsea.pathway=='KEGG|hsa00190')].ES.iloc[0];calculated=running.max() if running.max()>-running.min() else running.min();assert np.isclose(calculated,observed,atol=1e-8)
 pd.read_csv(raw/file).to_csv(r/file,index=False)
pd.concat(curves).to_csv(r/'GSEA_oxidative_phosphorylation_curve_data.csv',index=False)
key=gsea[gsea.pathway.isin(['KEGG|hsa00190','KEGG|hsa03010','KEGG|hsa04727','KEGG|hsa04080'])];key.to_csv(r/'GSEA_key_pathways.csv',index=False)
decomp=pd.read_csv(r/'Brain_cell_surrogate_scores_all_samples.csv');cols=['ast','end','mic','neu','oli','opc']
long=decomp.melt(id_vars=['sample_id','donor_id','brain_region','group'],value_vars=cols,var_name='cell_code',value_name='surrogate_score');long['score_Z']=long.groupby(['brain_region','cell_code']).surrogate_score.transform(lambda x:(x-x.mean())/x.std(ddof=1));long.to_csv(r/'Brain_cell_scores_plot_data.csv',index=False)
# Independent multiplicity and integrity checks.
ora=pd.read_csv(r/'GO_KEGG_ORA_all_results.csv')
for _,x in ora.groupby('candidate_set'):assert np.allclose(bh(x.P),x.FDR_all_GO_KEGG_in_set)
assert np.isfinite(gsea[['pval','NES','ES','FDR_all_three_datasets']].to_numpy()).all();assert np.allclose(bh(gsea.pval),gsea.FDR_all_three_datasets)
cell=pd.read_csv(r/'Brain_cell_composition_group_comparisons.csv');assert np.allclose(bh(cell.P),cell.FDR_12_brain_cell_tests);assert len(cell)==12 and len(decomp)==214
context=pd.read_csv(r/'ceRNA_all_expression_context_tests.csv');test=context[context.expression_tested];assert np.allclose(bh(test.P_expression),test.FDR_expression_all_brain_pair_tests);assert len(pairs)==38 and (pairs.rho_adjusted>=.3).all()
assert not pd.DataFrame(nodes)[['brain_region','node_id']].duplicated().any();assert not pd.DataFrame(edges)[['brain_region','source','target']].duplicated().any()
audit={'status':'PASS','ORA_FDR_all_libraries_significant':int((ora.FDR_all_GO_KEGG_in_set<.05).sum()),'GSEA_gene_rank_counts':{k:len(pd.read_csv(raw/v)) for k,v in rank_files.items()},'GSEA_FDR_global_significant_by_dataset':gsea[gsea.FDR_all_three_datasets<.05].groupby('dataset').size().to_dict(),'candidate67_mouse_GSEA_P':float(pd.read_csv(r/'GSEA_candidate67_independent_mouse_test.csv').pval.iloc[0]),'brain_composition_FDR12_significant':int((cell.FDR_12_brain_cell_tests<.05).sum()),'ceRNA_pairs_by_region':pairs.groupby('brain_region').size().to_dict(),'ceRNA_total_triplets':len(triplets),'ceRNA_total_node_records':len(nodes),'ceRNA_total_edge_records':len(edges),'images_generated':False,'primary_network_coexpression_adjustment':'diagnosis, age, sex, race, RIN, intronic/rRNA read fractions, six BRETIGEA SPVs; rank-residual correlation df=90','no_matched_miRNA_expression':True,'network_not_causal_validation':True}
(r/'validation.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
for f in r.iterdir():
 if f.is_file():shutil.copy2(f,out/f.name)
ref=out/'references';ref.mkdir(exist_ok=True)
for f in raw.iterdir():
 if f.is_file() and (f.suffix=='.gmt' or f.name in ['human_gene_annotation.tsv','BRETIGEA_findCells.R','BRETIGEA_brainCells.R','markers_df_human_brain.rda']):shutil.copy2(f,ref/f.name)
code=out/'code';code.mkdir(exist_ok=True)
for name in ['fetch_functional_resources.py','fetch_pathway_annotations.py','run_functional_enrichment.py','run_pathway_gsea.R','refine_gsea_precision.R','run_brain_composition.R','fetch_encori_candidates.py','build_cerna_pairs.py','refine_cerna_seed_families.py','test_cerna_expression_context.R','package_functional_data.py']:
 shutil.copy2(pathlib.Path(__file__).parent/name,code/name)
print(json.dumps(audit,indent=2));print(summary.to_string(index=False))
