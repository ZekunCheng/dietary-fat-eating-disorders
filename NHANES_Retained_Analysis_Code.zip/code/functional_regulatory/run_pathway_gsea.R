.libPaths(c('./project/R/win-library/4.4',.libPaths()))
suppressPackageStartupMessages({library(fgsea);library(data.table)})
root<-'./project/Workspaces/AN_functional_regulatory_20261013';raw<-file.path(root,'raw');out<-file.path(root,'results')
gmt<-readLines(file.path(raw,'GO_KEGG_human_combined.gmt'),warn=FALSE)
split<-strsplit(gmt,'\t',fixed=TRUE);pathways<-setNames(lapply(split,function(x)x[-c(1,2)]),vapply(split,'[',character(1),1));descriptions<-setNames(vapply(split,'[',character(1),2),names(pathways))
rankfiles<-c(DLPFC='GSEA_rank_DLPFC.csv',Caudate='GSEA_rank_Caudate.csv',Mouse_HFD_PFC='GSEA_rank_mouse_HFD_PFC_human_orthologues.csv')
all<-list();audit<-list()
for(i in seq_along(rankfiles)) {
 dataset<-names(rankfiles)[i];d<-fread(file.path(raw,rankfiles[i]));stopifnot(!anyDuplicated(d$gene),all(is.finite(d$statistic)))
 stats<-setNames(d$statistic,d$gene);stats<-sort(stats,decreasing=TRUE)
 set.seed(202610130+i);res<-fgseaMultilevel(pathways,stats,minSize=15,maxSize=500,eps=1e-6,nPermSimple=1000,nproc=1)
 res$dataset<-dataset;res$library<-sub('\\|.*','',res$pathway);res$term_name<-unname(descriptions[res$pathway]);res$leading_edge_genes<-vapply(res$leadingEdge,paste,character(1),collapse=';');res$leadingEdge<-NULL
 res$FDR_all_pathways_in_dataset<-res$padj
 for(lib in unique(res$library)){idx<-res$library==lib;res$padj[idx]<-p.adjust(res$pval[idx],'BH')}
 setnames(res,'padj','FDR_within_library');fwrite(res,file.path(out,paste0('GSEA_',dataset,'_all_results.csv')));all[[i]]<-res
 audit[[i]]<-data.frame(dataset=dataset,ranked_gene_count=length(stats),tested_pathways=nrow(res),FDR05_all_pathways=sum(res$FDR_all_pathways_in_dataset<.05,na.rm=TRUE))
 cat(dataset,'ranked genes',length(stats),'tested pathways',nrow(res),'FDR05',audit[[i]]$FDR05_all_pathways,'\n');flush.console()
 if(dataset=='Mouse_HFD_PFC'){
  custom<-strsplit(readLines(file.path(raw,'Candidate67_custom_gene_set.gmt')),'\t',fixed=TRUE)[[1]]
  set.seed(202610139);cr<-fgseaMultilevel(setNames(list(custom[-c(1,2)]),custom[1]),stats,minSize=15,maxSize=500,eps=1e-6,nPermSimple=1000,nproc=1)
  cr$leading_edge_genes<-vapply(cr$leadingEdge,paste,character(1),collapse=';');cr$leadingEdge<-NULL;fwrite(cr,file.path(out,'GSEA_candidate67_independent_mouse_test.csv'))
 }
}
combined<-rbindlist(all);combined$FDR_all_three_datasets<-p.adjust(combined$pval,'BH')
fwrite(combined,file.path(out,'GSEA_all_datasets.csv'));fwrite(combined[FDR_all_three_datasets<.05],file.path(out,'GSEA_FDR_significant_all_datasets.csv'));fwrite(rbindlist(audit),file.path(out,'GSEA_analysis_audit.csv'))
capture.output(sessionInfo(),file=file.path(out,'GSEA_R_sessionInfo.txt'))
