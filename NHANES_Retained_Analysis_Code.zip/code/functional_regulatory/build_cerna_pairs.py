import pathlib,json,pandas as pd,numpy as np,collections,itertools
from scipy.stats import hypergeom
root=pathlib.Path(r'./project/Workspaces\AN_functional_regulatory_20261013');raw=root/'raw';out=root/'results'
u=pd.read_csv(r'./project/outputs\AN_TWAS_HFD_union_20261013\Union_candidates_all_evidence.csv');u=u[u.HFD_testable].drop_duplicates('gene_id');eligible_ids=set(u.gene_id)
ann=pd.read_csv(raw/'human_gene_annotation.tsv',sep='\t',dtype=str);ann.columns=['gene_id','symbol','gene_type','entrez'];ann=ann[['gene_id','symbol','gene_type']].drop_duplicates()
de=pd.read_csv(r'./project/Workspaces\AN_diet_transcriptome_20261013\results\AN_DE_all_regions_primary.csv')
lnc_ids=set(ann.loc[ann.gene_type.eq('lncRNA'),'gene_id']) & set(de.gene_id)
pred_cols=['PITA','RNA22','miRmap','microT','miRanda','PicTar','TargetScan']
rnaframes=[];empty=[]
for f in (raw/'encori_mRNA').glob('*.tsv'):
 try:
  x=pd.read_csv(f,sep='\t',comment='#',dtype=str)
  if not {'miRNAname','geneID','clipExpNum'}.issubset(x.columns):empty.append(f.stem);continue
  x['predicting_program_count']=sum(pd.to_numeric(x[c],errors='coerce').fillna(0).gt(0).astype(int) for c in pred_cols)
  x=x[x.geneID.isin(eligible_ids)&pd.to_numeric(x.clipExpNum,errors='coerce').ge(1)&x.predicting_program_count.ge(2)]
  rnaframes.append(x)
 except pd.errors.EmptyDataError:empty.append(f.stem)
m=pd.concat(rnaframes,ignore_index=True)
lall=pd.read_csv(raw/'ENCORI_lncRNA_all.tsv',sep='\t',comment='#',dtype=str)
print('lnc seed classes',lall.merClass.value_counts().to_dict())
l=lall[lall.geneID.isin(lnc_ids)&pd.to_numeric(lall.clipExpNum,errors='coerce').ge(1)&lall.merClass.isin(['8mer','7mer-m8','7mer-A1'])].copy()
assert len(l)>0
m.to_csv(out/'ENCORI_candidate_mRNA_site_evidence.csv',index=False);l.to_csv(out/'ENCORI_brain_expressed_lncRNA_site_evidence.csv',index=False)
msets={g:set(x.miRNAname) for g,x in m.groupby('geneID')};lsets={g:set(x.miRNAname) for g,x in l.groupby('geneID')}
msym=dict(zip(m.geneID,m.geneName));lsym=dict(zip(l.geneID,l.geneName))
mir_universe=set(lall.miRNAname)|set(m.miRNAname);M=len(mir_universe)
rows=[]
for mg,mi in msets.items():
 for lg,li in lsets.items():
  common=mi&li;k=len(common);rows.append(dict(mRNA_id=mg,mRNA_name=msym[mg],lncRNA_id=lg,lncRNA_name=lsym[lg],shared_miRNA_count=k,shared_miRNAs=';'.join(sorted(common)),mRNA_miRNA_n=len(mi),lncRNA_miRNA_n=len(li),miRNA_background_n=M,shared_target_P=hypergeom.sf(k-1,M,len(mi),len(li)) if k else 1))
pairs=pd.DataFrame(rows);p=pairs.shared_target_P.to_numpy();order=np.argsort(p);q=np.minimum.accumulate((p[order]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1];pairs['shared_target_FDR']=np.empty(len(p));pairs.loc[order,'shared_target_FDR']=np.minimum(q,1)
pairs.to_csv(out/'ceRNA_all_shared_target_pair_tests.csv',index=False)
stage=pairs[(pairs.shared_miRNA_count>=2)&(pairs.shared_target_FDR<.05)].copy();stage.to_csv(out/'ceRNA_shared_target_supported_pairs.csv',index=False)
audit={'anchor_candidate_genes':67,'anchor_mRNAs_with_qualifying_ENCORI_sites':len(msets),'expressed_lncRNAs_with_qualifying_ENCORI_sites':len(lsets),'mRNA_CLIP_min':1,'mRNA_prediction_program_min':2,'lncRNA_CLIP_min':1,'lncRNA_seed_classes':['8mer','7mer-m8','7mer-A1'],'lncRNA_program_count_not_available_in_API':True,'shared_target_pair_family':len(pairs),'shared_miRNA_min':2,'shared_target_FDR_threshold':.05,'supported_shared_pairs':len(stage),'miRNA_background_n':M,'ENCORI_context':'public CLIP evidence from multiple non-AN tissues and cell lines; not necessarily brain','no_matched_miRNA_expression':True,'network_is_putative':True,'empty_mRNA_records':empty}
(out/'ceRNA_stage1_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
print(json.dumps(audit,indent=2));print(stage.sort_values('shared_target_P').head(5).to_string(index=False))
