import pathlib,sys,json,concurrent.futures,time
sys.path.insert(0,r'./project/Workspaces\dietary_fat_AN_MR\runtime\python-deps')
import requests,pandas as pd
root=pathlib.Path(r'./project/Workspaces\AN_functional_regulatory_20261013');raw=root/'raw';dest=raw/'encori_mRNA';dest.mkdir(exist_ok=True)
u=pd.read_csv(r'./project/outputs\AN_TWAS_HFD_union_20261013\Union_candidates_all_evidence.csv');u=u[u.HFD_testable].drop_duplicates('gene_id')
ann=pd.read_csv(raw/'human_gene_annotation.tsv',sep='\t');ann=ann.iloc[:,:3].drop_duplicates();ann.columns=['gene_id','annotation_name','gene_type']
u=u.merge(ann,on='gene_id',how='left',validate='one_to_one')
u.to_csv(root/'candidate_67_annotation_audit.csv',index=False);u=u[u.gene_type.eq('protein_coding')]
def fetch(row):
 name=row.annotation_name if pd.notna(row.annotation_name) else row.gene_name;f=dest/(row.gene_id+'.tsv')
 params=dict(assembly='hg38',geneType='mRNA',miRNA='all',clipExpNum=1,degraExpNum=0,pancancerNum=0,programNum=2,program='None',target=name,cellType='all')
 for attempt in range(3):
  try:
   if f.exists():return dict(gene_id=row.gene_id,gene_name=name,cached=True,bytes=f.stat().st_size)
   r=requests.get('https://rnasysu.com/encori/api/miRNATarget/',params=params,timeout=35);r.raise_for_status()
   if '<html' in r.text[:1000].lower():raise ValueError('HTML rather than API data')
   f.write_bytes(r.content);return dict(gene_id=row.gene_id,gene_name=name,url=r.url,bytes=len(r.content))
  except Exception as e:
   if attempt==2:return dict(gene_id=row.gene_id,gene_name=name,error=str(e))
res=[]
with concurrent.futures.ThreadPoolExecutor(4) as pool:
 for x in pool.map(fetch,u.itertuples(index=False)):
  res.append(x)
  if len(res)%10==0:print('ENCORI',len(res),'/',len(u),flush=True)
(root/'encori_candidate_download_log.json').write_text(json.dumps(res,indent=2),encoding='utf8')
print('ENCORI complete',len(res),'errors',sum('error' in x for x in res))
