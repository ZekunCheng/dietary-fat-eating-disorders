.libPaths(unique(c('./project/R/win-library/4.4',.libPaths())))
library(ggplot2)
library(patchwork)
root <- './project/outputs/AN_functional_regulatory_20261013'
out <- file.path(root,'brain_cell_figures')
dir.create(out,recursive=TRUE,showWarnings=FALSE)
d <- read.csv(file.path(root,'Brain_cell_scores_plot_data.csv'))
s <- read.csv(file.path(root,'Brain_cell_composition_group_comparisons.csv'))
corr <- read.csv(file.path(root,'Candidate67_brain_cell_score_correlations.csv'))
cells <- c('Astrocytes','Endothelial','Microglia','Neurons','Oligodendrocytes','OPCs')
codes <- c('ast','end','mic','neu','oli','opc')
colours <- c(Control='#548AA5',AN='#C37C69')
d$cell_type <- factor(cells[match(d$cell_code,codes)],levels=cells)
d$group <- factor(d$group,levels=c('Control','AN'))
stopifnot(!anyNA(d$cell_type),!anyNA(d$group),nrow(s)==12)
for(obj in c('d','s','corr')) {
 v <- get(obj);v$brain_region <- factor(v$brain_region,levels=c('DLPFC','Caudate'))
 if('cell_type'%in%names(v)) v$cell_type <- factor(v$cell_type,levels=cells)
 assign(obj,v)
}
th <- theme_classic(base_size=8,base_family='Arial')+
 theme(axis.line=element_line(linewidth=.3),axis.ticks=element_line(linewidth=.3),
       axis.text=element_text(size=7,colour='#333333'),
       strip.background=element_blank(),strip.text=element_text(size=7,face='bold'),
       legend.position='bottom',legend.text=element_text(size=7),legend.title=element_text(size=7),
       panel.spacing=grid::unit(3,'mm'),plot.margin=margin(5,5,5,5))
save_fig <- function(p,name,w,h) {
 svglite::svglite(file.path(out,paste0(name,'.svg')),width=w/25.4,height=h/25.4);print(p);dev.off()
 grDevices::cairo_pdf(file.path(out,paste0(name,'.pdf')),width=w/25.4,height=h/25.4,family='Arial');print(p);dev.off()
 ggsave(file.path(out,paste0(name,'.png')),p,device=ragg::agg_png,width=w,height=h,units='mm',dpi=300,bg='white')
 ggsave(file.path(out,paste0(name,'.tiff')),p,device=ragg::agg_tiff,width=w,height=h,units='mm',dpi=600,compression='lzw',bg='white')
}
s$label <- sprintf('P = %.3f\nFDR = %.3f',s$P,s$FDR_12_brain_cell_tests)
# Scores are displayed directly; annotation statistics come from the adjusted model.
distribution <- ggplot(d,aes(group,score_Z,fill=group))+
 geom_violin(trim=TRUE,scale='width',alpha=.20,colour=NA,width=.85)+
 geom_boxplot(width=.28,outlier.shape=NA,linewidth=.35,alpha=.8)+
 geom_point(position=position_jitter(width=.11,height=0,seed=20261015),size=.55,alpha=.30,shape=16,colour='#4E5962')+
 geom_text(data=s,aes(x=1.5,y=6.05,label=label),inherit.aes=FALSE,size=2.25,family='Arial',lineheight=1.1)+
 facet_grid(brain_region~cell_type)+scale_fill_manual(values=colours,guide='none')+
 scale_y_continuous(breaks=c(-4,-2,0,2,4),limits=c(-5.2,6.6),expand=expansion(mult=c(0,0)))+
 labs(x=NULL,y='Brain cell surrogate score (Z)')+th
save_fig(distribution,'Brain_cell_group_distributions',240,135)
s$cell_rev <- factor(s$cell_type,levels=rev(cells))
forest <- ggplot(s,aes(effect_SD,cell_rev,colour=brain_region))+
 geom_vline(xintercept=0,linetype=2,colour='grey65',linewidth=.35)+
 geom_segment(aes(x=CI_low,xend=CI_high,yend=cell_rev),linewidth=.6)+geom_point(size=2.2)+
 geom_text(aes(x=1.40,label=sprintf('%.3f',FDR_12_brain_cell_tests)),colour='#444444',size=2.5,family='Arial')+
 annotate('text',x=1.4,y=6.55,label='FDR',size=2.6,fontface='bold',family='Arial')+
 facet_wrap(~brain_region,nrow=1)+
 scale_colour_manual(values=c(DLPFC='#548AA5',Caudate='#8F82B1'),guide='none')+
 scale_y_discrete(expand=expansion(add=c(.5,1)))+
 scale_x_continuous(limits=c(-1.4,1.6),breaks=c(-1,-.5,0,.5,1))+
 labs(x='Adjusted AN - control difference (SD; 95% CI)',y=NULL)+th
save_fig(forest,'Brain_cell_adjusted_effects',183,90)
# Preserve all evaluable candidate-gene correlations, with missing entries explicit.
genes <- sort(unique(corr$gene_name))
grid <- expand.grid(brain_region=c('DLPFC','Caudate'),gene_name=genes,cell_type=cells,stringsAsFactors=FALSE)
key <- function(x)paste(x$brain_region,x$gene_name,x$cell_type,sep='|')
j <- match(key(grid),key(corr))
grid$rho <- corr$rho[j];grid$q <- corr$FDR_all_candidate_cell_tests[j]
grid$star <- ifelse(is.na(grid$q),'',ifelse(grid$q<.05,'*',''))
grid$gene_name <- factor(grid$gene_name,levels=rev(genes))
grid$cell_type <- factor(grid$cell_type,levels=cells)
grid$brain_region <- factor(grid$brain_region,levels=c('DLPFC','Caudate'))
heat <- ggplot(grid,aes(cell_type,gene_name,fill=rho))+
 geom_tile(colour='white',linewidth=.15)+geom_text(aes(label=star),size=2.0,colour='#292929')+
 facet_grid(.~brain_region)+
 scale_fill_gradient2(low='#5186AA',mid='white',high='#BE7967',midpoint=0,limits=c(-1,1),na.value='#D5D5D5',name='Adjusted rho')+
 labs(x=NULL,y=NULL)+th+
 theme(axis.line=element_blank(),axis.ticks=element_blank(),axis.text.x=element_text(angle=45,hjust=1,size=7),
       axis.text.y=element_text(size=6.5),legend.key.width=grid::unit(9,'mm'))
save_fig(heat,'Candidate67_brain_cell_correlations',183,250)
for(f in c('Brain_cell_scores_plot_data.csv','Brain_cell_composition_group_comparisons.csv','Candidate67_brain_cell_score_correlations.csv'))file.copy(file.path(root,f),out,overwrite=TRUE)
write.csv(grid,file.path(out,'Candidate67_brain_cell_heatmap_data.csv'),row.names=FALSE)
writeLines(c('Brain cell composition proxy visualization; BRETIGEA human-only markers, 50 detectable markers per cell type, excluding candidate84 genes.',
 'These are surrogate proportion variables, not absolute fractions or immune infiltration percentages. No stacked-percentage plot is supplied.',
 'Distributions: every retained score is plotted (22 AN and 85 controls per region and cell type); violin density, box median and IQR, whiskers within 1.5 IQR; jitter points retain all observations. Suppressed boxplot outlier dots are represented by the individual points.',
 'Distributions show unadjusted standardized scores; annotated P and FDR come from adjusted linear models. Covariates: age, sex, race, RIN, intronic and rRNA read fractions. No tests are inferred from raw boxplot positions.',
 'Forest: AN minus control adjusted differences in cell-score SD units; 95% confidence intervals. BH FDR across all 12 region-cell tests. No FDR < 0.05 result.',
 'Heatmap: all 67 candidate genes, six cell types, two regions; 798 evaluable adjusted rank-residual correlations. Asterisk: BH FDR < 0.05 across 798 tests; grey means not evaluable, not zero.',
 'Correlation covariates and residual degrees of freedom are retained in the original analysis code/tables. Correlation does not establish cell-specific gene expression or regulation.',
 'Cells: astrocytes, endothelial cells, microglia, neurons, oligodendrocytes, oligodendrocyte precursor cells (OPCs).',
 'Both brain regions share donors; this is not independent donor replication.',
 'No overall figure titles or panel letters. Editable PDF/SVG; PNG 300 dpi; TIFF 600 dpi. R source and original plotting data retained.'),file.path(out,'README.txt'))
stopifnot(length(genes)==67,nrow(corr)==798,nrow(d)==107*6*2)
cat('Completed:',out,'\n')
