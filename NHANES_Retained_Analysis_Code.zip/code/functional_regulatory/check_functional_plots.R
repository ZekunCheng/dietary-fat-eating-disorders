source('./project/outputs/AN_functional_regulatory_20261013/plot_functional_results.R')
stopifnot(grDevices::dev.cur()==1L)
for(set in c('Union_67_cross_species','Union_84_all_candidates')){
 p<-functional_figures$ora(set);b<-ggplot2::ggplot_build(p);stopifnot(nrow(b$data[[1]])==32,all(is.finite(b$data[[1]]$x)));cat('ORA',set,'PASS\n')
}
p<-functional_figures$gsea_heatmap();b<-ggplot2::ggplot_build(p);stopifnot(nrow(b$data[[1]])==nrow(p$data),nrow(p$data)%%3==0);cat('GSEA heatmap PASS\n')
p<-functional_figures$oxidative_curve();b<-ggplot2::ggplot_build(p);stopifnot(nrow(b$data[[2]])==nrow(p$data));cat('GSEA curves PASS\n')
p<-functional_figures$brain_forest();b<-ggplot2::ggplot_build(p);stopifnot(nrow(b$data[[2]])==12,nrow(b$data[[3]])==12);cat('Brain composition forest PASS\n')
p<-functional_figures$brain_boxplots();b<-ggplot2::ggplot_build(p);stopifnot(nrow(b$data[[2]])==214*6);cat('Brain scores 1284 observations PASS\n')
for(reg in c('DLPFC','Caudate')){
 p<-functional_figures$network(region=reg);b<-ggplot2::ggplot_build(p)
 stopifnot(nrow(b$data[[2]])==nrow(p$data));cat('ceRNA',reg,nrow(p$data),'nodes PASS\n')
}
p<-functional_figures$network(region='DLPFC',gene='MYO5A',label_miRNA=TRUE);b<-ggplot2::ggplot_build(p);stopifnot(nrow(b$data[[2]])==nrow(p$data));cat('ceRNA MYO5A module PASS\n')
stopifnot(grDevices::dev.cur()==1L);cat('All checks passed; no images generated.\n')
