import pathlib,json,pandas as pd,zipfile,shutil,numpy as np
out=pathlib.Path(r'./project/outputs\AN_TWAS_HFD_union_20261013');d=pd.read_csv(out/'Union_candidates_all_evidence.csv');a=json.loads((out/'union_audit.json').read_text())
report='''# AN 差异表达与 TWAS 并集：高脂饮食趋势检验

日期：2026-10-13。已完成。此分析根据用户要求，由此前严格交集改为并集；此前交集结果保留不变。此变更发生在观察交集为空之后，属于探索性整合，不应称为预注册分析或多证据同时验证。

## 选择规则

每个脑区分别选择：人体 AN vs 对照差异表达 BH FDR < 0.05，或对应脑区 AN TWAS 既有 12 脑组织全家族 BH FDR < 0.05。仍使用明确 AN-R/AN-BP 病例与正常对照，没有纳入 BN、未分类 ED 或 OCD，也没有改变任何显著性阈值。保留 selected_by_DE、selected_by_TWAS、evidence_source。

前额叶：18 个 DE 基因 + 25 个 TWAS 基因 = 43 个基因×脑区记录。
尾状核：27 个 DE 基因 + 25 个 TWAS 基因 = 52 个基因×脑区记录。
合计 95 个记录、84 个不同人体基因；DE 与对应脑区 TWAS 共同显著的记录仍为 0。少数 TWAS 基因不在人体表达过滤后的检验范围，明确标注 human_DE_tested = False，不能将缺失等同于零效应。

沿用 Ensembl 高置信度一对一人鼠同源映射、GSE236077 已核验的前额叶计数和原作者 QC；67 个不同小鼠基因可检验。HFD 候选家族 BH 改为这 67 个基因，不再沿用之前 31 个 TWAS 基因的 q 值，也不把同一个小鼠基因对应两个脑区重复计算。

## 结果

67 个基因中没有基因达到高脂饮食候选家族 FDR < 0.05。三个基因达到未校正 P < 0.05：

| 基因 | 入选依据 | 人体对应证据 | HFD log2FC | HFD P | 并集内 q | 方向解释 |
|---|---|---|---:|---:|---:|---|
| WDR6 | 前额叶及尾状核 TWAS | TWAS Z 为正，人体 AN DE 均不显著 | −0.3162 | 0.001536 | 0.1029 | 与遗传表达风险方向相反；不等于逆转实际 AN 表达 |
| SST | 前额叶 DE | AN log2FC = −0.6796，FDR = 0.00759 | −0.1535 | 0.01511 | 0.5060 | 高脂饮食变化与 AN 下调同向；不支持表达恢复 |
| CLIC1 | 前额叶及尾状核 TWAS | TWAS Z 为正，人体 AN DE 均不显著 | −0.3700 | 0.03093 | 0.6907 | 与遗传表达风险方向相反，尚无校正后的饮食支持 |

以上三者可作为探索性候选分别讨论，但不能称为经过并集筛选后得到的稳健保护基因。WDR6 在此前仅 31 个 TWAS 候选中的 q = 0.0476，而扩大到 67 个基因后 q = 0.1029；这是检验家族扩大的结果，不是表达效应改变。

## 方向的定义与脑区边界

HFD_vs_selection_direction：DE_only 使用显著的人体 AN log2FC 为参照；TWAS_only 使用 TWAS Z 为参照。两者的生物学含义不同。HFD_vs_observed_AN_direction 单独给出实际 AN 表达的方向，但其方向不表示该人体差异达到显著性。

小鼠只有前额叶；brain_region_match=True 表示人体 DLPFC 对小鼠 PFC 的跨物种比较，False 表示人体尾状核对小鼠 PFC 的跨脑区补充。不能据此宣称尾状核饮食验证。

并集扩大候选覆盖范围，不会消除急性饮食干预偏倚，也不能建立脂肪供能比→候选基因→AN 的因果链。TWAS 仍缺乏共定位验证；小鼠约 16 小时干预与长期人群饮食倾向不同。主饮食模型仍以随机分配饮食的笼为独立单位（3 笼 vs 3 笼），不是以同笼动物或重复脑区记录增加 n。

## 统计与敏感性

不重新运行或改变原差异模型。人体主分析仍为 edgeR filterByExpr、TMM 和 limma-voom，按脑区调整 group、Neuronal、RIN、Age、Sex、Race、Perc.Intronic 和 Perc.rRNA。饮食检验沿用已完成的、作者原始样本名与 GEO 计数精确核验后的笼汇总模型。

整合表提供人体增加 PMI 与简化模型结果，以及饮食半球调整、包含原 QC 失败动物和动物层面按笼相关建模结果；这些敏感性模型的候选集 q 也按各模型中可检验的并集基因重新计算。原先 31 个基因的留一笼家族 q 没有复制到新并集，以免检验家族混用。

来源和全部原模型、计数矩阵、原始样本对应验证、留一笼分析保存在 ./project/Workspaces/AN_diet_transcriptome_20261013 及 ./project/outputs/AN_TWAS_HFD_integration_20261013。

## 文件

- Union_candidates_all_evidence.csv：全部 95 条记录，含 84 个人体基因、证据来源、方向、显著性和敏感性分析。
- Union_mouse_testable_unique_genes.csv：67 个不同小鼠基因的饮食结果，FDR 的实际检验家族。
- Union_HFD_nominal_genes.csv：三个名义 P < 0.05 的基因，共五条人体脑区记录。
- Union_HFD_FDR_supported_genes.csv：无记录，保留表头。
- Union_PFC_opposite_direction_FDR_genes.csv：无记录，保留表头。
- Union_selection_counts.csv、union_audit.json：计数与规则审计。
- code/build_union_candidates.py：读取已完成结果进行并集和重新校正的代码；无需重新运行 MR、TWAS 或差异模型。

没有生成图片。各源分析的技术细节、输入哈希和原 R 代码详见此前完整分析包。
'''
(out/'Union_analysis_report_CN.md').write_text(report,encoding='utf8')
assert len(d)==95 and d.gene_id.nunique()==84
assert not d[['gene_id','brain_region']].duplicated().any()
assert len(pd.read_csv(out/'Union_HFD_FDR_supported_genes.csv'))==0
assert pd.read_csv(out/'Union_HFD_nominal_genes.csv').gene_name.nunique()==3
validation={'status':'PASS','gene_region_pairs':95,'unique_human_genes':84,'unique_testable_mouse_genes':67,'no_figures_generated':True,'strict_original_results_preserved':True}
(out/'validation.json').write_text(json.dumps(validation,indent=2),encoding='utf8')
shutil.copy2(pathlib.Path(__file__),out/'code/package_union_results.py')
with zipfile.ZipFile(str(out)+'.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
 for f in out.rglob('*'):
  if f.is_file():z.write(f,f.relative_to(out))
with zipfile.ZipFile(str(out)+'.zip') as z:assert z.testzip() is None
print('PACKAGE COMPLETE',str(out)+'.zip')
