import pathlib,pandas as pd,numpy as np,json,shutil
root=pathlib.Path(r'./project/Workspaces\AN_diet_transcriptome_20261013');r=root/'results'
out=pathlib.Path(r'./project/outputs\AN_TWAS_HFD_union_20261013');out.mkdir(exist_ok=True)
def bh(p):
 p=np.asarray(p);order=np.argsort(p);q=np.minimum.accumulate((p[order]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1];v=np.empty(len(p));v[order]=np.minimum(q,1);return v
de=pd.read_csv(r/'AN_DE_all_regions_primary_annotated.csv')
t=pd.read_csv(r'./project/outputs\AN_brain_localization_20261013\AN_TWAS_complete_models.csv')
t=t[t.tissue.isin(['Frontal_Cortex_BA9','Caudate_basal_ganglia'])].copy();t['gene_id']=t.gene.str.split('.').str[0];t['brain_region']=t.tissue.map({'Frontal_Cortex_BA9':'DLPFC','Caudate_basal_ganglia':'Caudate'})
t=t.rename(columns={'gene_name':'TWAS_gene_name','Z':'TWAS_Z','P':'TWAS_P','FDR_all_genes_12_tissues':'TWAS_FDR_12_tissues'})
t=t[['gene_id','brain_region','TWAS_gene_name','TWAS_Z','TWAS_P','TWAS_FDR_12_tissues','model_snps']]
allpairs=de.merge(t,on=['gene_id','brain_region'],how='outer',validate='one_to_one')
allpairs['selected_by_DE']=allpairs['adj.P.Val'].lt(.05);allpairs['selected_by_TWAS']=allpairs.TWAS_FDR_12_tissues.lt(.05)
u=allpairs[allpairs.selected_by_DE|allpairs.selected_by_TWAS].copy()
u['gene_name']=u.gene_name.fillna(u.TWAS_gene_name)
u['evidence_source']=np.select([u.selected_by_DE&u.selected_by_TWAS,u.selected_by_DE],['DE_and_TWAS','DE_only'],default='TWAS_only')
u['human_DE_tested']=u['P.Value'].notna()
ort=pd.read_csv(root/'raw/human_mouse_ensembl_orthologs.tsv',sep='\t');ort.columns=['gene_id','human_gene_name','mouse_gene_id','mouse_gene_name','orthology_type','orthology_confidence']
ort=ort[(ort.orthology_type=='ortholog_one2one')&(ort.orthology_confidence==1)].drop_duplicates();assert not ort.gene_id.duplicated().any()
u=u.merge(ort,on='gene_id',how='left',validate='many_to_one')
mouse=pd.read_csv(r/'HFD_vs_chow_PFC_cage_primary.csv')
target=mouse[mouse.mouse_gene_id.isin(u.mouse_gene_id.dropna().unique())].copy();target['HFD_FDR_union_candidates']=bh(target['P.Value'])
target=target.rename(columns={'logFC':'HFD_logFC','P.Value':'HFD_P','adj.P.Val':'HFD_FDR_genome','CI.L':'HFD_CI_low','CI.R':'HFD_CI_high'})
u=u.merge(target[['mouse_gene_id','HFD_logFC','HFD_P','HFD_FDR_genome','HFD_FDR_union_candidates','HFD_CI_low','HFD_CI_high']],on='mouse_gene_id',how='left',validate='many_to_one')
u['HFD_testable']=u.HFD_P.notna();u['HFD_brain_region']='mouse_PFC';u['brain_region_match']=u.brain_region.eq('DLPFC')
u['selection_reference_direction']=np.where(u.selected_by_DE,u.logFC,u.TWAS_Z)
u['HFD_vs_selection_direction']=np.where(~u.HFD_testable,'not_testable',np.where(np.sign(u.HFD_logFC)==np.sign(u.selection_reference_direction),'same','opposite'))
u['HFD_vs_observed_AN_direction']=np.where(~u.HFD_testable|~u.human_DE_tested,'not_testable',np.where(np.sign(u.HFD_logFC)==np.sign(u.logFC),'same','opposite'))
for label,file in [('AN_PMI','AN_vs_control_{}_PMI_adjusted.csv'),('AN_minimal','AN_vs_control_{}_demographic_RIN.csv')]:
 parts=[]
 for region in ['DLPFC','Caudate']:
  x=pd.read_csv(r/file.format(region))[['gene_id','brain_region','logFC','P.Value','adj.P.Val']].rename(columns={'logFC':label+'_logFC','P.Value':label+'_P','adj.P.Val':label+'_FDR'});parts.append(x)
 u=u.merge(pd.concat(parts),on=['gene_id','brain_region'],how='left',validate='one_to_one')
for label,file in [('HFD_hemisphere','HFD_vs_chow_PFC_cage_hemisphere_adjusted.csv'),('HFD_QC_included','HFD_vs_chow_PFC_cage_include_original_QC_fail.csv'),('HFD_animal_blocked','HFD_vs_chow_PFC_animal_cage_blocked.csv')]:
 x=pd.read_csv(r/file);x=x[x.mouse_gene_id.isin(target.mouse_gene_id)].copy()
 x[label+'_FDR_union']=bh(x['P.Value']);x=x[['mouse_gene_id','logFC','P.Value',label+'_FDR_union']].rename(columns={'logFC':label+'_logFC','P.Value':label+'_P'})
 u=u.merge(x,on='mouse_gene_id',how='left',validate='many_to_one')
u=u.sort_values(['HFD_P','brain_region'],na_position='last')
u.to_csv(out/'Union_candidates_all_evidence.csv',index=False)
target.to_csv(out/'Union_mouse_testable_unique_genes.csv',index=False)
u[u.HFD_FDR_union_candidates<.05].to_csv(out/'Union_HFD_FDR_supported_genes.csv',index=False)
u[u.HFD_P<.05].to_csv(out/'Union_HFD_nominal_genes.csv',index=False)
u[(u.HFD_FDR_union_candidates<.05)&u.HFD_vs_selection_direction.eq('opposite')&u.brain_region_match].to_csv(out/'Union_PFC_opposite_direction_FDR_genes.csv',index=False)
counts=u.groupby(['brain_region','evidence_source']).size().reset_index(name='n_gene_region_pairs');counts.to_csv(out/'Union_selection_counts.csv',index=False)
audit={'union_gene_region_pairs':len(u),'union_unique_human_genes':u.gene_id.nunique(),'selected_DE_pairs':int(u.selected_by_DE.sum()),'selected_TWAS_pairs':int(u.selected_by_TWAS.sum()),'both_selected_pairs':int((u.selected_by_DE&u.selected_by_TWAS).sum()),'testable_unique_mouse_genes':len(target),'HFD_FDR_supported_unique_genes':int((target.HFD_FDR_union_candidates<.05).sum()),'HFD_nominal_unique_genes':int((target.HFD_P<.05).sum()),'thresholds_changed':False,'HFD_candidate_FDR_family':'all distinct testable genes in two-brain-region DE/TWAS union'}
assert len(u)==95 and not (u.selected_by_DE&u.selected_by_TWAS).any();assert not u[['gene_id','brain_region']].duplicated().any();assert np.allclose(bh(target.HFD_P),target.HFD_FDR_union_candidates)
(out/'union_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
code=out/'code';code.mkdir(exist_ok=True);shutil.copy2(pathlib.Path(__file__),code/'build_union_candidates.py')
print(json.dumps(audit,indent=2));print(u[u.HFD_P<.05][['brain_region','gene_name','evidence_source','logFC','adj.P.Val','TWAS_Z','HFD_logFC','HFD_P','HFD_FDR_union_candidates','HFD_vs_selection_direction']].to_string(index=False))
