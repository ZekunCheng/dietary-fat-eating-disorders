.libPaths(c('./project/R/win-library/4.4',.libPaths()))
suppressPackageStartupMessages(library(SpatialExperiment))
root <- './project/Workspaces/AN_gsMap'
cat('Loading complete spatial object\n')
spe <- readRDS(file.path(root,'raw/spatialDLPFC/spe_filtered_final_with_clusters_and_deconvolution_results.rds'))
genes <- as.data.frame(rowData(spe))
write.csv(genes,file.path(root,'inputs/spatial/genes.csv'),row.names=FALSE)
info <- as.data.frame(colData(spe))
info$spot_id <- paste(info$sample_id,colnames(spe),sep='__')
coordinates <- spatialCoords(spe)
info$x <- coordinates[,1]
info$y <- coordinates[,2]
samples <- unique(as.character(spe$sample_id))
manifest <- list()
for (sample in samples) {
  folder <- file.path(root,'inputs/spatial',sample)
  dir.create(folder,showWarnings=FALSE)
  idx <- which(spe$sample_id==sample)
  if (!file.exists(file.path(folder,'export.done'))) {
    Matrix::writeMM(assay(spe,'counts')[,idx],file.path(folder,'counts.mtx'))
    write.csv(info[idx,],file.path(folder,'spots.csv'),row.names=FALSE)
    write.csv(reducedDim(spe,'HARMONY')[idx,,drop=FALSE],file.path(folder,'harmony.csv'),row.names=FALSE)
    writeLines('complete',file.path(folder,'export.done'))
  }
  manifest[[sample]] <- data.frame(sample=sample,subject=unique(info$subject[idx]),
    position=unique(info$position[idx]),spots=length(idx),genes=nrow(spe))
  cat('Exported',sample,length(idx),'spots\n')
  gc(FALSE)
}
write.csv(do.call(rbind,manifest),file.path(root,'audit/spatial_slice_manifest.csv'),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(root,'audit/R_sessionInfo.txt'))
cat('Complete: all',ncol(spe),'spots exported across',length(samples),'slices\n')
