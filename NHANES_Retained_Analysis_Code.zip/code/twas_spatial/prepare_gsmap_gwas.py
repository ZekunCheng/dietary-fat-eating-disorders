from pathlib import Path
import h5py,pandas as pd,numpy as np,json
root=Path(r'./project/Workspaces\AN_gsMap')
raw=Path(r'./project/Workspaces\dietary_fat_AN_MR\raw')
matrix=root/'resources/gsMap_quick_mode_resource/1000GP3_GRCh37_gencode_v46_protein_coding_ldscore_weights.h5ad'
with h5py.File(matrix) as h:
    ids={x.decode() for x in h['obs/SNP'][:]}
audit=[]
specs=[('AN','pgcAN2.2019-07.vcf.tsv.gz',16992,55525),('BN','finngen_R10_F5_BULIMIA.gz',1126,400510),('EDs','finngen_R7_F5_EATING.gz',2682,306472)]
for trait,name,ncase,ncontrol in specs:
    destination=root/'inputs/gwas'/f'{trait}.sumstats.tsv.gz'
    if destination.exists():
        cached=pd.read_csv(destination,sep='\t');audit.append({'trait':trait,'source':str(raw/name),'reference_matched_QC_variants':len(cached),'N_min':float(cached.N.min()),'N_max':float(cached.N.max()),'cases':ncase,'controls':ncontrol,'cached':True});print('Cached',trait,flush=True);continue
    results=[];total=0
    cols=['CHROM','POS','ID','REF','ALT','BETA','SE','PVAL','IMPINFO','NEFFDIV2'] if trait=='AN' else ['#chrom','pos','ref','alt','rsids','pval','beta','sebeta','af_alt']
    for chunk in pd.read_csv(raw/name,sep='\t',comment='#' if trait=='AN' else None,usecols=cols,chunksize=300000,encoding='utf-8',dtype={'ID':str,'REF':str,'ALT':str} if trait=='AN' else {'rsids':str,'ref':str,'alt':str}):
        total+=len(chunk)
        if trait=='AN':
            chunk=chunk[(chunk.IMPINFO>=.9)&chunk.ID.isin(ids)&chunk.CHROM.between(1,22)]
            d=pd.DataFrame({'SNP':chunk.ID,'A1':chunk.ALT,'A2':chunk.REF,'Z':chunk.BETA/chunk.SE,'N':2*chunk.NEFFDIV2,'P':chunk.PVAL,'CHR':chunk.CHROM,'BP':chunk.POS})
        else:
            chunk=chunk[chunk['#chrom'].between(1,22)&chunk.af_alt.between(.01,.99)]
            chunk=chunk.assign(rsids=chunk.rsids.fillna('').str.replace(';',',').str.split(',')).explode('rsids')
            chunk=chunk[chunk.rsids.isin(ids)]
            d=pd.DataFrame({'SNP':chunk.rsids,'A1':chunk.alt,'A2':chunk.ref,'Z':chunk.beta/chunk.sebeta,'N':4/(1/ncase+1/ncontrol),'P':chunk.pval,'CHR':chunk['#chrom'],'BP':chunk.pos})
        d=d[d.A1.isin(list('ACGT'))&d.A2.isin(list('ACGT'))&np.isfinite(d.Z)&np.isfinite(d.N)&(d.N>0)]
        results.append(d)
    d=pd.concat(results).drop_duplicates('SNP',keep=False)
    d.to_csv(destination,sep='\t',index=False,compression='gzip')
    audit.append({'trait':trait,'source':str(raw/name),'total_variants_scanned':total,'reference_matched_QC_variants':len(d),'cases':ncase,'controls':ncontrol,'N_min':float(d.N.min()),'N_max':float(d.N.max()),'N_rule':'2*NEFFDIV2 (source per-variant meta-analysis effective N)' if trait=='AN' else '4/(1/Ncase+1/Ncontrol)','QC':'autosomes, ACGT biallelic, finite Z/N, unique rsID, reference-covered SNPs; AN INFO>=0.9; FinnGen MAF>=0.01; no P-based selection','build':'GRCh37' if trait=='AN' else 'GRCh38; rsID-based match to GRCh37 LD reference'})
    print(trait,total,'scanned;',len(d),'retained; mean_chisq',float(np.mean(d.Z**2)),flush=True)
(root/'audit/GWAS_formatting.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
