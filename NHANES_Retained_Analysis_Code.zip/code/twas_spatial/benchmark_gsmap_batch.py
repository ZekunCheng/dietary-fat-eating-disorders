from pathlib import Path
import os,time,json
os.environ['OMP_NUM_THREADS']='2';os.environ['OPENBLAS_NUM_THREADS']='2'
import torch
import numpy as np
from threadpoolctl import threadpool_limits
threadpool_limits(2)
from gsMap.config import SpatialLDSCConfig
from gsMap.utils.regression_read import _read_ref_ld_v2,_read_w_ld
from gsMap.spatial_ldsc_multiple_sumstats import _get_sumstats_with_common_snp_from_sumstats_dict,S_LDSC_Boost_with_pre_calculate_SNP_Gene_weight_matrix,jackknife_for_processmap,append_intercept
from gsmap_batch_regression import batched_jackknife
root=Path(r'./project/Workspaces\AN_gsMap')
cfg=SpatialLDSCConfig(workdir=str(root/'analysis'),sample_name='Br2720_mid',trait_name='AN',sumstats_file=str(root/'inputs/gwas/AN.sumstats.tsv.gz'),w_file=str(root/'resources/gsMap_quick_mode_resource/weights_hm3_no_hla/weights.'),ldscore_save_format='quick_mode',snp_gene_weight_adata_path=str(root/'resources/gsMap_quick_mode_resource/1000GP3_GRCh37_gencode_v46_protein_coding_ldscore_weights.h5ad'),spots_per_chunk_quick_mode=32)
b=_read_ref_ld_v2(str(root/'resources/baseline/baseline.'));w=_read_w_ld(cfg.w_file).set_index('SNP')
stats,common=_get_sumstats_with_common_snp_from_sumstats_dict(cfg.sumstats_config_dict,b.index.intersection(w.index))
pos=b.index.get_indexer(common);b=b.loc[common];w=w.loc[common];s=stats['AN']
boost=S_LDSC_Boost_with_pre_calculate_SNP_Gene_weight_matrix(cfg,pos)
spatial,_=boost.fetch_ldscore_by_chunk(0);spatial=spatial.astype(np.float32)
start=time.time();optimized=batched_jackknife(spatial,b.to_numpy(),s,w);batchtime=time.time()-start
start=time.time();reference=np.array([jackknife_for_processmap(i,spatial,b.astype(np.float32).sum(axis=1).to_numpy(),s,append_intercept(b.to_numpy(dtype=np.float32)*(s.N.to_numpy()[:,None]/s.N.mean())),s.N.to_numpy()[:,None]/s.N.mean(),w,float(s.N.mean()),200) for i in range(spatial.shape[1])]);officialtime=time.time()-start
z_error=np.max(np.abs(optimized[:,0]/optimized[:,1]-reference[:,0]/reference[:,1]))
relative=np.max(np.abs(optimized-reference)/np.maximum(np.abs(reference),1e-15))
audit={'real_SNPs':len(common),'real_spots':spatial.shape[1],'batch_seconds':batchtime,'official_serial_seconds':officialtime,'max_Z_difference':float(z_error),'max_relative_beta_SE_difference':float(relative),'equivalence_pass':bool(z_error<1e-4 and relative<1e-3)}
(root/'audit/batch_regression_equivalence.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
print(audit,flush=True)
assert audit['equivalence_pass']
