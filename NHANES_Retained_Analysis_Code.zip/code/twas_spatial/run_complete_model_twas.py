from pathlib import Path
import sqlite3, pandas as pd, numpy as np, json
from scipy.stats import norm
root=Path(r'./project/Workspaces\AN_gsMap')
models=Path(r'./project/Workspaces\dietary_fat_AN_MR\brain_localization\models')
out=root/'analysis/TWAS'
out.mkdir(exist_ok=True)
weights={}
for p in sorted(models.glob('*.db')):
    if 'Spinal_cord' in p.name:continue
    with sqlite3.connect(p) as con:
        weights[p.stem]=pd.read_sql_query('SELECT * FROM weights',con)
ids=set(pd.concat(weights.values()).rsid.dropna())
cache=root/'inputs/gwas/AN_GTex_model_variants.csv.gz'
if not cache.exists():
    rows=[]
    source=Path(r'./project/Workspaces\dietary_fat_AN_MR\raw\pgcAN2.2019-07.vcf.tsv.gz')
    for c in pd.read_csv(source,sep='\t',comment='#',usecols=['ID','REF','ALT','BETA','SE','IMPINFO'],chunksize=400000,encoding='utf-8'):
        rows.append(c[c.ID.isin(ids)&(c.IMPINFO>=.9)])
    pd.concat(rows).drop_duplicates('ID',keep=False).to_csv(cache,index=False,compression='gzip')
gwas=pd.read_csv(cache).set_index('ID')
gwas=gwas[np.isfinite(gwas.BETA)&np.isfinite(gwas.SE)&(gwas.SE>0)]
rows=[];complement={'A':'T','T':'A','C':'G','G':'C'}
for tissue,w in weights.items():
    cov=pd.read_csv(models/(tissue+'.txt.gz'),sep=r'\s+')
    cov_groups={gene:c for gene,c in cov.groupby('GENE',sort=False)}
    for gene,m in w.groupby('gene',sort=False):
        m=m.reset_index(drop=True)
        nmodel=len(m);aligned=[];reason=[]
        for r in m.itertuples():
            if r.rsid not in gwas.index:reason.append('missing_or_QC_failed');aligned.append(np.nan);continue
            a=gwas.loc[r.rsid]
            if set([r.ref_allele,r.eff_allele]) in [{'A','T'},{'C','G'}]:reason.append('palindromic_no_EAF');aligned.append(np.nan);continue
            pair=(a.REF,a.ALT);target=(r.ref_allele,r.eff_allele)
            reverse=(r.eff_allele,r.ref_allele)
            strand=tuple(complement.get(x,'?') for x in pair)
            if pair==target or strand==target:sign=1
            elif pair==reverse or strand==reverse:sign=-1
            else:reason.append('allele_mismatch');aligned.append(np.nan);continue
            aligned.append(sign*a.BETA/a.SE)
        nmatch=int(np.isfinite(aligned).sum())
        result={'tissue':tissue.replace('mashr_Brain_',''),'gene':gene,'model_snps':nmodel,'matched_snps':nmatch,'coverage':nmatch/nmodel,'status':'incomplete_model','Z':np.nan,'P':np.nan}
        if nmatch==nmodel and gene in cov_groups:
            index={v:i for i,v in enumerate(m.varID)}
            matrix=np.zeros((nmodel,nmodel))
            for c in cov_groups[gene].itertuples():
                if c.RSID1 in index and c.RSID2 in index:
                    i,j=index[c.RSID1],index[c.RSID2]
                    matrix[i,j]=matrix[j,i]=c.VALUE
            diagonal=np.diag(matrix)
            weight=m.weight.to_numpy()
            variance=float(weight@matrix@weight)
            if (diagonal>0).all() and variance>0:
                z=float(np.sum(weight*np.sqrt(diagonal)*np.asarray(aligned))/np.sqrt(variance))
                # Single-variant models must reduce exactly to signed GWAS Z.
                if nmodel==1:assert abs(z-np.sign(weight[0])*aligned[0])<1e-8
                result.update(status='complete_model',Z=z,P=float(2*norm.sf(abs(z))),prediction_variance=variance)
            else:result['status']='invalid_covariance'
        result['exclusions']=';'.join(sorted(set(reason)))
        rows.append(result)
    print('TWAS',tissue,'processed',flush=True)
d=pd.DataFrame(rows)
valid=d.P.notna()
p=d.loc[valid,'P'].to_numpy();order=np.argsort(p);q=np.empty(len(p))
q[order]=np.minimum(1,np.minimum.accumulate((p[order]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1])
d.loc[valid,'FDR_all_genes_12_tissues']=q
d.to_csv(out/'AN_TWAS_all_models_with_coverage.csv',index=False)
d.loc[valid].sort_values('P').to_csv(out/'AN_TWAS_complete_models.csv',index=False)
d.loc[valid & (d.FDR_all_genes_12_tissues<.05)].sort_values('P').to_csv(out/'AN_TWAS_FDR_signals.csv',index=False)
d.pivot(index='gene',columns='tissue',values='Z').to_csv(out/'AN_TWAS_gene_by_brain_tissue_Z.csv')
summary=d.groupby('tissue').agg(all_models=('gene','size'),complete_models=('P','count'),median_coverage=('coverage','median'))
summary['FDR_significant']=d.assign(significant=d.FDR_all_genes_12_tissues<.05).groupby('tissue').significant.sum()
summary.to_csv(out/'AN_TWAS_tissue_summary.csv')
(out/'method_audit.json').write_text(json.dumps({'implementation':'S-PrediXcan summary association formula; complete SNP/allele coverage only','formula':'Z_gene = sum(weight_i * sqrt(cov_ii) * aligned_Z_i)/sqrt(weight.T @ cov @ weight)','main_family':'all tested complete models across 12 GTEx brain tissues','no_partial_model_imputation':True,'palindromic_variants':'excluded without allele-frequency resolution','not_tissue_enrichment_test':True,'not_causal_or_colocalization_evidence':True,'total_models':len(d),'tested_complete_models':int(valid.sum())},indent=2),encoding='utf-8')
print(summary.to_string(),flush=True)
