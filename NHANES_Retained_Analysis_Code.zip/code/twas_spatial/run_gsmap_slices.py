from pathlib import Path
import os,sys,logging,json,time
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import torch
torch.set_num_threads(2)
import pandas as pd
from gsMap.config import LatentToGeneConfig,SpatialLDSCConfig
from gsMap.latent_to_gene import run_latent_to_gene
from gsMap.spatial_ldsc_multiple_sumstats import run_spatial_ldsc
root=Path(r'./project/Workspaces\AN_gsMap')
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s',handlers=[logging.StreamHandler(sys.stdout),logging.FileHandler(root/'logs/gsmap_all_slices.log',encoding='utf-8')])
sample_arg=sys.argv[1] if len(sys.argv)>1 else None
for folder in sorted((root/'inputs/spatial').iterdir()):
    if not folder.is_dir() or not (folder/f'{folder.name}.h5ad').exists():continue
    sample=folder.name
    if sample_arg and sample!=sample_arg:continue
    config=LatentToGeneConfig(workdir=str(root/'analysis'),sample_name=sample,input_hdf5_path=str(folder/f'{sample}.h5ad'),latent_representation='HARMONY',annotation=None,num_neighbour=21,num_neighbour_spatial=101)
    if not config.mkscore_feather_path.exists():run_latent_to_gene(config)
    baseline=config.ldscore_save_dir/'baseline'
    baseline.mkdir(exist_ok=True)
    for source in (root/'resources/baseline').iterdir():
        dest=baseline/source.name
        if not dest.exists():os.link(source,dest)
    for trait in ['AN','BN','EDs']:
        settings=SpatialLDSCConfig(workdir=str(root/'analysis'),sample_name=sample,w_file=str(root/'resources/gsMap_quick_mode_resource/weights_hm3_no_hla/weights.'),trait_name=trait,sumstats_file=str(root/'inputs/gwas'/f'{trait}.sumstats.tsv.gz'),num_processes=4,n_blocks=200,ldscore_save_format='quick_mode',spots_per_chunk_quick_mode=32,snp_gene_weight_adata_path=str(root/'resources/gsMap_quick_mode_resource/1000GP3_GRCh37_gencode_v46_protein_coding_ldscore_weights.h5ad'))
        if settings.get_ldsc_result_file(trait).exists():continue
        run_spatial_ldsc(settings)
    print('Completed all three traits:',sample,flush=True)
