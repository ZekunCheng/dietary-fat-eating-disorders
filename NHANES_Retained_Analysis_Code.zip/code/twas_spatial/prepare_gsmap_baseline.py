from pathlib import Path
import torch
import anndata as ad,pandas as pd,numpy as np,json
root=Path(r'./project/Workspaces\AN_gsMap')
p=root/'resources/gsMap_quick_mode_resource/1000GP3_GRCh37_gencode_v46_protein_coding_ldscore_weights.h5ad'
a=ad.read_h5ad(p)
assert a.var_names[-1]=='Unmapped' and a.obs.CHR.is_monotonic_increasing
# Official gsMap baseline is all_gene=1 on mapped genes/0 on Unmapped,
# and base=1 on all features. Matrix multiplication reconstructs these exactly.
baseline=pd.DataFrame({'CHR':pd.to_numeric(a.obs.CHR).to_numpy(),'SNP':a.obs_names,'BP':a.obs.BP.to_numpy(),
 'all_gene':np.asarray(a.X[:,:-1].sum(axis=1)).ravel(),'base':np.asarray(a.X.sum(axis=1)).ravel()})
folder=root/'resources/baseline'
folder.mkdir(exist_ok=True)
for chrom in range(1,23):baseline.loc[baseline.CHR==chrom, ['SNP','all_gene','base']].reset_index(drop=True).to_feather(folder/f'baseline.{chrom}.l2.ldscore.feather')
(root/'audit/baseline_reconstruction.json').write_text(json.dumps({'rows':len(baseline),'features':a.n_vars,'last_feature':'Unmapped','rule':'Official gsMap _calculate_baseline_ldscores: mapped-gene sum and all-feature sum','reference_build':'GRCh37','reference_ancestry':'1000 Genomes Phase 3 EUR','no_new_reference_estimation':True},indent=2),encoding='utf-8')
print('Reconstructed official two-column baseline for all 22 autosomes',flush=True)
