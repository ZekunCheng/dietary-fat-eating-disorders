import numpy as np

def batched_jackknife(spatial, baseline, sumstats, w_ld, n_blocks=200):
    # Same weighting, regression and block-jackknife equations as gsMap 1.73.8.
    # Only normal-equation calculation is batched; no SNP/spot subsampling.
    spatial=np.asarray(spatial,dtype=np.float32)
    bas=np.asarray(baseline,dtype=np.float32)
    N=sumstats.N.to_numpy(dtype=np.float64)
    y=sumstats.chisq.to_numpy(dtype=np.float64)
    Nbar=N.mean(); nratio=N/Nbar
    total=spatial+bas.sum(axis=1)[:,None]
    hsq=np.clip(10000*(y.mean()-1)/(total.astype(np.float64)*N[:,None]).mean(axis=0),0,1)
    q=np.sqrt(1/(2*np.square(1+(hsq[None,:]*N[:,None]/10000)*np.maximum(total,1))) / np.maximum(w_ld.LD_weights.to_numpy()[:,None],1)).astype(np.float32)
    q=q/q.sum(axis=0)
    B=np.column_stack((bas*nratio[:,None],np.ones(len(N))))
    pairs=[(i,j) for i in range(B.shape[1]) for j in range(i,B.shape[1])]
    common=np.column_stack([B[:,i]*B[:,j] for i,j in pairs]+[B[:,i]*y for i in range(B.shape[1])])
    blocks=np.floor(np.linspace(0,len(N),n_blocks+1)).astype(int)
    size=spatial.shape[1]; dim=B.shape[1]+1
    xtx=np.zeros((n_blocks,size,dim,dim));xty=np.zeros((n_blocks,size,dim))
    for b,(start,end) in enumerate(zip(blocks[:-1],blocks[1:])):
        weight2=q[start:end].astype(np.float64)**2
        s=spatial[start:end].astype(np.float64)*nratio[start:end,None]
        fixed=weight2.T@common[start:end]
        for k,(i,j) in enumerate(pairs):xtx[b,:,i+1,j+1]=xtx[b,:,j+1,i+1]=fixed[:,k]
        xty[b,:,1:]=fixed[:,len(pairs):]
        xtx[b,:,0,0]=np.sum(weight2*s*s,axis=0)
        cross=(weight2*s).T@B[start:end]
        xtx[b,:,0,1:]=cross;xtx[b,:,1:,0]=cross
        xty[b,:,0]=np.sum(weight2*s*y[start:end,None],axis=0)
    xsum=xtx.sum(axis=0);ysum=xty.sum(axis=0)
    estimate=np.linalg.solve(xsum,ysum[...,None])[...,0]
    deleted=np.linalg.solve(xsum[None]-xtx,(ysum[None]-xty)[...,None])[...,0]
    pseudo=n_blocks*estimate[None]-(n_blocks-1)*deleted
    beta=pseudo[:,:,0].mean(axis=0)/Nbar
    se=pseudo[:,:,0].std(axis=0,ddof=1)/np.sqrt(n_blocks)/Nbar
    return np.column_stack([beta,se])
