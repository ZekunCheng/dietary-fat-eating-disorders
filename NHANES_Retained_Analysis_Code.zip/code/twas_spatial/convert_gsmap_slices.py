from pathlib import Path
import os
os.environ.setdefault('OMP_NUM_THREADS','2')
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
import torch
import anndata as ad,pandas as pd,numpy as np
from scipy.io import mmread
from scipy import sparse
root=Path(r'./project/Workspaces\AN_gsMap')
genes=pd.read_csv(root/'inputs/spatial/genes.csv')
symbols=genes.gene_name.fillna(genes.gene_id).astype(str)
codes,unique=pd.factorize(symbols,sort=False)
mapping=sparse.csr_matrix((np.ones(len(codes),dtype=np.int32),(np.arange(len(codes)),codes)),shape=(len(codes),len(unique)))
first=np.array([np.flatnonzero(codes==i)[0] for i in range(len(unique))])
var=genes.iloc[first].copy().set_axis(pd.Index(unique,name='HUMAN_GENE_SYM'))
for column in var:
    if var[column].dtype==object:var[column]=var[column].fillna('').astype(str)
for folder in sorted((root/'inputs/spatial').iterdir()):
    if not folder.is_dir() or not (folder/'export.done').exists():continue
    target=folder/f'{folder.name}.h5ad'
    if target.exists():continue
    obs=pd.read_csv(folder/'spots.csv').set_index('spot_id')
    obs.index=obs.index.astype(str)
    for column in obs:
        if obs[column].dtype==object:obs[column]=obs[column].fillna('Unknown').astype(str)
    x=(mmread(folder/'counts.mtx').T.tocsr().astype(np.float32) @ mapping).tocsr()
    assert x.shape==(len(obs),len(var)) and (x.data>=0).all()
    a=ad.AnnData(X=x,obs=obs,var=var.copy())
    a.obsm['spatial']=obs[['x','y']].to_numpy(dtype=np.float64)
    a.obsm['HARMONY']=pd.read_csv(folder/'harmony.csv').to_numpy(dtype=np.float32)
    a.obs['domain']=a.obs['BayesSpace_harmony_09'].astype(str)
    a.obs['layer']=a.obs['ManualAnnotation'].fillna('Unknown').astype(str)
    assert len(set(a.obs_names))==a.n_obs and np.isfinite(a.obsm['spatial']).all()
    a.write_h5ad(target,compression='gzip')
    print('Converted',folder.name,a.shape,'UMIs',int(x.sum()),flush=True)
