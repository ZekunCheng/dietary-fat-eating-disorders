from pathlib import Path
import pandas as pd,numpy as np,sqlite3,json,shutil,zipfile
from scipy.stats import cauchy
root=Path(r'./project/Workspaces\AN_gsMap')
out=Path(r'./project/outputs\AN_brain_localization_20261013')
out.mkdir(exist_ok=True)
def bh(values):
    p=np.asarray(values);order=np.argsort(p);q=np.empty(len(p));q[order]=np.minimum(1,np.minimum.accumulate((p[order]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1]);return q
def acat(values):
    p=np.clip(np.asarray(values,dtype=float),1e-300,1-1e-15)
    small=p<1e-15;terms=np.empty(len(p));terms[small]=1/(np.pi*p[small]);terms[~small]=np.tan((.5-p[~small])*np.pi)
    t=np.mean(terms)
    return float(1/(np.pi*t) if t>1e15 else cauchy.sf(t))
models=Path(r'./project/Workspaces\dietary_fat_AN_MR\brain_localization\models')
genes={}
for p in models.glob('*.db'):
    with sqlite3.connect(p) as conn:
        genes.update(dict(conn.execute('select gene,genename from extra').fetchall()))
for p in (root/'analysis/TWAS').glob('*.csv'):
    d=pd.read_csv(p)
    if 'gene' in d:d.insert(list(d.columns).index('gene')+1,'gene_name',d.gene.map(genes))
    d.to_csv(out/p.name,index=False,encoding='utf-8-sig')
summary=pd.read_csv(root/'analysis/TWAS/AN_TWAS_tissue_summary.csv')
main=pd.read_csv(root/'analysis/TWAS/AN_TWAS_complete_models.csv')
signals=main[main.FDR_all_genes_12_tissues<.05]
signal_unique=signals.gene.nunique()
manifest=pd.read_csv(root/'audit/spatial_slice_manifest.csv')
completed=[];pieces=[]
for row in manifest.itertuples():
    obs=pd.read_csv(root/'inputs/spatial'/row.sample/'spots.csv')
    obs['domain']=obs.BayesSpace_harmony_09.astype(str)
    fields=['spot_id','sample_id','subject','position','domain','x','y','sum_umi']
    for trait in ['AN','BN','EDs']:
        path=root/'analysis'/row.sample/'spatial_ldsc'/f'{row.sample}_{trait}.csv.gz'
        if not path.exists():continue
        d=pd.read_csv(path).rename(columns={'spot':'spot_id'})
        if len(d)!=len(obs):raise RuntimeError(f'Incomplete spot results: {row.sample} {trait}')
        d=d.merge(obs[fields],on='spot_id',validate='one_to_one')
        d['trait']=trait
        pieces.append(d);completed.append({'sample':row.sample,'trait':trait,'spots':len(d)})
full=len(completed)==90
pd.DataFrame(completed).to_csv(out/'gsMap_completed_slice_traits.csv',index=False,encoding='utf-8-sig')
manifest.to_csv(out/'spatial_slice_manifest.csv',index=False,encoding='utf-8-sig')
report=['# 脑区定位分析', '',f'状态：12脑组织AN遗传表达关联已完成；gsMap切片×结局完成 {len(completed)}/90。', '',
 f'空间参考：10名正常成年供者、30张DLPFC切片、113927个空间点。合并重复基因名后28907个基因；保留全部空间点。按切片处理真实坐标，使用作者提供的Harmony嵌入，邻域参数为101个空间邻居/21个表达相似邻居。没有生成图片。', '',
 f'AN跨组织分析：164258个可用模型中，仅50397个满足完整SNP、等位基因及协方差覆盖的模型进入检验；其他模型保留覆盖记录，没有填充缺失GWAS效应。统一BH校正后295个基因×脑组织关联显著，涉及{signal_unique}个不同基因。', '',
 '前额叶BA9：4256个完整模型，25个FDR显著关联。尾状核：4289个完整模型，25个FDR显著关联。其他脑组织也有信号，因此该结果不能证明前额叶特异性；显著基因数量不可直接作为脑区重要性排名。MASHR权重跨组织借力，模型覆盖有限，组织结果高度相关。', '',
 '该分析实现S-PrediXcan的完整模型公式：Z_gene=sum(w_i*sqrt(cov_ii)*Z_i)/sqrt(w.T*cov*w)，双侧P，12脑组织所有实际检验统一BH校正。仅采用完整覆盖模型，不代替共定位或组织富集检验；不少预测模型只有1个SNP，其关联可能由已有GWAS位点驱动。', '',
 'gsMap：官方1.73.8的基因评分、预计算SNP—基因权重和200块jackknife回归；EUR参考；AN采用源文件2×NEFFDIV2，FinnGen采用4/(1/Ncase+1/Ncontrol)。对默认all_gene/base基线从官方权重矩阵线性重建，保留审计记录。输出P为正向遗传富集的单侧检验，不能解释为保护/风险方向。', '',
 '疾病定义：PGC AN2019；FinnGen BN R10；广义EDs R7。不同结局存在样本及病例重叠，不作为独立重复研究。空间数据为正常DLPFC参考，不是AN病例、高脂或碳水干预。现有脂肪/碳水MR结果不足以证明膳食经前额叶产生保护。', '']
if full:
    spots=pd.concat(pieces,ignore_index=True)
    assert len(spots)==113927*3
    spots['FDR_all_spots_3_traits']=bh(spots.p)
    spots.to_csv(out/'gsMap_all_spots_AN_BN_EDs.csv.gz',index=False,compression='gzip')
    regions=[]
    for (trait,domain),d in spots.groupby(['trait','domain']):
        donor_p=d.groupby('subject').p.apply(acat)
        loo=[acat(donor_p.drop(subject)) for subject in donor_p.index]
        regions.append({'trait':trait,'domain':domain,'spots':len(d),'donors':len(donor_p),'P_ACAT_all_spots':acat(d.p),'P_ACAT_equal_donors':acat(donor_p),'P_leave_one_donor_out_min':min(loo),'P_leave_one_donor_out_max':max(loo),'median_spot_Z':float(d.z.median())})
    reg=pd.DataFrame(regions)
    reg['FDR_27_regions_traits']=bh(reg.P_ACAT_all_spots)
    reg['Bonferroni_27_regions_traits']=np.minimum(1,reg.P_ACAT_all_spots*len(reg))
    reg['FDR_equal_donor_sensitivity']=bh(reg.P_ACAT_equal_donors)
    reg.to_csv(out/'gsMap_spatial_domains_AN_BN_EDs.csv',index=False,encoding='utf-8-sig')
    report.extend(['gsMap全部90个切片×结局已完成。区域主分析为9个预定义Sp09域×3结局，27项统一BH/Bonferroni校正；保留所有点，不按显著性删点。另报告供者等权和逐供者剔除敏感性结果。不同供者的空间参考分析共享同一GWAS，不是独立GWAS复制。','','```\n'+reg.to_string(index=False)+'\n```',''])
else:
    report.extend(['gsMap全量运行尚未完成；目前切片结果仅用于技术检查，不作为最终脑区定位结论，不对部分切片重新计算最终多重校正。',''])
(out/'01_Brain_localization_report.md').write_text('\n'.join(report),encoding='utf-8-sig')
status={'TWAS_complete':True,'TWAS_tests':50397,'TWAS_significant_gene_tissue_pairs':295,'TWAS_unique_significant_genes':signal_unique,'gsMap_complete':full,'completed_slice_traits':len(completed),'expected_slice_traits':90,'expected_spots':113927,'figures_generated':False}
(out/'analysis_status.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
for name in ['source_files.json','GWAS_formatting.json','baseline_reconstruction.json','batch_regression_equivalence.json']:
    p=root/'audit'/name
    if p.exists():shutil.copy2(p,out/name)
script_dir=out/'scripts';script_dir.mkdir(exist_ok=True)
for p in (root/'scripts').glob('*'):
    if p.is_file():shutil.copy2(p,script_dir/p.name)
with zipfile.ZipFile(out.with_suffix('.zip'),'w',zipfile.ZIP_DEFLATED) as z:
    for p in out.rglob('*'):
        if p.is_file():z.write(p,out.name+'/'+str(p.relative_to(out)))
print(status,flush=True)
