from pathlib import Path
import subprocess,json,sys,time,datetime
root=Path(r'./project/Workspaces\AN_gsMap')
python=root/'runtime/venv/Scripts/python.exe'
manifest=__import__('pandas').read_csv(root/'audit/spatial_slice_manifest.csv')
state_path=root/'audit/run_state.json'
def state(**kwargs):
    kwargs['time']=datetime.datetime.now().isoformat();state_path.write_text(json.dumps(kwargs,indent=2),encoding='utf-8')
try:
    for sample in sorted(manifest['sample']):
        state(status='running',stage='gsMap',current_slice=sample)
        with (root/'logs'/f'{sample}_console.log').open('a',encoding='utf-8') as log:
            result=subprocess.run([str(python),str(root/'scripts/run_gsmap_slices.py'),sample],stdout=log,stderr=subprocess.STDOUT)
        if result.returncode:raise RuntimeError(f'Slice failed: {sample}; see {sample}_console.log')
        result=subprocess.run([str(python),str(root/'scripts/collect_brain_results.py')])
        if result.returncode:raise RuntimeError('Result assembly failed')
    state(status='complete',stage='all_analyses')
except Exception as exc:
    state(status='failed',stage='analysis',error=str(exc))
    raise
