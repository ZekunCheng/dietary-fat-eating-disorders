from pathlib import Path
import pandas as pd, numpy as np, json, re, html, hashlib
from datetime import datetime, timezone
ROOT=Path(r"./project/Workspaces\NHANES_fat_appetite_reanalysis")
OUT=ROOT/"outputs"
AUDIT=ROOT/"audit"
OUT.mkdir(parents=True,exist_ok=True)
CYCLES=[("2005-2006",2005,"D",2),("2007-2008",2007,"E",2),("2009-2010",2009,"F",2),("2011-2012",2011,"G",2),("2013-2014",2013,"H",2),("2015-2016",2015,"I",2),("2017-March2020",2017,"P",3.2),("2021-2023",2021,"L",2)]
DEMO=["SEQN","RIDAGEYR","RIAGENDR","RIDRETH1","RIDRETH3","DMDEDUC2","DMDEDUC3","DMDMARTL","DMDMARTZ","INDFMPIR","RIDEXPRG","SDMVSTRA","SDMVPSU","WTMEC2YR","WTMECPRP"]
DPQ=["SEQN"]+[f"DPQ{i:03}" for i in range(10,100,10)]+["DPQ100"]
BMX=["SEQN","BMXBMI","BMXWT","BMXHT"]
WHQ=["SEQN","WHD010","WHD020","WHD050","WHQ030","WHQ040","WHQ060","WHQ061","WHQ070","WHD080A","WHD080B","WHD080E","WHD080F"]
D1=["SEQN","WTDRD1","WTDR2D","WTDRD1PP","WTDR2DPP","DR1DRSTZ","DR1DAY"]+[f"DR1T{x}" for x in ["KCAL","TFAT","SFAT","MFAT","PFAT","PROT","CARB","ALCO","FIBE"]]
D2=["SEQN","DR2DRSTZ","DR2DAY"]+[f"DR2T{x}" for x in ["KCAL","TFAT","SFAT","MFAT","PFAT","PROT","CARB","ALCO","FIBE"]]
SELECT={"DEMO":DEMO,"DPQ":DPQ,"BMX":BMX,"WHQ":WHQ,"DR1TOT":D1,"DR2TOT":D2}
normrows=[]; schemarows=[]; frames=[]; freqchecks=[]
def load(cycle,suffix,module):
    name=f"P_{module}" if suffix=="P" else f"{module}_{suffix}"
    f=pd.read_sas(ROOT/"raw"/cycle/(name+".xpt"),format="xport")
    # pandas' IBM floating-point decoder may represent SAS numeric zero as ~5e-79.
    for c in f.select_dtypes(include="number"):
        mask=f[c].notna() & (f[c]!=0) & (f[c].abs()<1e-20)
        if mask.any():
            normrows.append(dict(cycle=cycle,file=name,variable=c,n=int(mask.sum()),action="IBM near-zero normalized to numeric zero"))
            f.loc[mask,c]=0.0
    assert f.SEQN.notna().all() and not f.SEQN.duplicated().any()
    f["SEQN"]=f.SEQN.astype("int64")
    available=[c for c in SELECT[module] if c in f]
    for c in SELECT[module]:
        schemarows.append(dict(cycle=cycle,file=name,variable=c,available=c in f))
    if module=="DPQ":
        text=(ROOT/"raw"/cycle/(name+".htm")).read_text(encoding="utf-8-sig")
        m=re.search(r'<h3[^>]*id=["\']DPQ050["\'][^>]*>',text,re.I)
        if not m:
            m=re.search(r'id=["\']DPQ050["\']',text,re.I)
        if not m: raise ValueError("DPQ050 section not found "+name)
        end=text.find("<h3",m.end())
        block=text[m.start():end if end!=-1 else len(text)]
        found={}
        for tr in re.findall(r"<tr\b[^>]*>(.*?)</tr>",block,re.S|re.I):
            td=re.findall(r"<td\b[^>]*>(.*?)</td>",tr,re.S|re.I)
            vals=[html.unescape(re.sub(r"<[^>]+>","",t)).strip() for t in td]
            if len(vals)>=3 and vals[0] in ["0","1","2","3","7","9","."]:
                found[vals[0]]=int(vals[2].replace(",",""))
        if not found: raise ValueError("DPQ050 codebook counts not parsed "+name)
        for code,expected in found.items():
            actual=int(f.DPQ050.isna().sum()) if code=="." else int((f.DPQ050==int(code)).sum())
            freqchecks.append(dict(cycle=cycle,variable="DPQ050",code=code,expected=expected,observed=actual,passed=actual==expected))
            if actual!=expected: raise ValueError(f"codebook count mismatch {name} {code}: {actual}!={expected}")
    return f[available]
for cycle,year,suffix,duration in CYCLES:
    f=load(cycle,suffix,"DEMO")
    for module in ["DPQ","BMX","WHQ","DR1TOT","DR2TOT"]:
        g=load(cycle,suffix,module)
        overlap=(set(f.columns)&set(g.columns))-{"SEQN"}
        assert not overlap, overlap
        f=f.merge(g,on="SEQN",how="left",validate="one_to_one")
    f["cycle"]=cycle
    f["period"]="postpandemic_2021_2023" if suffix=="L" else "prepandemic_2005_March2020"
    f["cycle_duration_years"]=duration
    weight1="WTDRD1PP" if suffix=="P" else "WTDRD1"
    weight2="WTDR2DPP" if suffix=="P" else "WTDR2D"
    for c in [weight1,weight2,"DR1TKCAL","DR1TTFAT","DR1DRSTZ","DR2TKCAL","DR2TTFAT","DR2DRSTZ","DPQ050","SDMVSTRA","SDMVPSU"]:
        if c not in f: raise ValueError(f"required variable absent {cycle} {c}")
    f["diet_weight_day1_original"]=f[weight1]
    f["diet_weight_twoday_original"]=f[weight2]
    factor=duration/15.2 if suffix!="L" else 1
    f["analysis_weight_day1"]=f[weight1]*factor
    f["analysis_weight_twoday"]=f[weight2]*factor
    frames.append(f)
d=pd.concat(frames,ignore_index=True,sort=False)
assert not d.duplicated(["cycle","SEQN"]).any()
d["participant_id"]=d.cycle+"_"+d.SEQN.astype(str)
d["age"]=d.RIDAGEYR
d["sex"]=d.RIAGENDR.map({1:"Male",2:"Female"})
d["race_ethnicity"]=d.RIDRETH1.map({1:"Mexican American",2:"Other Hispanic",3:"Non-Hispanic White",4:"Non-Hispanic Black",5:"Other / Multiracial"})
d["education_adult20_raw"]=d.DMDEDUC2
d["education_adult20"]=d.DMDEDUC2.where(d.DMDEDUC2.isin([1,2,3,4,5]))
d["income_poverty_ratio"]=d.INDFMPIR
d["bmi"]=d.BMXBMI.where(d.BMXBMI>0)
d["adult18"]=d.age.ge(18)
d["adult20"]=d.age.ge(20)
d["known_pregnant"]=d.RIDEXPRG.eq(1)
d["pregnancy_unknown_female20_44"]=d.RIAGENDR.eq(2)&d.age.between(20,44)&(~d.RIDEXPRG.isin([1,2]))
for c in DPQ[1:]:
    d[c+"_raw"]=d[c]
    if c=="DPQ100": d[c]=d[c].where(d[c].isin([0,1,2,3]))
    else: d[c]=d[c].where(d[c].isin([0,1,2,3]))
sym=d.DPQ050.notna()
d["appetite_eating_symptom_freq_ge2"]=d.DPQ050.ge(2).astype(float).where(sym)
d["appetite_eating_symptom_any_ge1"]=d.DPQ050.ge(1).astype(float).where(sym)
d["appetite_eating_symptom_daily"]=d.DPQ050.eq(3).astype(float).where(sym)
d["underweight_bmi_lt18_5"]=d.bmi.lt(18.5).astype(float).where(d.bmi.notna()&d.adult18)
d["symptom_ge2_and_underweight"]=(d.DPQ050.ge(2)&d.bmi.lt(18.5)).astype(float).where(sym&d.bmi.notna()&d.adult18)
phq9=[f"DPQ{i:03}" for i in range(10,100,10)]
phq_except=[c for c in phq9 if c!="DPQ050"]
d["phq9_total"]=d[phq9].sum(axis=1,min_count=9)
# This excludes appetite, unlike the standard PHQ-8 (which excludes suicidality).
d["other_eight_depressive_symptoms_sum"]=d[phq_except].sum(axis=1,min_count=8)
d["other_eight_depressive_symptoms_missing_n"]=d[phq_except].isna().sum(axis=1)
for day in [1,2]:
    prefix=f"DR{day}T"
    kcal=d[prefix+"KCAL"]
    fat=d[prefix+"TFAT"]
    basic=kcal.gt(0)&fat.ge(0)&kcal.notna()&fat.notna()
    pct=900*fat/kcal
    physical=pct.between(0,100)&np.isfinite(pct)
    reliable=d[f"DR{day}DRSTZ"].eq(1)
    valid=basic&physical&reliable
    d[f"valid_day{day}_recall"]=valid
    d[f"day{day}_fat_energy_pct"]=pct.where(valid)
    d[f"day{day}_fat_g"]=fat.where(valid)
    d[f"day{day}_energy_kcal"]=kcal.where(valid)
    sfa=d[prefix+"SFAT"]
    mufa=d[prefix+"MFAT"]
    pufa=d[prefix+"PFAT"]
    d[f"day{day}_unsat_to_sat_ratio"]=((mufa+pufa)/sfa).where(valid&sfa.gt(0)&mufa.ge(0)&pufa.ge(0))
both=d.valid_day1_recall & d.valid_day2_recall
d["twoday_fat_energy_pct"]=(900*(d.DR1TTFAT+d.DR2TTFAT)/(d.DR1TKCAL+d.DR2TKCAL)).where(both)
d["twoday_fat_g_mean"]=((d.DR1TTFAT+d.DR2TTFAT)/2).where(both)
d["twoday_energy_kcal_mean"]=((d.DR1TKCAL+d.DR2TKCAL)/2).where(both)
d["twoday_unsat_to_sat_ratio"]=((d.DR1TMFAT+d.DR2TMFAT+d.DR1TPFAT+d.DR2TPFAT)/(d.DR1TSFAT+d.DR2TSFAT)).where(both&(d.DR1TSFAT+d.DR2TSFAT).gt(0)&d[["DR1TMFAT","DR2TMFAT","DR1TPFAT","DR2TPFAT"]].ge(0).all(axis=1))
design=d.SDMVSTRA.notna()&d.SDMVPSU.notna()
d["valid_survey_design"]=design
d["positive_day1_weight"]=d.analysis_weight_day1.gt(0)&np.isfinite(d.analysis_weight_day1)
d["positive_twoday_weight"]=d.analysis_weight_twoday.gt(0)&np.isfinite(d.analysis_weight_twoday)
# Keep a continuous exposure. No data-driven HFD threshold/quartiles are selected.
d["core_covariates_complete"]=d[["age","sex","race_ethnicity","education_adult20","income_poverty_ratio","bmi"]].notna().all(axis=1)
d["eligible_day1"]=d.adult18&(~d.known_pregnant)&sym&d.valid_day1_recall&d.positive_day1_weight&design
d["eligible_twoday"]=d.eligible_day1&d.valid_day2_recall&d.positive_twoday_weight
d["eligible_lowweight_day1"]=d.eligible_day1&d.bmi.notna()
d["eligible_lowweight_twoday"]=d.eligible_twoday&d.bmi.notna()
d["eligible_day1_covariates_complete"]=d.eligible_day1&d.core_covariates_complete
d["eligible_twoday_covariates_complete"]=d.eligible_twoday&d.core_covariates_complete
checks=[
 ("age_below18",~d.adult18),
 ("known_pregnancy",d.known_pregnant),
 ("missing_or_refused_dpq050",~sym),
 ("unreliable_or_invalid_day1",~d.valid_day1_recall),
 ("nonpositive_day1_weight",~d.positive_day1_weight),
 ("missing_survey_design",~design)]
reason=pd.Series("",index=d.index,dtype="object")
for name,mask in checks:
    reason=reason.mask(mask&reason.eq(""),name)
d["first_exclusion_day1"]=reason.mask(reason.eq(""),"included")
assert d.first_exclusion_day1.eq("included").equals(d.eligible_day1)
flows=[]; summary=[]
for period,group in d.groupby("period",sort=False):
    live=pd.Series(True,index=group.index)
    flows.append(dict(period=period,step="all_demographic_records",excluded=0,remaining=len(group)))
    for name,mask in checks:
        before=int(live.sum())
        live &= ~mask.loc[group.index]
        after=int(live.sum())
        flows.append(dict(period=period,step=name,excluded=before-after,remaining=after))
    assert int(live.sum())==int(group.eligible_day1.sum())
    for cohort,flag in [("day1","eligible_day1"),("twoday","eligible_twoday")]:
        a=group[group[flag]]
        b=a[a.bmi.notna()]
        summary.append(dict(period=period,cohort=cohort,n=len(a),n_symptom_ge2=int(a.appetite_eating_symptom_freq_ge2.sum()),n_bmi_observed=len(b),n_underweight=int(b.underweight_bmi_lt18_5.sum()),n_symptom_and_underweight=int(b.symptom_ge2_and_underweight.sum()),n_core_covariates_complete=int(a.core_covariates_complete.sum()),n_age20plus=int(a.adult20.sum()),n_female20_44_pregnancy_unknown=int(a.pregnancy_unknown_female20_44.sum())))
d.to_csv(OUT/"merged_all_participants_with_flags.csv.gz",index=False,encoding="utf-8-sig",compression="gzip")
for period,short in [("prepandemic_2005_March2020","prepandemic"),("postpandemic_2021_2023","2021_2023")]:
    for cohort,flag in [("day1","eligible_day1"),("twoday","eligible_twoday")]:
        a=d[(d.period==period)&d[flag]]
        a.to_csv(OUT/f"clean_{short}_{cohort}.csv",index=False,encoding="utf-8-sig")
pd.DataFrame(flows).to_csv(OUT/"participant_flow.csv",index=False,encoding="utf-8-sig")
pd.DataFrame(summary).to_csv(OUT/"cohort_summary.csv",index=False,encoding="utf-8-sig")
pd.DataFrame(schemarows).to_csv(AUDIT/"variable_availability_by_cycle.csv",index=False,encoding="utf-8-sig")
pd.DataFrame(normrows).to_csv(AUDIT/"sas_numeric_zero_normalization.csv",index=False,encoding="utf-8-sig")
pd.DataFrame(freqchecks).to_csv(AUDIT/"dpq050_official_frequency_validation.csv",index=False,encoding="utf-8-sig")
ct=[]
for cycle,g in d.groupby("cycle",sort=False):
    a=g[g.eligible_day1]
    ct.append(dict(cycle=cycle,n_demographic=len(g),n_age18=int(g.adult18.sum()),n_valid_dpq050=int(g.DPQ050.notna().sum()),n_day1=len(a),n_symptom_day1=int(a.appetite_eating_symptom_freq_ge2.sum()),n_twoday=int(g.eligible_twoday.sum()),n_symptom_underweight_day1=int(a.symptom_ge2_and_underweight.sum())))
pd.DataFrame(ct).to_csv(OUT/"cycle_summary.csv",index=False,encoding="utf-8-sig")
specific={
 "day1_fat_energy_pct":"Primary continuous exposure: 100 * 9 * DR1TTFAT / DR1TKCAL; reliable day1 only.",
 "twoday_fat_energy_pct":"Two-day sensitivity: 100 * 9 * (DR1TTFAT+DR2TTFAT)/(DR1TKCAL+DR2TKCAL); both days reliable. Ratio of sums, not average of daily ratios.",
 "day1_fat_g":"Total dietary fat, g/day, day1. Supplementary exposure.",
 "twoday_fat_g_mean":"Mean total dietary fat g/day across two reliable days.",
 "day1_unsat_to_sat_ratio":"Supplementary composition exposure: (MUFA+PUFA)/SFA, day1, positive SFA.",
 "twoday_unsat_to_sat_ratio":"Supplementary composition exposure: sum(MUFA+PUFA)/sum(SFA) across two reliable days.",
 "appetite_eating_symptom_freq_ge2":"Primary exploratory symptom: DPQ050 2 or 3 = 1; 0 or 1 = 0; refused/dont know/missing = missing. Cannot identify appetite direction or AN.",
 "appetite_eating_symptom_any_ge1":"Sensitivity symptom: DPQ050 >=1; not AN.",
 "appetite_eating_symptom_daily":"Sensitivity symptom: DPQ050=3; not AN.",
 "underweight_bmi_lt18_5":"Adult BMI<18.5 kg/m2; descriptive underweight, not AN.",
 "symptom_ge2_and_underweight":"Supplementary composite: DPQ050>=2 AND BMI<18.5. Control: all other participants with both observed. Not validated anorexia/AN phenotype.",
 "other_eight_depressive_symptoms_sum":"Sum of all eight OTHER DPQ symptom items, excluding DPQ050; all eight must be observed. Range0-24. Not the standard PHQ-8.",
 "phq9_total":"Complete nine-item score0-27; includes outcome DPQ050. Avoid automatic adjustment for this full score when DPQ050 is the outcome.",
 "analysis_weight_day1":"Day1 dietary weight: original*cycle_duration/15.2 for 2005-March2020; original weight for separate2021-2023. Never use to pool these two periods.",
 "analysis_weight_twoday":"Two-day dietary weight: original*cycle_duration/15.2 for 2005-March2020; original weight for separate2021-2023.",
 "pregnancy_unknown_female20_44":"Females20-44 without a yes/no public pregnancy value; retained and flagged, not certified nonpregnant.",
 "education_adult20":"DMDEDUC2 valid1-5 only. Age18-19 use different education questions; retained but not silently harmonized.",
 "core_covariates_complete":"Age, sex, harmonized RIDRETH1, adult20 education, PIR and BMI all observed; a model-specific flag, not exclusion from base cohort.",
 "eligible_day1":"Age>=18; not known pregnant; valid DPQ050; reliable day1, physical fat energy0-100%, kcal>0,fat>=0; positive day1 weight; observed strata/PSU.",
 "eligible_twoday":"eligible_day1 plus reliable physically valid day2 and positive two-day weight.",
 "participant_id":"cycle+SEQN; join and deduplicate within cycle.",
 "first_exclusion_day1":"First applicable ordered base-cohort exclusion, audit purposes."
}
dictionary=[]
for c in d.columns:
    if c in specific: desc=specific[c]
    elif c.endswith("_raw"): desc="Original public numeric response after correcting IBM numeric-zero decoding. Refusal/dont-know codes preserved."
    elif c.startswith("DPQ"): desc="DPQ numeric frequency item0-3; all other codes missing. Refer to original cycle codebook."
    elif c.startswith(("DR1","DR2","WHD","WHQ","RID","DMD","SDMV","WT","BMX","IND")): desc="Original NHANES public variable; see saved cycle-specific codebook; structural absence/missing retained."
    elif c.startswith("eligible"): desc="Analysis/subgroup eligibility flag; see reproducible cleaning script."
    else: desc="Derived/harmonized field; see cleaning script and README."
    dictionary.append(dict(variable=c,description=desc,nonmissing_n=int(d[c].notna().sum()),dtype=str(d[c].dtype)))
pd.DataFrame(dictionary).to_csv(OUT/"data_dictionary.csv",index=False,encoding="utf-8-sig")
q={
 "created_utc":datetime.now(timezone.utc).isoformat(),
 "n_merged":len(d),"n_cycles":len(CYCLES),
 "unique_cycle_seqn":not d.duplicated(["cycle","SEQN"]).any(),
 "unique_seqn_across_cycles":not d.SEQN.duplicated().any(),
 "all_dpq050_codebook_frequency_checks_passed":all(r["passed"] for r in freqchecks),
 "n_frequency_checks":len(freqchecks),
 "n_numeric_zero_cells_corrected":sum(r["n"] for r in normrows),
 "all_primary_fat_pct_in_0_100":bool(d.loc[d.eligible_day1,"day1_fat_energy_pct"].between(0,100).all()),
 "both_periods_separate":True,
 "no_imputation_performed":True,
 "an_diagnosis_created":False,
 "summary":summary
}
(AUDIT/"cleaning_validation.json").write_text(json.dumps(q,indent=2,ensure_ascii=False),encoding="utf-8")
manifest=[]
for path in OUT.iterdir():
    if path.is_file():
        manifest.append(dict(file=path.name,bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
pd.DataFrame(manifest).to_csv(AUDIT/"cleaned_output_checksums.csv",index=False,encoding="utf-8-sig")
print(json.dumps(q,indent=2,ensure_ascii=False),flush=True)

