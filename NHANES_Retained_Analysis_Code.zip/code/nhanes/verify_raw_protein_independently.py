
from pathlib import Path
import pandas as pd,numpy as np,json
from scipy.special import expit
root=Path(r"./project/Workspaces\NHANES_fat_appetite_reanalysis")
a=root/"analysis"/"2026-10-10";out=a/"original_replication"
d=pd.read_csv(a/"variable_exploration"/"exploration_inputs.csv.gz",keep_default_na=False,na_values=["","NA"],low_memory=False)
r=pd.read_csv(out/"raw_protein_original_style_survey.csv").set_index("label")
checks=[]
levels={"sex":["Male","Female"],"race_ethnicity":["Non-Hispanic White","Non-Hispanic Black","Mexican American","Other Hispanic","Other / Multiracial"],"education_adult20":[1,2,3,4,5],"smoking_status":["Never_100cig","Former","Current"],"alcohol_frequency_group":["Less_than_monthly_or_none","Monthly_less_than_weekly","Weekly_or_more"],"leisure_activity_group":["None","Some_below150","At_least150"]}
for prefix,period in [("pre","prepandemic_2005_March2020"),("post","postpandemic_2021_2023")]:
 for day in ["day1","twoday"]:
  v=d[d.period.eq(period)&d[f"analysis_weight_{day}"].gt(0)].copy()
  v["x"]=v[f"{day}_protein_pct"]/5;v["age10"]=v.age/10;v["bmi5"]=v.bmi/5;v["pir"]=v.income_poverty_ratio
  v["energy1000"]=v["day1_energy_kcal" if day=="day1" else "twoday_energy_kcal_mean"]/1000
  v["w"]=v[f"analysis_weight_{day}"];v["y"]=v.appetite_eating_symptom_freq_ge2
  for model in ["R3","R5_lifestyle"]:
   numeric=["x","age10","bmi5","pir"];cat=["sex","race_ethnicity","education_adult20"]
   if prefix=="pre":cat+=["cycle"]
   if model=="R5_lifestyle":numeric+=["energy1000"];cat+=["smoking_status","alcohol_frequency_group","leisure_activity_group"]
   mask=v[f"eligible_{day}"].eq(True)&v.adult20.eq(True)&v[numeric+cat+["y"]].notna().all(axis=1)
   z=v.loc[mask].copy()
   for col in cat:
    lev=[c for c in levels.get(col,sorted(z[col].unique())) if c in set(z[col])]
    z[col]=pd.Categorical(z[col],categories=lev)
   xframe=pd.get_dummies(z[numeric+cat],columns=cat,drop_first=True,dtype=float)
   X=np.column_stack([np.ones(len(z)),xframe.to_numpy(float)])
   y=z.y.to_numpy(float);w=z.w.to_numpy(float);wn=w/w.mean()
   b=np.zeros(X.shape[1]);pmean=np.average(y,weights=w);b[0]=np.log(pmean/(1-pmean))
   for it in range(60):
    p=expit(X@b);H=X.T@((wn*p*(1-p))[:,None]*X);delta=np.linalg.solve(H,X.T@(wn*(y-p)));b+=delta
    if np.max(np.abs(delta))<1e-10:break
   p=expit(X@b);H=X.T@((w*p*(1-p))[:,None]*X)
   score=X*(w*(y-p))[:,None]
   gf=pd.DataFrame(score);gf["strata"]=z.SDMVSTRA.values;gf["PSU"]=z.SDMVPSU.values
   g=gf.groupby(["strata","PSU"])[list(range(X.shape[1]))].sum()
   ids=pd.MultiIndex.from_frame(v[["SDMVSTRA","SDMVPSU"]].drop_duplicates());g=g.reindex(ids,fill_value=0)
   B=np.zeros_like(H)
   for _,sub in g.groupby(level=0):
    U=sub.to_numpy(copy=True);m=len(U);assert m>1,(label if "label" in locals() else "",prefix,day,model,m,sub.index.tolist())
    U-=U.mean(axis=0);B+=m/(m-1)*U.T@U
   hi=np.linalg.inv(H);V=hi@B@hi
   label=f"{prefix}_{day}_continuous_{model}";rr=r.loc[label]
   assert len(z)==rr.n and int(y.sum())==rr.events
   be=float(abs(b[1]-rr.beta));se=float(np.sqrt(V[1,1]));rel=float(abs(se-rr.se)/rr.se)
   assert be<1e-8 and rel<1e-6,(label,be,rel)
   checks.append({"label":label,"n":len(z),"beta_absolute_difference":be,"SE_relative_difference":rel,"passed":True})
(out/"independent_raw_protein_validation.json").write_text(json.dumps(checks,indent=2),encoding="utf-8")
print(json.dumps(checks,indent=2))

