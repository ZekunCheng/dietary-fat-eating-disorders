
from pathlib import Path
import pandas as pd,json
root=Path(r"./project/Workspaces\NHANES_fat_appetite_reanalysis")
adir=root/"analysis"/"2026-10-10"
new=adir/"variable_exploration"
new.mkdir(exist_ok=True)
plan={"date":"2026-10-10","status":"Additional exploration requested after primary analysis; not original prespecified confirmation","outcome":"DPQ050>=2 unchanged","diet_exposures":["Total fat percent energy per5pp","SFA percent energy per5pp","MUFA percent energy per5pp","PUFA percent energy per5pp","(MUFA+PUFA)/SFA per1","Protein percent energy per5pp","Carbohydrate percent energy per5pp","Fiber grams/day per5g"],"models":["M2 age/sex/race/cycle/education/PIR/energy","M3 M2+smoking/alcohol/leisure_activity"],"datasets":["pre_day1","pre_twoday","post_day1","post_twoday"],"multiplicity":"BH across all64 focal dietary tests; separately BH across existing four M3 non-cycle covariate category contrasts and four M4 BMI contrasts","interpretation":"Conditional cross-sectional associations. Nutrients modeled individually, not formal specified isocaloric substitution. Day1 and two-day overlap; post-period non-overlap does not guarantee transportability. Covariate coefficients not causal effects."}
(new/"exploration_plan.json").write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding="utf-8")
master=pd.read_csv(adir/"inputs"/"survey_analysis_master.csv.gz",keep_default_na=False,na_values=["","NA"])
raw=pd.read_csv(root/"outputs"/"merged_all_participants_with_flags.csv.gz",usecols=["participant_id"]+[f"DR{day}T{x}" for day in [1,2] for x in ["SFAT","MFAT","PFAT","PROT","CARB","FIBE"]])
n=len(master)
master=master.merge(raw,on="participant_id",how="left",validate="one_to_one")
assert len(master)==n
for source,name,k in [("SFAT","sfa",9),("MFAT","mufa",9),("PFAT","pufa",9),("PROT","protein",4),("CARB","carbohydrate",4)]:
    master["day1_"+name+"_pct"]=100*k*master["DR1T"+source]/master.day1_energy_kcal
    master["twoday_"+name+"_pct"]=100*k*(master["DR1T"+source]+master["DR2T"+source])/(2*master.twoday_energy_kcal_mean)
master["day1_fiber_g"]=master.DR1TFIBE
master["twoday_fiber_g"]=(master.DR1TFIBE+master.DR2TFIBE)/2
master.to_csv(new/"exploration_inputs.csv.gz",index=False,compression="gzip")
base=(root/"scripts"/"analyze_survey.R").read_text(encoding="utf-8-sig").split('for(period in c(')[0]
base=base.replace('file.path(adir,"results")','file.path(adir,"variable_exploration")').replace('gzfile(file.path(adir,"inputs","survey_analysis_master.csv.gz"))','gzfile(file.path(adir,"variable_exploration","exploration_inputs.csv.gz"))')
extra=r'''
for(period in c("prepandemic_2005_March2020","postpandemic_2021_2023")){
 short<-if(grepl("^pre",period))"pre" else "post"
 for(day in c("day1","twoday")){
  v<-d[d$period==period,]
  v$w<-v[[paste0("analysis_weight_",day)]]
  v$eligible<-v[[paste0("eligible_",day)]]
  v$energy1000<-v[[if(day=="day1")"day1_energy_kcal" else "twoday_energy_kcal_mean"]]/1000
  v$y<-v$appetite_eating_symptom_freq_ge2
  vars<-c(total_fat="fat_energy_pct",sfa="sfa_pct",mufa="mufa_pct",pufa="pufa_pct",unsat_sat="unsat_to_sat_ratio",protein="protein_pct",carbohydrate="carbohydrate_pct",fiber="fiber_g")
  for(name in names(vars)) v[[paste0("z_",name)]]<-v[[paste0(day,"_",vars[name])]]/if(name=="unsat_sat")1 else 5
  good<-is.finite(v$w)&v$w>0&!is.na(v$SDMVSTRA)&!is.na(v$SDMVPSU)
  v<-v[good,];v$cycle<-droplevels(v$cycle)
  des<-svydesign(ids=~SDMVPSU,strata=~SDMVSTRA,weights=~w,data=v,nest=TRUE)
  base<-v$eligible&v$adult20
  cyc<-if(short=="pre")"+ cycle" else ""
  for(name in names(vars)){
   z<-paste0("z_",name)
   f2<-as.formula(paste("y ~",z,"+ age10 + sex + race_ethnicity",cyc,"+ education + pir + energy1000"))
   f3<-update(f2,.~.+smoking+alcohol+activity)
   unit<-if(name=="unsat_sat")"1 unit ratio" else if(name=="fiber")"5 g/day" else "5 percentage points"
   for(model in c("M2","M3")){
    f<-if(model=="M2")f2 else f3
    add_fit(des,f,base,paste(short,day,name,model,sep="_"),term=z,exposure_unit=unit)
   }
  }
 }
}
r<-do.call(rbind,all_results);stopifnot(nrow(r)==64)
r$BH_q_64<-p.adjust(r$p,method="BH")
write.csv(r,file.path(resdir,"dietary_exploration_64_tests.csv"),row.names=FALSE)
write.csv(do.call(rbind,all_coefs),file.path(resdir,"dietary_all_coefficients.csv"),row.names=FALSE)
write.csv(do.call(rbind,all_diag),file.path(resdir,"dietary_diagnostics.csv"),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(resdir,"R_session_info.txt"))
cat("Completed 64 additional dietary tests; BH q<0.05:",sum(r$BH_q_64<.05),"
")
'''
(root/"scripts"/"explore_variables.R").write_text(base+extra,encoding="utf-8")
print("Saved exploration plan and script before dietary model fitting.")
