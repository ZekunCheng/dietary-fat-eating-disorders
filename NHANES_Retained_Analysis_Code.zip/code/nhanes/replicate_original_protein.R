
options(stringsAsFactors=FALSE)
.libPaths(c("./project/Workspaces/NHANES_fat_appetite_reanalysis/runtime/R-library",.libPaths()))
suppressPackageStartupMessages(library(survey))
options(survey.lonely.psu="adjust",survey.adjust.domain.lonely=TRUE)
root<-"./project/Workspaces/NHANES_fat_appetite_reanalysis"
out<-file.path(root,"analysis","2026-10-10","original_replication")
d<-read.csv(file.path(out,"legacy_input.csv"),check.names=FALSE)
d$sex<-factor(d$sex);d$eth<-factor(d$eth);d$edu<-factor(d$edu)
forms<-list(M1=y~x,M2=y~x+ageyr+sex+eth,M3=y~x+ageyr+sex+eth+BMI+poverty+edu)
legacy<-list()
add_legacy<-function(v,f,label,unit,term="x"){
 fit<-glm(f,data=v,family=binomial(),control=list(epsilon=1e-12,maxit=60))
 co<-coef(summary(fit));inds<-if(term=="quartile")grep("^quartile",rownames(co)) else match(term,rownames(co))
 for(j in inds){
  b<-co[j,1];se<-co[j,2];OR<-exp(b)
  legacy[[length(legacy)+1]]<<-data.frame(label=label,term=rownames(co)[j],n=nobs(fit),events=sum(model.response(model.frame(fit))),beta=b,se=se,OR=OR,ci_low=exp(b-qnorm(.975)*se),ci_high=exp(b+qnorm(.975)*se),legacy_delta_ci_low=OR-qnorm(.975)*OR*se,legacy_delta_ci_high=OR+qnorm(.975)*OR*se,p=co[j,4],unit=unit,formula=paste(deparse(f),collapse=" "))
 }
}
scores<-c(total_HEI="hei2015_total_score",total_protein_foods="totprot",seafood_plant_score="seaplant_prot",fatty_acid_score="fattyacid")
for(name in names(scores)){
 v<-d;v$x<-v[[scores[name]]]
 for(m in names(forms)){
  add_legacy(v,forms[[m]],paste(name,m,sep="_"),"1 score point")
  for(sex in levels(v$sex)){
   sub<-v[v$sex==sex,];f<-if(m=="M1")forms[[m]] else update(forms[[m]],.~.-sex)
   add_legacy(sub,f,paste(name,sex,m,sep="_"),"1 score point")
  }
 }
}
v<-d;v$x<-as.numeric(scale(v$protein))
for(m in names(forms)){
 add_legacy(v,forms[[m]],paste0("transformed_protein_SD_",m),"1 SD transformed protein column; not g/day")
 for(sex in levels(v$sex)){
  sub<-v[v$sex==sex,];f<-if(m=="M1")forms[[m]] else update(forms[[m]],.~.-sex)
  add_legacy(sub,f,paste("transformed_protein_SD",sex,m,sep="_"),"1 SD transformed protein; not g/day")
 }
}
components<-c(totalveg="hei2015c1_totalveg",green_and_bean="hei2015c2_green_and_bean",totalfruit="hei2015c3_totalfruit",wholefruit="hei2015c4_wholefruit",wholegrain="hei2015c5_wholegrain",totaldairy="hei2015c6_totaldairy",totprot="hei2015c7_totprot",seaplant_prot="hei2015c8_seaplant_prot",fattyacid="hei2015c9_fattyacid",sodium="hei2015c10_sodium",refinedgrain="hei2015c11_refinedgrain",sfat="hei2015c12_sfat",addsug="hei2015c13_addsug")
for(name in names(components)){
 v<-d;v$x<-v[[name]]
 add_legacy(v,y~x,paste0("component_",components[name]),"1 HEI component point")
}
cutrows<-list()
for(name in c("total_HEI","transformed_protein")){
 v<-d;v$x<-v[[if(name=="total_HEI")"hei2015_total_score" else "protein"]]
 qs<-quantile(v$x,c(.25,.5,.75),na.rm=TRUE)
 v$quartile<-cut(v$x,breaks=c(-Inf,qs,Inf),labels=paste0("Q",1:4),include.lowest=TRUE)
 v$trend_rank<-as.integer(v$quartile)
 meds<-tapply(v$x,v$quartile,median);v$trend_median<-meds[as.character(v$quartile)]
 cutrows[[length(cutrows)+1]]<-data.frame(label=name,q25=qs[1],q50=qs[2],q75=qs[3],weighted=FALSE)
 for(m in names(forms)){
  add_legacy(v,update(forms[[m]],.~.-x+quartile),paste(name,"quartile",m,sep="_"),"Q2/Q3/Q4 vsQ1",term="quartile")
  add_legacy(v,update(forms[[m]],.~.-x+trend_rank),paste(name,"rank_trend",m,sep="_"),"quartile rank",term="trend_rank")
  add_legacy(v,update(forms[[m]],.~.-x+trend_median),paste(name,"median_trend",m,sep="_"),"quartile median",term="trend_median")
 }
}
v<-d;v$x<-as.integer(v$totprot>=5-1e-10)
for(m in names(forms))add_legacy(v,forms[[m]],paste0("total_protein_foods_fullscore_",m),"HEI score5 vs below5; ceiling prevents balanced quartiles")
l<-do.call(rbind,legacy)
write.csv(l,file.path(out,"legacy_replication_and_protein.csv"),row.names=FALSE)
write.csv(do.call(rbind,cutrows),file.path(out,"legacy_cutpoints.csv"),row.names=FALSE)
cat("LEGACY MAIN\n");print(l[l$label %in% c("total_HEI_M1","total_HEI_M2","total_HEI_M3","total_protein_foods_M1","total_protein_foods_M2","total_protein_foods_M3","transformed_protein_SD_M3"),c("label","OR","ci_low","ci_high","p")])
# Raw protein: comparable original model progression with verified survey design.
d<-read.csv(gzfile(file.path(root,"analysis","2026-10-10","variable_exploration","exploration_inputs.csv.gz")),na.strings=c("","NA"),check.names=FALSE)
for(n in c("adult18","adult20","eligible_day1","eligible_twoday"))d[[n]]<-as.logical(d[[n]])
d$sex<-factor(d$sex,levels=c("Male","Female"))
d$race_ethnicity<-factor(d$race_ethnicity,levels=c("Non-Hispanic White","Non-Hispanic Black","Mexican American","Other Hispanic","Other / Multiracial"))
d$education<-factor(d$education_adult20,levels=1:5)
d$smoking<-factor(d$smoking_status,levels=c("Never_100cig","Former","Current"))
d$alcohol<-factor(d$alcohol_frequency_group,levels=c("Less_than_monthly_or_none","Monthly_less_than_weekly","Weekly_or_more"))
d$activity<-factor(d$leisure_activity_group,levels=c("None","Some_below150","At_least150"))
d$cycle<-factor(d$cycle);d$age10<-d$age/10;d$pir<-d$income_poverty_ratio;d$bmi5<-d$bmi/5
results<-list();diags<-list();cutrows<-list();tests<-list()
add<-function(des,f,mask,label,term="x",unit="5 percentage points"){
 cc<-complete.cases(model.frame(f,data=des$variables,na.action=na.pass))
 des$variables$ok<-mask&cc;des$variables$ok[is.na(des$variables$ok)]<-FALSE
 ds<-subset(des,ok)
 fit<-svyglm(f,design=ds,family=quasibinomial(),control=list(epsilon=1e-12,maxit=80))
 df<-degf(ds);b<-coef(fit);se<-sqrt(diag(vcov(fit)));crit<-qt(.975,df)
 inds<-if(term=="quartile")grep("^quartile",names(b)) else match(term,names(b))
 for(j in inds)results[[length(results)+1]]<<-data.frame(label=label,term=names(b)[j],n=nrow(ds$variables),events=sum(ds$variables$y),OR=exp(b[j]),ci_low=exp(b[j]-crit*se[j]),ci_high=exp(b[j]+crit*se[j]),p=2*pt(abs(b[j]/se[j]),df,lower.tail=FALSE),beta=b[j],se=se[j],design_df=df,unit=unit,formula=paste(deparse(f),collapse=" "))
 diags[[length(diags)+1]]<<-data.frame(label=label,n=nrow(ds$variables),events=sum(ds$variables$y),converged=fit$converged,design_df=df)
 list(fit=fit,design=ds,mask=des$variables$ok)
}
wq<-function(x,w,p){j<-is.finite(x)&is.finite(w)&w>0;x<-x[j];w<-w[j];o<-order(x);approx(cumsum(w[o])/sum(w[o]),x[o],xout=p,rule=2,ties="ordered")$y}
for(period in c("prepandemic_2005_March2020","postpandemic_2021_2023")){
 short<-if(grepl("^pre",period))"pre" else "post"
 for(day in c("day1","twoday")){
  v<-d[d$period==period,];v$w<-v[[paste0("analysis_weight_",day)]]
  v$y<-v$appetite_eating_symptom_freq_ge2;v$x<-v[[paste0(day,"_protein_pct")]]/5
  v$protein20<-if(day=="day1")v$DR1TPROT/20 else (v$DR1TPROT+v$DR2TPROT)/40
  v$energy1000<-v[[if(day=="day1")"day1_energy_kcal" else "twoday_energy_kcal_mean"]]/1000
  v$eligible<-v[[paste0("eligible_",day)]]
  v<-v[is.finite(v$w)&v$w>0&!is.na(v$SDMVPSU)&!is.na(v$SDMVSTRA),]
  v$cycle<-droplevels(v$cycle);cyc<-if(short=="pre")"+cycle" else ""
  des<-svydesign(ids=~SDMVPSU,strata=~SDMVSTRA,weights=~w,data=v,nest=TRUE)
  fs<-list(R1=y~x,R2=as.formula(paste("y~x+age10+sex+race_ethnicity",cyc)))
  fs$R3<-update(fs$R2,.~.+bmi5+pir+education)
  fs$R4_energy<-update(fs$R3,.~.+energy1000)
  fs$R5_lifestyle<-update(fs$R4_energy,.~.+smoking+alcohol+activity)
  prefix<-paste(short,day,sep="_");base<-v$eligible
  fits<-list()
  for(m in names(fs))fits[[m]]<-add(des,fs[[m]],if(m %in% c("R1","R2"))base else base&v$adult20,paste(prefix,"continuous",m,sep="_"))
  # Match all progressive adjustments on the same fully adjusted sample.
  for(m in names(fs))add(des,fs[[m]],fits$R5_lifestyle$mask,paste(prefix,"sameCC",m,sep="_"))
  qs<-wq(v$x[base]*5,v$w[base],c(.25,.5,.75))
  des$variables$quartile<-cut(v$x*5,breaks=c(-Inf,qs,Inf),labels=paste0("Q",1:4))
  cutrows[[length(cutrows)+1]]<-data.frame(label=prefix,q25=qs[1],q50=qs[2],q75=qs[3],weighted=TRUE)
  med<-sapply(paste0("Q",1:4),function(q){j<-base&des$variables$quartile==q;j[is.na(j)]<-FALSE;wq(v$x[j]*5,v$w[j],.5)})
  des$variables$trend_median5<-med[as.character(des$variables$quartile)]/5
  for(m in c("R1","R2","R3","R4_energy","R5_lifestyle")){
   mask<-if(m %in% c("R1","R2"))base else base&v$adult20
   add(des,update(fs[[m]],.~.-x+quartile),mask,paste(prefix,"quartile",m,sep="_"),term="quartile",unit="Q2/Q3/Q4 vsQ1 protein energy percent")
   add(des,update(fs[[m]],.~.-x+trend_median5),mask,paste(prefix,"trend",m,sep="_"),term="trend_median5",unit="5pp quartile weighted median")
  }
  for(m in c("R3","R4_energy","R5_lifestyle")){
   for(sx in levels(v$sex)){
    mask<-base&v$adult20&v$sex==sx
    add(des,update(fs[[m]],.~.-sex),mask,paste(prefix,sx,m,sep="_"))
   }
   add(des,update(fs[[m]],.~.-x+protein20),base&v$adult20,paste(prefix,"grams",m,sep="_"),term="protein20",unit="20 g/day")
  }
  inter<-add(des,update(fs$R4_energy,.~.+x:sex),base&v$adult20,paste0(prefix,"_sexinteraction"),term="x:sexFemale",unit="interaction")
  it<-regTermTest(inter$fit,~x:sex,df=degf(inter$design))
  tests[[length(tests)+1]]<-data.frame(label=paste0(prefix,"_sexinteraction"),p=it$p,df_den=degf(inter$design))
 }
}
r<-do.call(rbind,results)
r$BH_q_protein_all_focal<-p.adjust(r$p,"BH")
write.csv(r,file.path(out,"raw_protein_original_style_survey.csv"),row.names=FALSE)
write.csv(do.call(rbind,diags),file.path(out,"raw_model_diagnostics.csv"),row.names=FALSE)
write.csv(do.call(rbind,cutrows),file.path(out,"raw_protein_weighted_cutpoints.csv"),row.names=FALSE)
write.csv(do.call(rbind,tests),file.path(out,"raw_protein_sex_interaction.csv"),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,"R_session_info.txt"))
cat("RAW PROTEIN MAIN\n");print(r[grepl("pre_.*continuous",r$label),c("label","n","OR","ci_low","ci_high","p")])
cat("Completed legacy replication and analogous raw-protein models.\n")
