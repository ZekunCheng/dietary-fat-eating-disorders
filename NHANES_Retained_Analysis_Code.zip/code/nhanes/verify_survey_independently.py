from pathlib import Path
import pandas as pd, numpy as np, json
from scipy.special import expit
ROOT=Path("./project/Workspaces/NHANES_fat_appetite_reanalysis")
A=ROOT/"analysis"/"2026-10-10"
allv=pd.read_csv(A/"inputs"/"survey_analysis_master.csv.gz",low_memory=False)
co=pd.read_csv(A/"results"/"all_model_coefficients.csv")
validation=[]
for prefix,period in [("pre","prepandemic_2005_March2020"),("post","postpandemic_2021_2023")]:
 for day in ["day1","twoday"]:
    label=f"{prefix}_{day}_M2"
    z=pd.read_csv(A/"validation"/f"{label}_matrix.csv")
    xcols=list(z.columns[6:])
    X=z[xcols].to_numpy(float);y=z.y.to_numpy(float);w=z.w.to_numpy(float)
    wn=w/w.mean()
    b=np.zeros(X.shape[1]);b[0]=np.log(np.average(y,weights=w)/(1-np.average(y,weights=w)))
    def loss(beta): return np.sum(wn*(np.logaddexp(0,X@beta)-y*(X@beta)))
    for it in range(60):
        p=expit(X@b)
        score=X.T@(wn*(y-p))
        H=X.T@((wn*p*(1-p))[:,None]*X)
        delta=np.linalg.solve(H,score)
        scale=1
        old=loss(b)
        while loss(b+scale*delta)>old+1e-8 and scale>1e-6: scale*=.5
        b+=scale*delta
        if np.max(np.abs(scale*delta))<1e-10:break
    rb=co[co.label==label].set_index("term").loc[xcols,"beta"].to_numpy()
    beta_err=float(np.max(np.abs(b-rb)))
    assert beta_err<2e-6,(label,beta_err)
    # Taylor-linearized score sandwich, summed at PSU within original strata.
    p=z.p.to_numpy(float)
    score=X*(w*(y-p))[:,None]
    H=X.T@((w*p*(1-p))[:,None]*X)
    grouped=pd.DataFrame(score,columns=xcols)
    grouped["SDMVSTRA"]=z.SDMVSTRA.to_numpy();grouped["SDMVPSU"]=z.SDMVPSU.to_numpy()
    cluster=grouped.groupby(["SDMVSTRA","SDMVPSU"])[xcols].sum()
    full=allv[(allv.period==period)&allv[f"analysis_weight_{day}"].gt(0)]
    ids=pd.MultiIndex.from_frame(full[["SDMVSTRA","SDMVPSU"]].drop_duplicates())
    cluster=cluster.reindex(ids,fill_value=0)
    meat=np.zeros_like(H)
    for stra,g in cluster.groupby(level=0):
        U=g.to_numpy()
        m=len(U);assert m>1
        centered=U-U.mean(axis=0)
        meat+=m/(m-1)*(centered.T@centered)
    inv=np.linalg.inv(H)
    V=inv@meat@inv
    rv=pd.read_csv(A/"validation"/f"{label}_R_covariance.csv",index_col=0)
    rv=rv.loc[xcols,xcols].to_numpy(float)
    diagrel=float(np.max(np.abs(np.diag(V)-np.diag(rv))/np.maximum(np.diag(rv),1e-15)))
    assert diagrel<2e-5,(label,diagrel)
    i=xcols.index("x5")
    validation.append({"model":label,"n":len(z),"weighted_logistic_beta_max_difference":beta_err,"Taylor_covariance_diag_max_relative_difference":diagrel,"independent_se_fat5":float(np.sqrt(V[i,i])),"passed":True})
(A/"validation"/"independent_survey_verification.json").write_text(json.dumps(validation,indent=2),encoding="utf-8")
print(json.dumps(validation,indent=2))

