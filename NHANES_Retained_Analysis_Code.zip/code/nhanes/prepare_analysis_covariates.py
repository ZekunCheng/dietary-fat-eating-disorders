from pathlib import Path
import pandas as pd, numpy as np, json
ROOT=Path("./project/Workspaces/NHANES_fat_appetite_reanalysis")
A=ROOT/"analysis"/"2026-10-10"
(A/"inputs").mkdir(parents=True,exist_ok=True)
(A/"results").mkdir(parents=True,exist_ok=True)
d=pd.read_csv(ROOT/"outputs"/"merged_all_participants_with_flags.csv.gz",low_memory=False)
cycles=[("2005-2006","D"),("2007-2008","E"),("2009-2010","F"),("2011-2012","G"),("2013-2014","H"),("2015-2016","I"),("2017-March2020","P"),("2021-2023","L")]
cv=[]
for cycle,suffix in cycles:
    tables=[]
    for module in ["SMQ","ALQ","PAQ"]:
        name=f"P_{module}" if suffix=="P" else f"{module}_{suffix}"
        f=pd.read_sas(ROOT/"raw"/cycle/(name+".xpt"),format="xport")
        for col in f.select_dtypes(include="number"):
            f.loc[f[col].notna()&(f[col]!=0)&(f[col].abs()<1e-20),col]=0
        for col in f.select_dtypes(include="object"):
            f[col]=f[col].map(lambda z:z.decode("utf-8").strip() if isinstance(z,bytes) else z)
        assert not f.SEQN.duplicated().any()
        f.SEQN=f.SEQN.astype(int)
        tables.append(f)
    f=tables[0].merge(tables[1],on="SEQN",how="outer",validate="one_to_one").merge(tables[2],on="SEQN",how="outer",validate="one_to_one")
    f["cycle"]=cycle
    cv.append(f)
cov=pd.concat(cv,ignore_index=True,sort=False)
assert not cov.duplicated(["cycle","SEQN"]).any()
d=d.merge(cov,on=["cycle","SEQN"],how="left",validate="one_to_one")
d["smoking_status"]=pd.Series(np.nan,index=d.index,dtype="object")
d.loc[d.SMQ020.eq(2),"smoking_status"]="Never_100cig"
d.loc[d.SMQ020.eq(1)&d.SMQ040.eq(3),"smoking_status"]="Former"
d.loc[d.SMQ020.eq(1)&d.SMQ040.isin([1,2]),"smoking_status"]="Current"
annual=pd.Series(np.nan,index=d.index,dtype=float)
old=~d.cycle.isin(["2017-March2020","2021-2023"])
q=d.ALQ120Q.where(d.ALQ120Q.between(0,365))
units=d.ALQ120U.map({1:365.25/7,2:12,3:1})
annual.loc[old]=q.loc[old]*units.loc[old]
annual.loc[old&q.eq(0)]=0
# <12 lifetime drinks implies <monthly drinking, but does NOT imply abstinence.
annual.loc[old&d.ALQ110.eq(2)]=0.01
new=~old
annual.loc[new&d.ALQ111.eq(2)]=0
newcat=d.ALQ121
d["alcohol_frequency_group"]=pd.Series(np.nan,index=d.index,dtype="object")
d.loc[old&annual.lt(12),"alcohol_frequency_group"]="Less_than_monthly_or_none"
d.loc[old&annual.ge(12)&annual.lt(365.25/7),"alcohol_frequency_group"]="Monthly_less_than_weekly"
d.loc[old&annual.ge(365.25/7),"alcohol_frequency_group"]="Weekly_or_more"
d.loc[new&(d.ALQ111.eq(2)|newcat.isin([0,8,9,10])),"alcohol_frequency_group"]="Less_than_monthly_or_none"
d.loc[new&newcat.isin([6,7]),"alcohol_frequency_group"]="Monthly_less_than_weekly"
d.loc[new&newcat.isin([1,2,3,4,5]),"alcohol_frequency_group"]="Weekly_or_more"
def old_activity(yes_col,days_col,mins_col):
    active=d[yes_col]
    days=d[days_col].where(d[days_col].between(1,7))
    minutes=d[mins_col].where(d[mins_col].gt(0)&d[mins_col].lt(1440))
    value=(days*minutes).where(active.eq(1))
    return value.mask(active.eq(2),0)
vig=old_activity("PAQ650","PAQ655","PAD660")
mod=old_activity("PAQ665","PAQ670","PAD675")
def new_activity(qcol,ucol,mcol):
    q=d[qcol].where(d[qcol].between(0,365))
    u=d[ucol].map({"D":7,"W":1,"M":12/52.1775,"Y":1/52.1775})
    minutes=d[mcol].where(d[mcol].gt(0)&d[mcol].lt(1440))
    return (q*u*minutes).mask(q.eq(0),0)
post=d.cycle.eq("2021-2023")
mod.loc[post]=new_activity("PAD790Q","PAD790U","PAD800").loc[post]
vig.loc[post]=new_activity("PAD810Q","PAD810U","PAD820").loc[post]
d["leisure_moderate_equiv_minutes_week"]=(mod+2*vig).where((mod+vig).lt(10080))
d["leisure_activity_group"]=pd.Series(np.nan,index=d.index,dtype="object")
z=d.leisure_moderate_equiv_minutes_week
d.loc[z.eq(0),"leisure_activity_group"]="None"
d.loc[z.gt(0)&z.lt(150),"leisure_activity_group"]="Some_below150"
d.loc[z.ge(150),"leisure_activity_group"]="At_least150"
base=[
"SEQN","participant_id","cycle","period","SDMVSTRA","SDMVPSU","age","sex","race_ethnicity","education_adult20","income_poverty_ratio","bmi","adult18","adult20","known_pregnant","pregnancy_unknown_female20_44",
"DPQ050","appetite_eating_symptom_freq_ge2","appetite_eating_symptom_any_ge1","appetite_eating_symptom_daily","underweight_bmi_lt18_5","symptom_ge2_and_underweight","other_eight_depressive_symptoms_sum","phq9_total",
"day1_fat_energy_pct","day1_fat_g","day1_energy_kcal","day1_unsat_to_sat_ratio","twoday_fat_energy_pct","twoday_fat_g_mean","twoday_energy_kcal_mean","twoday_unsat_to_sat_ratio",
"analysis_weight_day1","analysis_weight_twoday","diet_weight_day1_original","diet_weight_twoday_original",
"eligible_day1","eligible_twoday","eligible_lowweight_day1","eligible_lowweight_twoday",
"smoking_status","alcohol_frequency_group","leisure_moderate_equiv_minutes_week","leisure_activity_group"]
d[base].to_csv(A/"inputs"/"survey_analysis_master.csv.gz",index=False,encoding="utf-8",compression="gzip")
cov.to_csv(A/"inputs"/"merged_covariates_raw.csv.gz",index=False,encoding="utf-8",compression="gzip")
audit=[]
for cycle,g in d.groupby("cycle",sort=False):
    sub=g[g.eligible_day1&g.adult20]
    row={"cycle":cycle,"n_day1_age20":len(sub)}
    for c in ["smoking_status","alcohol_frequency_group","leisure_activity_group"]:
        row[c+"_observed_n"]=int(sub[c].notna().sum())
        for value,n in sub[c].value_counts(dropna=False).items(): row[c+"_"+str(value)]=int(n)
    audit.append(row)
pd.DataFrame(audit).to_csv(A/"results"/"covariate_harmonization_audit.csv",index=False,encoding="utf-8-sig")
rules={
"smoking":"100 lifetime cigarettes: SMQ020=2 never; SMQ020=1 & SMQ040=3 former; SMQ020=1 & SMQ040=1/2 current; otherwise missing.",
"alcohol":"Comparable frequency groups <monthly/none, monthly<weekly, weekly+. Earlier ALQ120Q/U converted to days/year; ALQ110=2 (<12 drinks lifetime) classified <monthly, not as lifetime abstainer. Later ALQ121 categories mapped; ALQ111=2 no lifetime drinks mapped first group. Refusal/dontknow missing.",
"activity":"Leisure only: moderate minutes/week + 2*vigorous minutes/week, categorized 0, >0<150, >=150. Earlier PAQ650/665 yes/no with days/minutes;2021-2023 PAD790/PAD810 frequency and D/W/M/Y units.2005-2006 unavailable in this comparable definition. Structural skip after explicit No/zero coded zero; other missing not zero.",
"missing":"No imputation; preserve older raw columns and note differences in instrument wording.",
"n_after_join":len(d)
}
(A/"inputs"/"covariate_rules.json").write_text(json.dumps(rules,indent=2),encoding="utf-8")
print(pd.DataFrame(audit)[["cycle","n_day1_age20","smoking_status_observed_n","alcohol_frequency_group_observed_n","leisure_activity_group_observed_n"]].to_string(index=False))

