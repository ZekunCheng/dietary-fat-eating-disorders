from pathlib import Path
import requests, pandas as pd, hashlib, json, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
ROOT=Path(r"./project/Workspaces\NHANES_fat_appetite_reanalysis")
CYCLES=[("2005-2006",2005,"D",2),("2007-2008",2007,"E",2),("2009-2010",2009,"F",2),("2011-2012",2011,"G",2),("2013-2014",2013,"H",2),("2015-2016",2015,"I",2),("2017-March2020",2017,"P",3.2),("2021-2023",2021,"L",2)]
MODULES=["DEMO","DPQ","DR1TOT","DR2TOT","BMX","WHQ"]
def get_file(task):
    cycle,year,suffix,duration,module=task
    name=f"P_{module}" if suffix=="P" else f"{module}_{suffix}"
    folder=ROOT/"raw"/cycle
    folder.mkdir(parents=True,exist_ok=True)
    url=f"https://wwwn.cdc.gov/Nchs/Data/Nhanes/Public/{year}/DataFiles/{name}.xpt"
    dest=folder/f"{name}.xpt"
    ses=requests.Session()
    ses.trust_env=False
    for attempt in range(3):
        try:
            if dest.exists() and dest.read_bytes().startswith(b"HEADER RECORD"):
                data=dest.read_bytes()
            else:
                r=ses.get(url,timeout=(15,60))
                r.raise_for_status()
                data=r.content
                if not data.startswith(b"HEADER RECORD"):
                    raise ValueError(f"not XPT: {r.headers.get('content-type')} {data[:40]!r}")
                tmp=dest.with_suffix(".download")
                tmp.write_bytes(data)
                tmp.replace(dest)
            frame=pd.read_sas(dest,format="xport")
            if "SEQN" not in frame or frame.SEQN.isna().any() or frame.SEQN.duplicated().any():
                raise ValueError("invalid participant identifiers")
            doc_url=url[:-4]+".htm"
            doc_path=folder/f"{name}.htm"
            doc_status="cached"
            if not doc_path.exists():
                dr=ses.get(doc_url,timeout=(15,45))
                dr.raise_for_status()
                if name not in dr.text or "Variable Name" not in dr.text:
                    raise ValueError("invalid codebook HTML")
                doc_path.write_bytes(dr.content)
                doc_status="downloaded"
            return dict(cycle=cycle,year=year,suffix=suffix,duration_years=duration,module=module,file=name,path=str(dest),url=url,codebook_url=doc_url,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),n_rows=len(frame),n_columns=len(frame.columns),columns="|".join(frame.columns),verified_utc=datetime.now(timezone.utc).isoformat(),status="verified")
        except Exception as e:
            if attempt==2:
                return dict(cycle=cycle,module=module,file=name,url=url,status="failed",error=f"{type(e).__name__}: {e}")
            time.sleep(1+attempt)
tasks=[(*c,m) for c in CYCLES for m in MODULES]
(ROOT/"audit").mkdir(parents=True,exist_ok=True)
rows=[]
with ThreadPoolExecutor(max_workers=4) as pool:
    futures=[pool.submit(get_file,t) for t in tasks]
    for f in as_completed(futures):
        row=f.result()
        rows.append(row)
        pd.DataFrame(rows).sort_values(["cycle","module"]).to_csv(ROOT/"audit"/"download_manifest.csv",index=False,encoding="utf-8-sig")
        print(f"{len(rows)}/{len(tasks)} {row['file']} {row['status']} {row.get('n_rows','')} {row.get('error','')}",flush=True)
fail=[r for r in rows if r["status"]!="verified"]
print(json.dumps({"verified":len(rows)-len(fail),"failed":len(fail),"root":str(ROOT)},ensure_ascii=False),flush=True)
if fail: raise SystemExit(1)

