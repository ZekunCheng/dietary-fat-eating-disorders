options(stringsAsFactors=FALSE)
.libPaths(c("./project/Workspaces/NHANES_fat_appetite_reanalysis/runtime/R-library",.libPaths()))
suppressPackageStartupMessages(library(survey))
options(survey.lonely.psu="adjust",survey.adjust.domain.lonely=TRUE)
root <- "./project/Workspaces/NHANES_fat_appetite_reanalysis"
adir <- file.path(root,"analysis","2026-10-10")
resdir <- file.path(adir,"results")
dir.create(resdir,recursive=TRUE,showWarnings=FALSE)
d <- read.csv(gzfile(file.path(adir,"inputs","survey_analysis_master.csv.gz")),check.names=FALSE,na.strings=c("","NA"))
for(n in c("adult18","adult20","eligible_day1","eligible_twoday","known_pregnant","pregnancy_unknown_female20_44")) d[[n]] <- as.logical(d[[n]])
d$sex <- factor(d$sex,levels=c("Male","Female"))
d$race_ethnicity <- factor(d$race_ethnicity,levels=c("Non-Hispanic White","Non-Hispanic Black","Mexican American","Other Hispanic","Other / Multiracial"))
d$education <- factor(d$education_adult20,levels=1:5)
d$smoking <- factor(d$smoking_status,levels=c("Never_100cig","Former","Current"))
d$alcohol <- factor(d$alcohol_frequency_group,levels=c("Less_than_monthly_or_none","Monthly_less_than_weekly","Weekly_or_more"))
d$activity <- factor(d$leisure_activity_group,levels=c("None","Some_below150","At_least150"))
d$cycle <- factor(d$cycle)
d$age10 <- d$age/10
d$pir <- d$income_poverty_ratio
d$bmi5 <- d$bmi/5
d$other_dep5 <- d$other_eight_depressive_symptoms_sum/5
all_results <- list(); all_coefs <- list(); all_diag <- list(); desc_results <- list(); curves <- list(); tests <- list(); cuts <- list()
fit_store <- list()
weighted_quantile <- function(x,w,p){
 ok<-is.finite(x)&is.finite(w)&w>0
 x<-x[ok];w<-w[ok];o<-order(x); x<-x[o];w<-w[o]
 approx(cumsum(w)/sum(w),x,xout=p,rule=2,ties="ordered")$y
}
add_fit <- function(des,formula,base_mask,label,term="x5",exposure_unit="5 percentage points",subset_extra=NULL){
 v<-des$variables
 cc<-complete.cases(model.frame(formula,data=v,na.action=na.pass))
 mask<-base_mask & cc
 if(!is.null(subset_extra)) mask <- mask & subset_extra
 mask[is.na(mask)]<-FALSE
 des$variables$model_ok<-mask
 subdes<-subset(des,model_ok)
 warning_text<-character()
 fit<-withCallingHandlers(svyglm(formula,design=subdes,family=quasibinomial(),control=list(maxit=80,epsilon=1e-12)),
 warning=function(w){warning_text<<-c(warning_text,conditionMessage(w));invokeRestart("muffleWarning")})
 df<-degf(subdes)
 b<-coef(fit); vc<-vcov(fit); se<-sqrt(diag(vc)); z<-b/se
 p<-2*pt(abs(z),df=df,lower.tail=FALSE)
 crit<-qt(.975,df)
 co<-data.frame(label=label,term=names(b),beta=unname(b),se=unname(se),OR=exp(unname(b)),ci_low=exp(unname(b)-crit*se),ci_high=exp(unname(b)+crit*se),p=unname(p),design_df=df)
 all_coefs[[length(all_coefs)+1]]<<-co
 idx<-which(names(b)==term)
 if(length(idx)==1){
 row<-co[idx,]
 row$n<-nrow(subdes$variables);row$events<-sum(subdes$variables$y);row$exposure_unit<-exposure_unit
 row$formula<-paste(deparse(formula),collapse=" ")
 row$weighted_prevalence<-as.numeric(svymean(~y,subdes))
 row$converged<-fit$converged
 all_results[[length(all_results)+1]]<<-row
 }
 all_diag[[length(all_diag)+1]]<<-data.frame(label=label,n=nrow(subdes$variables),events=sum(subdes$variables$y),rank=fit$rank,design_df=df,converged=fit$converged,min_fitted=min(fitted(fit)),max_fitted=max(fitted(fit)),warnings=paste(unique(warning_text),collapse=" | "))
 cat(label," n=",nrow(subdes$variables)," events=",sum(subdes$variables$y),if(length(idx)==1) paste0(" OR=",round(exp(b[idx]),4)," P=",signif(p[idx],4)) else "","\n")
 flush.console()
 list(fit=fit,design=subdes,mask=mask,label=label,coef=co)
}
for(period in c("prepandemic_2005_March2020","postpandemic_2021_2023")){
 short<-if(grepl("^pre",period))"pre" else "post"
 for(day in c("day1","twoday")){
  v<-d[d$period==period,]
  v$w <- v[[paste0("analysis_weight_",day)]]
  v$eligible <- v[[paste0("eligible_",day)]]
  v$x <- v[[if(day=="day1")"day1_fat_energy_pct" else "twoday_fat_energy_pct"]]
  v$x5 <- v$x/5
  v$fat20 <- v[[if(day=="day1")"day1_fat_g" else "twoday_fat_g_mean"]]/20
  v$energy1000 <- v[[if(day=="day1")"day1_energy_kcal" else "twoday_energy_kcal_mean"]]/1000
  v$composition <- v[[if(day=="day1")"day1_unsat_to_sat_ratio" else "twoday_unsat_to_sat_ratio"]]
  v$y <- v$appetite_eating_symptom_freq_ge2
  good<-is.finite(v$w)&v$w>0 & !is.na(v$SDMVSTRA)&!is.na(v$SDMVPSU)
  v<-v[good,]
  v$cycle<-droplevels(v$cycle)
  cyc<-if(short=="pre")"+ cycle" else ""
  des<-svydesign(ids=~SDMVPSU,strata=~SDMVSTRA,weights=~w,data=v,nest=TRUE)
  base<-v$eligible
  adult<-base&v$adult20
  f0<-y~x5
  f1<-as.formula(paste("y ~ x5 + age10 + sex + race_ethnicity",cyc))
  f2<-as.formula(paste("y ~ x5 + age10 + sex + race_ethnicity",cyc,"+ education + pir + energy1000"))
  f3<-update(f2,.~.+smoking+alcohol+activity)
  f4<-update(f3,.~.+bmi5)
  f5<-update(f4,.~.+other_dep5)
  label<-paste(short,day,sep="_")
  a0<-add_fit(des,f0,base,paste0(label,"_M0"))
  a1<-add_fit(des,f1,base,paste0(label,"_M1"))
  a2<-add_fit(des,f2,adult,paste0(label,"_M2"))
  a3<-add_fit(des,f3,adult,paste0(label,"_M3_lifestyle"))
  a4<-add_fit(des,f4,adult,paste0(label,"_M4_BMI"))
  a5<-add_fit(des,f5,adult,paste0(label,"_M5_otherdepression"))
  fit_store[[paste0(label,"_M2")]]<-a2
  # Compare nested models on exactly the fully-adjusted complete-case sample.
  for(mm in c("M0","M1","M2","M3","M4","M5")){
   ff<-switch(mm,M0=f0,M1=f1,M2=f2,M3=f3,M4=f4,M5=f5)
   add_fit(des,ff,a5$mask,paste0(label,"_",mm,"_sameCC"))
  }
  # Day1 on the same participants and same weights as the two-day analysis.
  if(day=="twoday"){
   des_same<-des
   des_same$variables$x5<-des_same$variables$day1_fat_energy_pct/5
   des_same$variables$energy1000<-des_same$variables$day1_energy_kcal/1000
   add_fit(des_same,f2,a2$mask,paste0(label,"_day1_exposure_same_sample_M2"))
  }
  # Absolute dietary fat sensitivity and composition complement.
  add_fit(des,update(f2,.~.-x5+fat20),adult,paste0(label,"_fatg_M2"),term="fat20",exposure_unit="20 g/day total fat")
  add_fit(des,update(f2,.~.-x5+composition),adult,paste0(label,"_composition_M2"),term="composition",exposure_unit="1 unit (MUFA+PUFA)/SFA")
  # Outcome-threshold sensitivity.
  for(outcome in c("appetite_eating_symptom_any_ge1","appetite_eating_symptom_daily")){
   alt<-des;alt$variables$y<-alt$variables[[outcome]]
   add_fit(alt,f2,adult,paste0(label,"_",outcome,"_M2"))
  }
  # Low-weight composite: minimal adjustment, do not adjust BMI.
  low<-des;low$variables$y<-low$variables$symptom_ge2_and_underweight
  add_fit(low,y~x5,base,paste0(label,"_lowweight_M0"))
  add_fit(low,y~x5+age10+sex,base,paste0(label,"_lowweight_age_sex"))
  add_fit(low,y~x5+age10+sex+energy1000,base,paste0(label,"_lowweight_age_sex_energy"))
  # Adult >=20, same demographic adjustment.
  add_fit(des,f1,adult,paste0(label,"_M1_age20"))
  # Weighted descriptive estimates for the base cohort.
  des$variables$baseok<-base
  bd<-subset(des,baseok)
  for(outcome in c(0,1)){
   tmp<-subset(bd,y==outcome)
   means<-svymean(~x+age+bmi,design=tmp,na.rm=TRUE)
   prev<-svymean(~y,design=bd)
   desc_results[[length(desc_results)+1]]<-data.frame(period=short,day=day,symptom=outcome,n=nrow(tmp$variables),weighted_prevalence=coef(prev)[1],fat_energy_pct_mean=coef(means)["x"],fat_energy_pct_se=SE(means)["x"],age_mean=coef(means)["age"],bmi_mean=coef(means)["bmi"])
  }
  # Quartile cutpoints, decided using exposure distribution independent of outcomes.
  qs<-weighted_quantile(v$x[base],v$w[base],c(.25,.5,.75))
  des$variables$fat_quartile<-cut(v$x,breaks=c(-Inf,qs,Inf),labels=c("Q1","Q2","Q3","Q4"))
  cuts[[length(cuts)+1]]<-data.frame(period=short,day=day,q25=qs[1],q50=qs[2],q75=qs[3])
  fq<-update(f2,.~.-x5+fat_quartile)
  aq<-add_fit(des,fq,adult,paste0(label,"_quartiles_M2"),term="fat_quartileQ4",exposure_unit="Q4 vs Q1")
  med<-sapply(levels(des$variables$fat_quartile),function(q){
    j<-base&des$variables$fat_quartile==q;j[is.na(j)]<-FALSE
    weighted_quantile(v$x[j],v$w[j],.5)})
  des$variables$quartile_median5<-med[as.character(des$variables$fat_quartile)]/5
  add_fit(des,update(f2,.~.-x5+quartile_median5),adult,paste0(label,"_quartile_trend_M2"),term="quartile_median5")
  # Prespecified restricted cubic spline with 3 total knots: weighted p10,p50,p90.
  k<-weighted_quantile(v$x[base],v$w[base],c(.1,.5,.9))
  rcs<-function(x){(pmax(x-k[1],0)^3-pmax(x-k[2],0)^3*(k[3]-k[1])/(k[3]-k[2])+pmax(x-k[3],0)^3*(k[2]-k[1])/(k[3]-k[2]))/(k[3]-k[1])^2}
  des$variables$rcs_nl<-rcs(v$x)/5
  sp<-add_fit(des,update(f2,.~.+rcs_nl),adult,paste0(label,"_spline_M2"),term="rcs_nl",exposure_unit="nonlinear spline coefficient; not an interpretable exposure OR")
  tt<-regTermTest(sp$fit,~rcs_nl,df=degf(sp$design),method="Wald")
  tests[[length(tests)+1]]<-data.frame(label=paste0(label,"_nonlinearity"),p=tt$p,statistic=as.numeric(tt$Ftest),df_num=tt$df,df_den=tt$ddf)
  ref<-qs[2]; grid<-seq(k[1],k[3],length.out=81)
  b<-coef(sp$fit); V<-vcov(sp$fit)
  L<-matrix(0,nrow=length(grid),ncol=length(b),dimnames=list(NULL,names(b)))
  L[,"x5"]<-(grid-ref)/5;L[,"rcs_nl"]<-(rcs(grid)-rcs(ref))/5
  lp<-as.numeric(L%*%b);se<-sqrt(rowSums((L%*%V)*L));crit<-qt(.975,degf(sp$design))
  curves[[length(curves)+1]]<-data.frame(period=short,day=day,fat_energy_pct=grid,reference_pct=ref,OR=exp(lp),ci_low=exp(lp-crit*se),ci_high=exp(lp+crit*se),knot10=k[1],knot50=k[2],knot90=k[3])
  fi<-update(f2,.~.+x5:sex)
  ai<-add_fit(des,fi,adult,paste0(label,"_sexinteraction_M2"),term="x5:sexFemale",exposure_unit="interaction ratio Female vs Male")
  ti<-regTermTest(ai$fit,~x5:sex,df=degf(ai$design),method="Wald")
  tests[[length(tests)+1]]<-data.frame(label=paste0(label,"_sexinteraction"),p=ti$p,statistic=as.numeric(ti$Ftest),df_num=ti$df,df_den=ti$ddf)
  for(s in c("Male","Female")){
   add_fit(des,update(f2,.~.-sex),adult,paste0(label,"_",s,"_M2"),subset_extra=v$sex==s)
  }
  write.csv(do.call(rbind,all_results),file.path(resdir,"model_results.csv"),row.names=FALSE)
 }
}
write.csv(do.call(rbind,all_results),file.path(resdir,"model_results.csv"),row.names=FALSE)
write.csv(do.call(rbind,all_coefs),file.path(resdir,"all_model_coefficients.csv"),row.names=FALSE)
write.csv(do.call(rbind,all_diag),file.path(resdir,"model_diagnostics.csv"),row.names=FALSE)
write.csv(do.call(rbind,desc_results),file.path(resdir,"weighted_descriptives.csv"),row.names=FALSE)
write.csv(do.call(rbind,cuts),file.path(resdir,"weighted_quartile_cutpoints.csv"),row.names=FALSE)
write.csv(do.call(rbind,tests),file.path(resdir,"nonlinearity_interaction_tests.csv"),row.names=FALSE)
write.csv(do.call(rbind,curves),file.path(resdir,"spline_curve_data.csv"),row.names=FALSE)
saveRDS(fit_store,file.path(resdir,"M2_fitted_models.rds"),compress="gzip")
capture.output(sessionInfo(),file=file.path(resdir,"R_session_info.txt"))
cat("All prespecified analyses completed.\n")

