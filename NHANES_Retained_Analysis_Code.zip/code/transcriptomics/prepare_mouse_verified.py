import pathlib,zipfile,pandas as pd,hashlib,json
root=pathlib.Path(r'./project/Workspaces\AN_diet_transcriptome_20261013');raw=root/'raw';z=zipfile.ZipFile(raw/'dmb-zenodo_0.9.2.zip')
for src,dest in [('03_build_meta_and_counts/counts.csv','mouse_original_counts.csv'),('04_cleanup/meta_qc.csv','mouse_original_metadata_qc.csv'),('03_build_meta_and_counts/meta_long.csv','mouse_original_metadata.csv')]:
 (raw/dest).write_bytes(z.read('dmb-zenodo_0.9.2/'+src))
m=pd.read_csv(raw/'mouse_original_metadata_qc.csv');c=pd.read_csv(raw/'mouse_original_counts.csv');g=pd.read_csv(raw/'GSE236077_counts.csv.gz')
print('META',m.columns.tolist());print('COUNTS',c.iloc[:2,:5].to_string(index=False))
pfc=m[(m.region=='PFC') & (m.diet.isin(['chow','HFD']))].copy()
print(pfc.to_string(index=False))
print('shape',c.shape)
# Match expression vectors exactly rather than guessing repeated GSM suffixes.
geo_hash={}
for col in g.columns[1:]:
 h=hashlib.sha256(g[col].to_numpy(dtype='int64').tobytes()).hexdigest();geo_hash.setdefault(h,[]).append(col)
assert c.iloc[:,0].tolist()==g.iloc[:,0].tolist()
map_rows=[]
for _,r in pfc.iterrows():
 col=r['name'];assert col in c.columns
 h=hashlib.sha256(c[col].to_numpy(dtype='int64').tobytes()).hexdigest();matches=geo_hash.get(h,[])
 assert len(matches)==1,(col,matches)
 map_rows.append(dict(sample_name=col,GEO_count_column=matches[0],animal_id=r.animal_id,cage_id=r.box_id,diet=r.diet))
pfc.to_csv(raw/'mouse_PFC_metadata_verified.csv',index=False)
pd.DataFrame(map_rows).to_csv(raw/'mouse_PFC_count_identity_audit.csv',index=False)
c[[c.columns[0]]+pfc['name'].tolist()].to_csv(raw/'mouse_PFC_counts_verified.csv',index=False)
print('VERIFIED PFC',map_rows)
