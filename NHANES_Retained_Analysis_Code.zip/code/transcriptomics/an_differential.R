.libPaths(c('./project/R/win-library/4.4',.libPaths()))
suppressPackageStartupMessages({library(edgeR);library(limma);library(data.table)})
root <- './project/Workspaces/AN_diet_transcriptome_20261013'
out <- file.path(root,'results');dir.create(out,recursive=TRUE,showWarnings=FALSE)
meta <- fread('./project/outputs/GSE262138_AN_sample_mapping_20261013/GSE262138_AN_and_controls_verified_mapping.csv',data.table=FALSE)
raw <- fread(file.path(root,'raw/GSE262138_Raw_count_data.txt'),data.table=FALSE)
ids <- sub('\\..*$','',raw[[1]])
counts <- as.matrix(raw[,-1]);storage.mode(counts)<-'numeric'
stopifnot(all(is.finite(counts)),all(counts>=0),max(abs(counts-round(counts)))<1e-7)
counts <- rowsum(counts,ids,reorder=FALSE)
results <- list(); audits <- list()
fit_one <- function(y,design,model_name,region) {
 stopifnot(qr(design)$rank==ncol(design))
 v <- voom(y,design,plot=FALSE)
 f <- eBayes(lmFit(v,design))
 tt <- topTable(f,coef='groupAN',number=Inf,sort.by='none',confint=TRUE)
 tt$gene_id<-rownames(tt);tt$brain_region<-region;tt$model<-model_name
 tt$SE <- f$stdev.unscaled[,'groupAN']*sqrt(f$s2.post)
 fwrite(tt,file.path(out,paste0('AN_vs_control_',region,'_',model_name,'.csv')))
 tt
}
for(region in c('DLPFC','Caudate')) {
 m<-meta[meta$brain_region==region,]
 stopifnot(!anyDuplicated(m$sample_id),!anyDuplicated(m$donor_id),all(m$sample_id %in% colnames(counts)))
 m$group<-factor(ifelse(m$AN_case==1,'AN','Control'),levels=c('Control','AN'))
 m$Sex<-factor(m$Sex);m$Race<-factor(m$Race);m$Neuronal<-m$Excitatory+m$Inhibitory
 fields<-c('Age','RIN','Neuronal','Perc.Intronic','Perc.rRNA','PMI')
 stopifnot(!anyNA(m[,c(fields,'Sex','Race')]))
 for(k in fields)m[[k]]<-as.numeric(scale(m[[k]]))
 design<-model.matrix(~group+Neuronal+RIN+Age+Sex+Race+Perc.Intronic+Perc.rRNA,m)
 y<-DGEList(counts[,m$sample_id]);keep<-filterByExpr(y,design=design)
 y<-calcNormFactors(y[keep,,keep.lib.sizes=FALSE],method='TMM')
 primary<-fit_one(y,design,'primary',region);results[[region]]<-primary
 sensitivity<-fit_one(y,model.matrix(~group+Neuronal+RIN+Age+Sex+Race+Perc.Intronic+Perc.rRNA+PMI,m),'PMI_adjusted',region)
 minimal<-fit_one(y,model.matrix(~group+RIN+Age+Sex+Race,m),'demographic_RIN',region)
 # AN subtype contrasts use the same retained genes as the primary analysis.
 for(subtype in c('AN-R','AN-BP')) {
  idx<-m$AN_case==0 | m$ED_subtype==subtype; mm<-droplevels(m[idx,]); yy<-calcNormFactors(y[,idx,keep.lib.sizes=FALSE])
  fit_one(yy,model.matrix(~group+Neuronal+RIN+Age+Sex+Race+Perc.Intronic+Perc.rRNA,mm),paste0('subtype_',subtype),region)
 }
 fwrite(m,file.path(out,paste0(region,'analysis_metadata.csv')))
 audits[[region]]<-data.frame(region=region,n_AN=sum(m$AN_case==1),n_control=sum(m$AN_case==0),genes_tested=nrow(y),design_rank=qr(design)$rank,residual_df=nrow(m)-ncol(design),DEG_FDR05=sum(primary$adj.P.Val<.05))
 cat(region,'tested',nrow(y),'DEG',sum(primary$adj.P.Val<.05),'\n')
}
all<-rbindlist(results);all$FDR_both_brain_regions<-p.adjust(all$P.Value,'BH');fwrite(all,file.path(out,'AN_DE_all_regions_primary.csv'))
fwrite(rbindlist(audits),file.path(out,'human_analysis_summary.csv'))
twas<-fread('./project/outputs/AN_brain_localization_20261013/AN_TWAS_complete_models.csv')
twas$gene_id<-sub('\\..*$','',twas$gene)
twas$brain_region<-ifelse(twas$tissue=='Frontal_Cortex_BA9','DLPFC',ifelse(twas$tissue=='Caudate_basal_ganglia','Caudate',NA))
print(unique(twas$tissue))
selected<-twas[!is.na(brain_region) & FDR_all_genes_12_tissues<.05]
setnames(selected,c('Z','P','FDR_all_genes_12_tissues'),c('TWAS_Z','TWAS_P','TWAS_FDR_12_tissues'))
inter<-merge(all,selected[,.(gene_id,brain_region,gene_name,TWAS_Z,TWAS_P,TWAS_FDR_12_tissues,model_snps)],by=c('gene_id','brain_region'))
inter$DE_significant_region<-inter$adj.P.Val<.05
inter$DE_significant_both_regions_family<-inter$FDR_both_brain_regions<.05
inter$TWAS_DE_direction_concordant<-sign(inter$TWAS_Z)==sign(inter$logFC)
fwrite(inter,file.path(out,'TWAS_signals_with_AN_DE_all.csv'))
fwrite(inter[DE_significant_region==TRUE],file.path(out,'AN_DE_TWAS_intersection.csv'))
capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'))
cat('INTERSECTION',nrow(inter[DE_significant_region==TRUE]),'\n');print(inter[DE_significant_region==TRUE,.(brain_region,gene_id,gene_name,logFC,adj.P.Val,TWAS_Z)])
