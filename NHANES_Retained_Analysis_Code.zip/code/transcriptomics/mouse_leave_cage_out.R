.libPaths(c('./project/R/win-library/4.4',.libPaths()))
suppressPackageStartupMessages({library(edgeR);library(limma);library(data.table)})
root<-'./project/Workspaces/AN_diet_transcriptome_20261013';out<-file.path(root,'results')
raw<-fread(file.path(root,'raw/mouse_PFC_counts_verified.csv'),data.table=FALSE);cnt<-as.matrix(raw[,-1]);rownames(cnt)<-raw[[1]]
m<-fread(file.path(root,'raw/mouse_PFC_metadata_verified.csv'),data.table=FALSE);m<-m[m$qc=='ok',];cnt<-cnt[,m$name]
cages<-unique(m$box_id);agg<-sapply(cages,function(k)rowSums(cnt[,m$box_id==k,drop=FALSE]));rownames(agg)<-rownames(cnt)
group<-factor(m$diet[match(cages,m$box_id)],levels=c('chow','HFD'))
primary<-fread(file.path(out,'HFD_vs_chow_PFC_cage_primary.csv'));agg<-agg[primary$mouse_gene_id,]
d<-fread(file.path(out,'AN_TWAS_HFD_integrated_all_candidates.csv'));target<-unique(d[!is.na(HFD_P),mouse_gene_id]);res<-list()
for(i in seq_along(cages)){
 y<-calcNormFactors(DGEList(agg[,-i]));design<-model.matrix(~group,data.frame(group=group[-i]));v<-voom(y,design,plot=FALSE);fit<-eBayes(lmFit(v,design));tt<-as.data.table(topTable(fit,coef='groupHFD',number=Inf,sort.by='none',confint=TRUE),keep.rownames='mouse_gene_id')
 tt<-tt[mouse_gene_id %in% target];tt$dropped_cage<-cages[i];tt$FDR_candidate_genes<-p.adjust(tt$P.Value,'BH');res[[i]]<-tt
 cat('leave cage',cages[i],'done\n')
}
fwrite(rbindlist(res),file.path(out,'TWAS_mouse_candidates_leave_one_cage_out.csv'))
