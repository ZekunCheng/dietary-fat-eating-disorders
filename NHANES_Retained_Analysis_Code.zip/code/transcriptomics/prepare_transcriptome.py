import pathlib,sys,concurrent.futures,json,gzip,re,hashlib
sys.path.insert(0,r'./project/Workspaces\dietary_fat_AN_MR\runtime\python-deps')
import requests
root=pathlib.Path(r'./project/Workspaces\AN_diet_transcriptome_20261013');raw=root/'raw';raw.mkdir(parents=True,exist_ok=True)
urls={
 'GSE236077_counts.csv.gz':'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE236nnn/GSE236077/suppl/GSE236077_counts.csv.gz',
 'GSE236077_gsm_meta_long.csv.gz':'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE236nnn/GSE236077/suppl/GSE236077_gsm_meta_long.csv.gz',
}
def get(item):
 name,url=item;dest=raw/name
 if dest.exists():return {'file':name,'cached':True,'bytes':dest.stat().st_size}
 r=requests.get(url,timeout=60);r.raise_for_status();dest.write_bytes(r.content)
 return {'file':name,'url':url,'bytes':len(r.content),'sha256':hashlib.sha256(r.content).hexdigest()}
res=list(concurrent.futures.ThreadPoolExecutor(3).map(get,urls.items()));print(json.dumps(res,indent=2))
(root/'download_log.json').write_text(json.dumps(res,indent=2),encoding='utf8')
print((raw/'GSE236077_suppl_listing.html').read_text()[:7000])
with gzip.open(raw/'GSE262138_Raw_count_data.txt.gz','rt') as f:print('HUMAN COUNT HEADER',f.readline()[:2500]);print('FIRST ROW',f.readline()[:250])
