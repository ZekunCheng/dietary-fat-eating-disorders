import pathlib,sys,json
sys.path.insert(0,r'./project/Workspaces\dietary_fat_AN_MR\runtime\python-deps')
import requests
root=pathlib.Path(r'./project/Workspaces\AN_diet_transcriptome_20261013')
xml='''<?xml version="1.0" encoding="UTF-8"?><Query virtualSchemaName="default" formatter="TSV" header="1" uniqueRows="1" count="" datasetConfigVersion="0.6"><Dataset name="hsapiens_gene_ensembl" interface="default"><Attribute name="ensembl_gene_id"/><Attribute name="external_gene_name"/><Attribute name="mmusculus_homolog_ensembl_gene"/><Attribute name="mmusculus_homolog_associated_gene_name"/><Attribute name="mmusculus_homolog_orthology_type"/><Attribute name="mmusculus_homolog_orthology_confidence"/></Dataset></Query>'''
for host in ['https://www.ensembl.org','https://useast.ensembl.org']:
 try:
  r=requests.get(host+'/biomart/martservice',params={'query':xml},timeout=55);r.raise_for_status()
  if 'Gene stable ID' not in r.text[:300]:raise ValueError(r.text[:200])
  (root/'raw/human_mouse_ensembl_orthologs.tsv').write_text(r.text,encoding='utf8')
  (root/'raw/ortholog_source.json').write_text(json.dumps({'url':r.url,'date':'2026-10-13','query':xml},indent=2),encoding='utf8')
  print('ORTHOLOGS',len(r.content),r.text[:500]);break
 except Exception as e:print(host,str(e))
