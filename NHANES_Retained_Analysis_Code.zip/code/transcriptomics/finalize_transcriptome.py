import pathlib,pandas as pd,numpy as np,json,shutil,hashlib,zipfile
root=pathlib.Path(r'./project/Workspaces\AN_diet_transcriptome_20261013');r=root/'results'
out=pathlib.Path(r'./project/outputs\AN_TWAS_HFD_integration_20261013');out.mkdir(exist_ok=True)
def bh(p):
 p=np.asarray(p);order=np.argsort(p);ranked=p[order];q=np.minimum.accumulate((ranked*len(p)/np.arange(1,len(p)+1))[::-1])[::-1];res=np.empty(len(p));res[order]=np.minimum(q,1);return res
de=pd.read_csv(r/'AN_DE_all_regions_primary.csv');twas=pd.read_csv(r'./project/outputs\AN_brain_localization_20261013\AN_TWAS_complete_models.csv')
twas=twas[twas.tissue.isin(['Frontal_Cortex_BA9','Caudate_basal_ganglia']) & (twas.FDR_all_genes_12_tissues<.05)].copy()
twas['gene_id']=twas.gene.str.split('.').str[0];twas['brain_region']=twas.tissue.map({'Frontal_Cortex_BA9':'DLPFC','Caudate_basal_ganglia':'Caudate'})
align=twas.merge(de[['gene_id','brain_region','P.Value','adj.P.Val']],on=['gene_id','brain_region'],how='left',validate='one_to_one');align['human_DE_tested']=align['P.Value'].notna();align.to_csv(r/'TWAS_human_expression_coverage_audit.csv',index=False)
d=pd.read_csv(r/'AN_TWAS_HFD_integrated_all_candidates.csv')
d['HFD_brain_region']='mouse_PFC';d['brain_region_match']=d.brain_region=='DLPFC'
d['diet_trend_scope']=np.where(d.brain_region=='DLPFC','PFC_to_PFC_cross_species','Caudate_to_PFC_cross_region_cross_species')
for label,file in [('AN_PMI','AN_vs_control_{}_PMI_adjusted.csv'),('AN_minimal','AN_vs_control_{}_demographic_RIN.csv'),('AN_R','AN_vs_control_{}_subtype_AN-R.csv'),('AN_BP','AN_vs_control_{}_subtype_AN-BP.csv')]:
 parts=[]
 for region in ['DLPFC','Caudate']:
  x=pd.read_csv(r/file.format(region));x=x[['gene_id','brain_region','logFC','P.Value','adj.P.Val']];x=x.rename(columns={'logFC':label+'_logFC','P.Value':label+'_P','adj.P.Val':label+'_FDR'});parts.append(x)
 d=d.merge(pd.concat(parts),on=['gene_id','brain_region'],how='left',validate='one_to_one')
targetids=d.loc[d.HFD_P.notna(),'mouse_gene_id'].unique()
for label,file in [('HFD_hemisphere','HFD_vs_chow_PFC_cage_hemisphere_adjusted.csv'),('HFD_QC_included','HFD_vs_chow_PFC_cage_include_original_QC_fail.csv'),('HFD_animal_blocked','HFD_vs_chow_PFC_animal_cage_blocked.csv')]:
 x=pd.read_csv(r/file);x=x[x.mouse_gene_id.isin(targetids)].copy();x[label+'_FDR_candidates']=bh(x['P.Value'])
 x=x[['mouse_gene_id','logFC','P.Value','adj.P.Val',label+'_FDR_candidates']].rename(columns={'logFC':label+'_logFC','P.Value':label+'_P','adj.P.Val':label+'_FDR_genome'})
 d=d.merge(x,on='mouse_gene_id',how='left',validate='many_to_one')
loo=pd.read_csv(r/'TWAS_mouse_candidates_leave_one_cage_out.csv')
ls=loo.groupby('mouse_gene_id').agg(HFD_LOO_logFC_min=('logFC','min'),HFD_LOO_logFC_max=('logFC','max'),HFD_LOO_P_min=('P.Value','min'),HFD_LOO_P_max=('P.Value','max'),HFD_LOO_FDR_max=('FDR_candidate_genes','max')).reset_index()
d=d.merge(ls,on='mouse_gene_id',how='left',validate='many_to_one')
d.to_csv(r/'AN_TWAS_HFD_integrated_all_candidates.csv',index=False)
d[d.DE_significant_region].to_csv(r/'Focus_genes_strict.csv',index=False)
d[d['P.Value']<.05].to_csv(r/'Supplementary_nominal_AN_DE_candidates.csv',index=False)
d[d.HFD_FDR_TWAS_candidate_genes<.05].to_csv(r/'Supplementary_TWAS_HFD_supported_candidates.csv',index=False)
ort=pd.read_csv(root/'raw/human_mouse_ensembl_orthologs.tsv',sep='\t');ann=ort[['Gene stable ID','Gene name']].drop_duplicates();assert not ann['Gene stable ID'].duplicated().any()
de=de.merge(ann,left_on='gene_id',right_on='Gene stable ID',how='left',validate='many_to_one').drop(columns='Gene stable ID').rename(columns={'Gene name':'gene_name'})
de.to_csv(r/'AN_DE_all_regions_primary_annotated.csv',index=False);de[de['adj.P.Val']<.05].to_csv(r/'AN_DE_significant_genes.csv',index=False)
checks=[]
for f in r.glob('AN_vs_control_*.csv'):
 x=pd.read_csv(f);assert np.allclose(bh(x['P.Value']),x['adj.P.Val']);assert (x['CI.L']<=x.logFC).all() and (x.logFC<=x['CI.R']).all();assert not x.gene_id.duplicated().any();checks.append(f.name)
for f in r.glob('HFD_vs_chow_*.csv'):
 x=pd.read_csv(f);assert np.allclose(bh(x['P.Value']),x['adj.P.Val']);assert not x.mouse_gene_id.duplicated().any();checks.append(f.name)
assert np.allclose(bh(de['P.Value']),de.FDR_both_brain_regions)
strict=de.merge(twas[['gene_id','brain_region']],on=['gene_id','brain_region']);assert (strict['adj.P.Val']<.05).sum()==0
u=d[d.HFD_P.notna()].drop_duplicates('mouse_gene_id');assert len(u)==31 and np.allclose(bh(u.HFD_P),u.HFD_FDR_TWAS_candidate_genes)
assert len(d)==47 and not d.DE_significant_region.any()
assert d.mouse_gene_id.notna().sum()>=len(u)
validation={'status':'PASS','verified_result_files':checks,'strict_intersection_gene_region_count':0,'TWAS_significant_region_models':len(twas),'TWAS_models_tested_in_human_DE':int(align.human_DE_tested.sum()),'unique_mouse_TWAS_genes_tested':len(u),'ortholog_mapping':'Ensembl ortholog_one2one, confidence=1','no_figures_generated':True}
(r/'validation.json').write_text(json.dumps(validation,indent=2),encoding='utf8')
print(json.dumps(validation,indent=2))
print('WDR6',d[d.gene_name=='WDR6'][['brain_region','HFD_logFC','HFD_P','HFD_FDR_TWAS_candidate_genes','HFD_LOO_logFC_min','HFD_LOO_logFC_max','HFD_LOO_P_max','HFD_LOO_FDR_max']].to_string(index=False))
for f in r.iterdir():
 if f.is_file():shutil.copy2(f,out/f.name)
code=out/'code';code.mkdir(exist_ok=True)
for name in ['an_differential.R','mouse_differential.R','mouse_leave_cage_out.R','prepare_transcriptome.py','prepare_mouse_verified.py','fetch_orthologs.py','fetch_mouse_source.py','finalize_transcriptome.py']:
 shutil.copy2(pathlib.Path(__file__).parent/name,code/name)
shutil.copy2(root/'raw/mouse_PFC_count_identity_audit.csv',out/'mouse_PFC_count_identity_audit.csv')
shutil.copy2(root/'raw/ortholog_source.json',out/'ortholog_source.json')
manifest=[]
for f in (root/'raw').iterdir():
 if f.is_file():manifest.append(dict(file=str(f),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
(out/'input_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
