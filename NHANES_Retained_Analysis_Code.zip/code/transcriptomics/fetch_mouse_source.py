import pathlib,sys,json
sys.path.insert(0,r'./project/Workspaces\dietary_fat_AN_MR\runtime\python-deps')
import requests
p=pathlib.Path(r'./project/Workspaces\AN_diet_transcriptome_20261013\raw')
r=requests.get('https://zenodo.org/api/records/10116113',timeout=40);r.raise_for_status();(p/'zenodo_record.json').write_text(r.text,encoding='utf8')
j=r.json();print(json.dumps([dict(key=f['key'],size=f['size'],url=f['links']['self']) for f in j['files']],indent=2))
for f in j['files']:
 dest=p/f['key']
 if not dest.exists():
  with requests.get(f['links']['self'],timeout=50,stream=True) as rr:
   rr.raise_for_status()
   with dest.open('wb') as out:
    for chunk in rr.iter_content(1024*1024):out.write(chunk)
 import zipfile
 z=zipfile.ZipFile(dest)
 print('\n'.join(f'{n}: {z.getinfo(n).file_size}' for n in z.namelist() if any(s in n.lower() for s in ['count','meta','geo','quality','qc'])))
