"""Numerical verification of exported predictions and grouped SHAP; no rendering."""
from pathlib import Path
import json, ast
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score
from xgboost import Booster, DMatrix
from run_xgboost_shap import encode, CAT

root=Path(__file__).resolve().parent
metrics=pd.read_csv(root/'model_metrics.csv')
checks=[]
for mode in ['day1','twoday']:
    inp=pd.read_csv(root/f'{mode}_model_input.csv',keep_default_na=False,na_values=['','NA'])
    assert not inp.participant_id.duplicated().any()
    for test in ['heldout_pre','temporal_post']:
        p=pd.read_csv(root/mode/f'{test}_predictions.csv')
        s=pd.read_csv(root/mode/f'{test}_SHAP_grouped.csv.gz')
        f=pd.read_csv(root/mode/f'{test}_feature_values.csv.gz',keep_default_na=False,na_values=['','NA'])
        assert p.participant_id.equals(s.participant_id) and p.participant_id.equals(f.participant_id)
        cols=[c for c in s if c not in ['participant_id','base_value','model_log_odds','probability','weight']]
        assert len(cols)==14
        err=float(np.abs(s[cols].sum(axis=1)+s.base_value-s.model_log_odds).max())
        assert err<3e-5
        assert np.max(np.abs(1/(1+np.exp(-s.model_log_odds))-p.probability_full))<3e-6
        d=inp[inp.partition==test].copy()
        assert d.participant_id.reset_index(drop=True).equals(p.participant_id)
        for c in CAT: d[c]=d[c].astype(str)
        for model in ['full','covariates_only']:
            row=metrics[(metrics.dietary_days==mode)&(metrics.test_set==test)&(metrics.model==model)].iloc[0]
            assert abs(roc_auc_score(p.y,p[f'probability_{model}'],sample_weight=p.weight)-row.AUROC)<1e-12
            assert abs(average_precision_score(p.y,p[f'probability_{model}'],sample_weight=p.weight)-row.average_precision)<1e-12
            saved=Booster()
            saved.load_model(root/mode/f'{model}_model.json')
            x=encode(d,saved.feature_names)
            assert np.max(np.abs(saved.predict(DMatrix(x,feature_names=x.columns.tolist()))-p[f'probability_{model}']))<1e-6
        imp=pd.read_csv(root/mode/f'{test}_SHAP_importance.csv')
        rankerror=0.
        for row in imp.itertuples():
            delta=abs(np.average(np.abs(s[row.variable]),weights=s.weight)-row.weighted_mean_abs_SHAP_log_odds)
            rankerror=max(rankerror,delta)
            assert delta<1e-7
        checks.append({'mode':mode,'test_set':test,'n':len(p),'SHAP_features':len(cols),'max_additivity_error':err,'max_mean_contribution_rounding_error':float(rankerror),'metrics_recomputed':'PASS','saved_model_predictions_recomputed':'PASS','SHAP_weighted_rank_recomputed':'PASS','row_alignment':'PASS'})
for path in root.rglob('*.py'): ast.parse(path.read_text(encoding='utf-8-sig'))
(root/'validation_checks.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps(checks,indent=2))
print('PASS: no plots rendered.')

