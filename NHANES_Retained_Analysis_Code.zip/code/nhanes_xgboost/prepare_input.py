from pathlib import Path
import pandas as pd, numpy as np, json
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--input',type=Path,required=True)
src=parser.parse_args().input
out=Path(__file__).resolve().parent
d=pd.read_csv(src,keep_default_na=False,na_values=['','NA'],low_memory=False)
rng=np.random.default_rng(20261010)
pre=d[d.period=='prepandemic_2005_March2020']
psus=pre[['SDMVSTRA','SDMVPSU']].dropna().drop_duplicates().sort_values(['SDMVSTRA','SDMVPSU'])
held=set()
for stratum,g in psus.groupby('SDMVSTRA',sort=True):
    assert len(g)>=2
    chosen=rng.choice(g.SDMVPSU.to_numpy())
    held.add((int(stratum),int(chosen)))
psus['partition']=['heldout_pre' if (int(a),int(b)) in held else 'train' for a,b in zip(psus.SDMVSTRA,psus.SDMVPSU)]
psus.to_csv(out/'prepandemic_PSU_partition.csv',index=False)
counts=[]
for mode in ['day1','twoday']:
    energy='day1_energy_kcal' if mode=='day1' else 'twoday_energy_kcal_mean'
    mapping={f'{mode}_protein_pct':'protein_pct',f'{mode}_fat_energy_pct':'fat_pct',f'{mode}_carbohydrate_pct':'carbohydrate_pct',f'{mode}_fiber_g':'fiber_g',energy:'energy_kcal',f'analysis_weight_{mode}':'weight','appetite_eating_symptom_freq_ge2':'y'}
    cols=['participant_id','SEQN','cycle','period','SDMVSTRA','SDMVPSU','age','bmi','income_poverty_ratio','sex','race_ethnicity','education_adult20','smoking_status','alcohol_frequency_group','leisure_activity_group']+list(mapping)
    eligible=d[d[f'eligible_{mode}'] & d.adult20].copy()
    complete=eligible[cols].notna().all(axis=1)
    z=eligible.loc[complete,cols].rename(columns=mapping).copy()
    assert (z.weight>0).all()
    z['partition']=['temporal_post' if p=='postpandemic_2021_2023' else ('heldout_pre' if (int(a),int(b)) in held else 'train') for p,a,b in zip(z.period,z.SDMVSTRA,z.SDMVPSU)]
    z.y=z.y.astype(int)
    z.to_csv(out/f'{mode}_model_input.csv',index=False)
    for period in eligible.period.unique():
        selected=z[z.period==period]
        counts.append({'mode':mode,'period':period,'eligible_adult20_n':int((eligible.period==period).sum()),'complete_n':len(selected),'excluded_missing_predictors':int((eligible.period==period).sum())-len(selected),'events':int(selected.y.sum())})
    print(mode,z.groupby('partition').y.agg(['count','sum']).to_string())
pd.DataFrame(counts).to_csv(out/'sample_flow.csv',index=False)
