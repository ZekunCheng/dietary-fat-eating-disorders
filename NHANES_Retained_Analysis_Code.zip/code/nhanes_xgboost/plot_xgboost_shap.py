"""Plot exported XGBoost/TreeSHAP source data. Importing this file does not render.
Usage: python plot_xgboost_shap.py --mode day1 --test-set heldout_pre
       python plot_xgboost_shap.py --mode twoday --test-set temporal_post --force-html
All participants retained in scatter/beeswarm panels; only displayed feature count
is restricted to ten for legibility. Full fourteen-variable SHAP data are exported.
"""
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable

mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':7,'axes.labelsize':7,'axes.titlesize':8,'xtick.labelsize':6,'ytick.labelsize':6,'legend.fontsize':6,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6})
LABELS={'protein_pct':'Protein (% energy)','fat_pct':'Fat (% energy)','carbohydrate_pct':'Carbohydrate (% energy)','fiber_g':'Fiber (g/day)','energy_kcal':'Energy (kcal/day)','age':'Age (years)','bmi':'BMI (kg/m²)','income_poverty_ratio':'Income-to-poverty ratio','sex':'Sex','race_ethnicity':'Race / ethnicity','education_adult20':'Education','smoking_status':'Smoking','alcohol_frequency_group':'Alcohol frequency','leisure_activity_group':'Leisure activity'}


def export(fig,stem):
    # Draw only when the user runs this script; editable vector text, 600 dpi preview.
    fig.savefig(stem.with_suffix('.pdf'))
    fig.savefig(stem.with_suffix('.svg'))
    fig.savefig(stem.with_suffix('.png'),dpi=600)
    plt.close(fig)


def load_data(root,mode,test):
    folder=root/mode
    sv=pd.read_csv(folder/f'{test}_SHAP_grouped.csv.gz',keep_default_na=False,na_values=['','NA'])
    values=pd.read_csv(folder/f'{test}_feature_values.csv.gz',keep_default_na=False,na_values=['','NA'])
    assert sv.participant_id.equals(values.participant_id)
    importance=pd.read_csv(folder/f'{test}_SHAP_importance.csv')
    return folder,sv,values,importance


def plot_panels(root,mode,test):
    folder,sv,values,importance=load_data(root,mode,test)
    metrics=pd.read_csv(root/'model_metrics.csv')
    fig,axs=plt.subplots(2,2,figsize=(7.204724,6.496063),layout='constrained')
    ax=axs[0,0]
    for model,color,label in [('full','#31688e','XGBoost: diet + covariates'),('covariates_only','#8c8c8c','XGBoost: covariates')]:
        roc=pd.read_csv(folder/f'{test}_{model}_ROC.csv')
        auc=float(metrics.loc[(metrics.dietary_days==mode)&(metrics.test_set==test)&(metrics.model==model),'AUROC'].iloc[0])
        ax.plot(roc.false_positive_rate,roc.true_positive_rate,color=color,lw=1.2,label=f'{label}\nAUROC = {auc:.3f}')
    ax.plot([0,1],[0,1],color='#c8c8c8',lw=.7,ls='--')
    ax.set(xlim=(0,1),ylim=(0,1),xlabel='False positive rate',ylabel='True positive rate',title='Weighted held-out ROC')
    ax.legend(loc='lower right',frameon=False)
    ax=axs[0,1]
    ordered=importance.iloc[::-1]
    colors=['#31688e' if v=='protein_pct' else '#a8bbc4' for v in ordered.variable]
    ax.barh([LABELS[v] for v in ordered.variable],ordered.weighted_mean_abs_SHAP_log_odds,color=colors)
    ax.set(xlabel='Weighted mean |SHAP| (log-odds)',title='All-variable model contributions')
    ax=axs[1,0]
    top=importance.variable.iloc[:10].tolist()[::-1]
    rng=np.random.default_rng(20261010)
    # Display jitter only: no subsampling or changes to SHAP estimates.
    for j,var in enumerate(top):
        jitter=rng.uniform(-.30,.30,len(sv))
        feature=pd.to_numeric(values[var],errors='coerce')
        if var in ['protein_pct','fat_pct','carbohydrate_pct','fiber_g','energy_kcal','age','bmi','income_poverty_ratio']:
            lo,hi=np.quantile(feature,[.01,.99])
            color=(feature-lo)/max(hi-lo,1e-12)
            ax.scatter(sv[var],j+jitter,c=np.clip(color,0,1),cmap='coolwarm',vmin=0,vmax=1,s=1,alpha=.35,rasterized=True,linewidths=0)
        else:
            ax.scatter(sv[var],j+jitter,c='#929292',s=1,alpha=.35,rasterized=True,linewidths=0)
    ax.axvline(0,lw=.6,color='#b5b5b5')
    ax.set(yticks=np.arange(len(top)),yticklabels=[LABELS[v] for v in top],xlabel='Grouped SHAP value (log-odds)',title='Contribution directions: top 10')
    cb=fig.colorbar(ScalarMappable(norm=Normalize(0,1),cmap='coolwarm'),ax=ax,fraction=.04,pad=.02,ticks=[0,1])
    cb.ax.set_yticklabels(['Low','High'])
    cb.set_label('Feature value; categories gray',fontsize=6)
    ax=axs[1,1]
    points=ax.scatter(values.protein_pct,sv.protein_pct,c=values.bmi,cmap='viridis',s=2,alpha=.4,rasterized=True,linewidths=0)
    ax.axhline(0,lw=.6,color='#b5b5b5')
    ax.set(xlabel=LABELS['protein_pct'],ylabel='Protein SHAP value (log-odds)',title='Protein dependence: every test participant')
    cb=fig.colorbar(points,ax=ax,fraction=.04,pad=.02)
    cb.set_label('BMI (kg/m²)',fontsize=6)
    for label,ax in zip('abcd',axs.flat):
        ax.text(-.12,1.06,label,transform=ax.transAxes,fontweight='bold',fontsize=8)
    export(fig,folder/f'{test}_XGBoost_SHAP')


def plot_waterfall(root,mode,test):
    folder=root/mode
    d=pd.read_csv(folder/f'{test}_individual_waterfall.csv',keep_default_na=False)
    audit=json.loads((folder/f'{test}_audit.json').read_text(encoding='utf-8'))
    d=d.reindex(d.SHAP_log_odds.abs().sort_values(ascending=False).index)
    fig,ax=plt.subplots(figsize=(4.724409,4.133858),layout='constrained')
    current=audit['example_base_value']
    for j,row in enumerate(d.itertuples()):
        end=current+row.SHAP_log_odds
        ax.barh(j,abs(row.SHAP_log_odds),left=min(current,end),color='#b6604c' if row.SHAP_log_odds>0 else '#31688e')
        ax.plot([end,end],[j+.35,j+.65],color='#bbbbbb',lw=.6)
        current=end
    assert abs(current-audit['example_log_odds'])<3e-5
    ax.set(yticks=np.arange(len(d)),yticklabels=[LABELS[v] for v in d.variable],xlabel='Model output (log-odds)',title=f"Illustrative participant: predicted probability {audit['example_probability']:.3f}")
    ax.invert_yaxis()
    ax.axvline(audit['example_base_value'],lw=.7,ls='--',color='#808080')
    export(fig,folder/f'{test}_individual_waterfall')


def force_html(root,mode,test):
    import shap
    folder=root/mode
    d=pd.read_csv(folder/f'{test}_individual_waterfall.csv',keep_default_na=False)
    audit=json.loads((folder/f'{test}_audit.json').read_text(encoding='utf-8'))
    force=shap.force_plot(audit['example_base_value'],d.SHAP_log_odds.to_numpy(),features=d.feature_value.to_numpy(),feature_names=[LABELS[v] for v in d.variable],link='logit',matplotlib=False)
    shap.save_html(str(folder/f'{test}_individual_force.html'),force)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--mode',choices=['day1','twoday'],default='day1')
    parser.add_argument('--test-set',choices=['heldout_pre','temporal_post'],default='heldout_pre')
    parser.add_argument('--force-html',action='store_true')
    a=parser.parse_args()
    plot_panels(a.root,a.mode,a.test_set)
    plot_waterfall(a.root,a.mode,a.test_set)
    if a.force_html:
        force_html(a.root,a.mode,a.test_set)

if __name__=='__main__':
    main()

