from pathlib import Path
import json, hashlib, platform
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, log_loss, roc_curve, precision_recall_curve
from xgboost import XGBClassifier, DMatrix
import xgboost, sklearn

ROOT=Path(__file__).resolve().parent
SEED=20261010
NUM=['protein_pct','fat_pct','carbohydrate_pct','fiber_g','energy_kcal','age','bmi','income_poverty_ratio']
CAT=['sex','race_ethnicity','education_adult20','smoking_status','alcohol_frequency_group','leisure_activity_group']
DIET=NUM[:5]
PARAM=dict(n_estimators=250,max_depth=3,learning_rate=.03,subsample=.8,colsample_bytree=.8,min_child_weight=10,reg_lambda=3,n_jobs=2,random_state=SEED,objective='binary:logistic',eval_metric='logloss')

def encode(d,columns=None):
    x=pd.get_dummies(d[NUM+CAT],columns=CAT,prefix_sep='::',dtype=float)
    if columns is not None:
        x=x.reindex(columns=columns,fill_value=0)
    assert x.notna().all().all()
    return x

def score(y,p,w):
    return dict(n=int(len(y)),events=int(np.sum(y)),weighted_prevalence=float(np.average(y,weights=w)),AUROC=float(roc_auc_score(y,p,sample_weight=w)),average_precision=float(average_precision_score(y,p,sample_weight=w)),Brier=float(brier_score_loss(y,p,sample_weight=w)),log_loss=float(log_loss(y,p,sample_weight=w)))

def main():
    plan={'outcome':'DPQ050 >= 2: poor appetite OR overeating; NOT diagnosed AN or ED','exposures':{'protein_pct':'400 * protein grams / energy kcal; two-day ratio of sums','fat_pct':'900 * fat grams / energy kcal; two-day ratio of sums'},'eligibility':'Adult >=20; previously defined dietary/outcome eligibility; complete predictors; no extra exposure trimming','numeric_features':NUM,'categorical_features':CAT,'excluded_features':['DPQ050 predictor','PHQ9','other depressive symptoms','participant identifiers','weights','cycle','period','PSU','stratum'],'split':'One random PSU held out within each pre-pandemic survey stratum, seed 20261010; remaining PSUs training. 2021-2023 independent temporal evaluation; not used for tuning. Same pre-pandemic PSU partition in both dietary analyses.','training':'Survey weights normalized to training mean, no hyperparameter optimization; not design-based statistical inference','metrics':'Survey-weighted held-out metrics; single fixed split, no confidence intervals or repeated-seed uncertainty estimated','SHAP':'Exact TreeSHAP via XGBoost pred_contribs; raw log-odds. Sum one-hot contributions within variable, then survey-weighted mean absolute grouped contribution. All test participants, no plotting subsample.','interpretation':'Correlated macronutrient percentages can redistribute attribution. SHAP does not establish causal/protective effects. Dietary incremental comparison adds all five diet variables; cannot isolate protein benefit.','hyperparameters':PARAM}
    (ROOT/'analysis_plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
    metrics=[]
    for mode in ['day1','twoday']:
        out=ROOT/mode
        out.mkdir(exist_ok=True)
        d=pd.read_csv(ROOT/f'{mode}_model_input.csv',keep_default_na=False,na_values=['','NA'],low_memory=False)
        for c in CAT:
            d[c]=d[c].astype(str)
        assert d[NUM+CAT+['y','weight','SDMVSTRA','SDMVPSU']].notna().all().all()
        train=d[d.partition=='train'].copy()
        tests={'heldout_pre':d[d.partition=='heldout_pre'].copy(),'temporal_post':d[d.partition=='temporal_post'].copy()}
        assert not set(zip(train.SDMVSTRA,train.SDMVPSU)) & set(zip(tests['heldout_pre'].SDMVSTRA,tests['heldout_pre'].SDMVPSU))
        xtrain=encode(train)
        wn=train.weight.to_numpy()/train.weight.mean()
        models={}
        for model_name in ['full','covariates_only']:
            cols=xtrain.columns.tolist() if model_name=='full' else [c for c in xtrain if c not in DIET]
            m=XGBClassifier(**PARAM)
            m.fit(xtrain[cols],train.y,sample_weight=wn)
            m.save_model(out/f'{model_name}_model.json')
            models[model_name]=(m,cols)
        train_summary={'n':len(train),'events':int(train.y.sum()),'weighted_prevalence':float(np.average(train.y,weights=train.weight)),'n_psus':train[['SDMVSTRA','SDMVPSU']].drop_duplicates().shape[0]}
        for label,test in tests.items():
            x=encode(test,xtrain.columns)
            row=test[['participant_id','SEQN','cycle','SDMVSTRA','SDMVPSU','y','weight']].reset_index(drop=True)
            for model_name,(m,cols) in models.items():
                p=m.predict_proba(x[cols])[:,1]
                row[f'probability_{model_name}']=p
                result=score(test.y,p,test.weight)
                result.update(dietary_days=mode,test_set=label,model=model_name,train_n=len(train),train_events=int(train.y.sum()))
                metrics.append(result)
                fpr,tpr,threshold=roc_curve(test.y,p,sample_weight=test.weight)
                pd.DataFrame({'false_positive_rate':fpr,'true_positive_rate':tpr,'threshold':threshold}).to_csv(out/f'{label}_{model_name}_ROC.csv',index=False)
                precision,recall,prthreshold=precision_recall_curve(test.y,p,sample_weight=test.weight)
                pd.DataFrame({'precision':precision,'recall':recall,'threshold':np.r_[prthreshold,np.nan]}).to_csv(out/f'{label}_{model_name}_PR.csv',index=False)
            row.to_csv(out/f'{label}_predictions.csv',index=False)
            m,cols=models['full']
            dm=DMatrix(x[cols],feature_names=cols)
            sv=m.get_booster().predict(dm,pred_contribs=True)
            margin=m.get_booster().predict(dm,output_margin=True)
            maxerr=float(np.max(np.abs(sv.sum(axis=1)-margin)))
            assert maxerr<3e-5
            assert np.max(np.abs(1/(1+np.exp(-sv.sum(axis=1)))-row.probability_full))<3e-6
            groups={}
            for j,col in enumerate(cols):
                groups.setdefault(col.split('::')[0],[]).append(j)
            grouped=pd.DataFrame({g:sv[:,js].sum(axis=1) for g,js in groups.items()})
            importance=[]
            for g in groups:
                importance.append({'variable':g,'weighted_mean_abs_SHAP_log_odds':float(np.average(np.abs(grouped[g]),weights=test.weight)),'weighted_mean_SHAP_log_odds':float(np.average(grouped[g],weights=test.weight)),'unweighted_mean_abs_SHAP_log_odds':float(np.abs(grouped[g]).mean()),'is_dietary':g in DIET})
            imp=pd.DataFrame(importance).sort_values('weighted_mean_abs_SHAP_log_odds',ascending=False).reset_index(drop=True)
            imp['overall_rank']=np.arange(1,len(imp)+1)
            imp['dietary_rank']=np.nan
            imp.loc[imp.is_dietary,'dietary_rank']=np.arange(1,imp.is_dietary.sum()+1)
            imp.to_csv(out/f'{label}_SHAP_importance.csv',index=False)
            pd.DataFrame(sv,columns=cols+['BASE_VALUE']).assign(participant_id=test.participant_id.to_numpy()).to_csv(out/f'{label}_SHAP_onehot.csv.gz',index=False,compression='gzip')
            grouped.assign(participant_id=test.participant_id.to_numpy(),base_value=sv[:,-1],model_log_odds=margin,probability=row.probability_full.to_numpy(),weight=test.weight.to_numpy()).to_csv(out/f'{label}_SHAP_grouped.csv.gz',index=False,compression='gzip')
            test[['participant_id']+NUM+CAT].to_csv(out/f'{label}_feature_values.csv.gz',index=False,compression='gzip')
            # Every participant retained: these columns support protein/fat dependence plots.
            pd.DataFrame({'participant_id':test.participant_id.to_numpy(),'protein_pct':test.protein_pct.to_numpy(),'protein_SHAP':grouped.protein_pct,'fat_pct':test.fat_pct.to_numpy(),'fat_SHAP':grouped.fat_pct,'bmi':test.bmi.to_numpy(),'energy_kcal':test.energy_kcal.to_numpy(),'weight':test.weight.to_numpy()}).to_csv(out/f'{label}_protein_fat_dependence.csv',index=False)
            # Deterministic example: probability nearest the test-set median; not chosen for favorable protein attribution.
            median=float(row.probability_full.median())
            k=int(np.argmin(np.abs(row.probability_full.to_numpy()-median)))
            individual=pd.DataFrame({'variable':list(groups),'SHAP_log_odds':grouped.iloc[k].to_numpy(),'feature_value':[test.iloc[k][g] for g in groups]})
            individual.to_csv(out/f'{label}_individual_waterfall.csv',index=False)
            audit={'max_SHAP_additivity_error_log_odds':maxerr,'example_participant_id':str(test.iloc[k].participant_id),'example_rule':'Prediction nearest unweighted median predicted probability','example_base_value':float(sv[k,-1]),'example_log_odds':float(margin[k]),'example_probability':float(row.probability_full.iloc[k]),'train':train_summary,'test_psus':int(test[['SDMVSTRA','SDMVPSU']].drop_duplicates().shape[0]),'unseen_category_counts':{c:int((~test[c].isin(train[c].unique())).sum()) for c in CAT},'protein_rank':imp[imp.variable=='protein_pct'].to_dict('records')}
            (out/f'{label}_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
            print(mode,label,json.dumps(score(test.y,row.probability_full,test.weight)),flush=True)
            print(imp[['variable','overall_rank','dietary_rank','weighted_mean_abs_SHAP_log_odds']].to_string(index=False),flush=True)
        (out/'encoded_feature_names.json').write_text(json.dumps(xtrain.columns.tolist(),indent=2),encoding='utf-8')
    pd.DataFrame(metrics).to_csv(ROOT/'model_metrics.csv',index=False)
    (ROOT/'software_versions.json').write_text(json.dumps({'python':platform.python_version(),'pandas':pd.__version__,'numpy':np.__version__,'xgboost':xgboost.__version__,'sklearn':sklearn.__version__},indent=2),encoding='utf-8')

if __name__=='__main__':
    main()
