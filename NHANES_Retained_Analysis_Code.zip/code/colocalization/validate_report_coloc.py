from pathlib import Path
import json,hashlib,shutil
import pandas as pd
import numpy as np
from scipy.special import logsumexp
root=Path('./project/Workspaces/AN_colocalization_20261014');out=Path('./project/outputs/AN_colocalization_20261014')
r=pd.read_csv(out/'Coloc_primary_results.csv');s=pd.read_csv(out/'Coloc_prior_sdY_sensitivity.csv');a=pd.read_csv(out/'Coloc_variant_matching_audit.csv')
maxerr=0
for row in s.itertuples():
    d=pd.read_csv(root/'matched'/(row.tissue+'__'+row.gene.split('.')[0]+'.csv'))
    v1=d.AN_se.to_numpy()**2;v2=d.eqtl_se.to_numpy()**2
    rr1=.2**2/(.2**2+v1);rr2=(.15*row.sdY)**2/((.15*row.sdY)**2+v2)
    l1=.5*(np.log1p(-rr1)+rr1*(d.AN_beta.to_numpy()/d.AN_se.to_numpy())**2)
    l2=.5*(np.log1p(-rr2)+rr2*(d.eqtl_beta.to_numpy()/d.eqtl_se.to_numpy())**2)
    p1=row.p1 if row.p1*len(d)<1 else 1/(len(d)+1)
    p2=row.p2 if row.p2*len(d)<1 else 1/(len(d)+1)
    p12=row.p12 if row.p12*len(d)<1 else 1/(len(d)+1)
    lsum=logsumexp(l1+l2);lprod=logsumexp(l1)+logsumexp(l2)
    h3=lprod+np.log1p(-min(np.exp(lsum-lprod),1))
    logh=np.array([0,np.log(p1)+logsumexp(l1),np.log(p2)+logsumexp(l2),np.log(p1*p2)+h3,np.log(p12)+lsum])
    pp=np.exp(logh-logsumexp(logh))
    expected=np.array([getattr(row,f'PP_H{i}') for i in range(5)])
    maxerr=max(maxerr,float(np.max(np.abs(pp-expected))))
assert len(r)==50 and len(s)==300 and maxerr<1e-8,(len(r),len(s),maxerr)
assert np.max(np.abs(r[[f'PP_H{i}' for i in range(5)]].sum(axis=1)-1))<1e-8
supports=r[r.PP_H4>=.8]
# R data.frame names include a literal decimal point in the robust flag.
def flag(df):return df['prior_sdY_robust_H4_0.8'].astype(str).str.upper().eq('TRUE')
robust=r[flag(r)]
counts=r.assign(shared=r.PP_H4>=.8,distinct=r.PP_H3>=.8,robust=flag(r)).groupby('tissue').agg(tests=('gene','size'),shared_support=('shared','sum'),distinct_support=('distinct','sum'),sensitivity_robust=('robust','sum'))
counts['inconclusive']=counts.tests-counts.shared_support-counts.distinct_support
counts.to_csv(out/'Coloc_tissue_summary.csv')
v=pd.read_csv(root/'audit/Coloc_SNP_posteriors_all.csv.gz')
posterior_sums=v.groupby(['tissue','gene'])['SNP.PP.H4'].sum()
assert len(posterior_sums)==50 and np.max(np.abs(posterior_sums-1))<1e-8
top=out/'Coloc_top_shared_variants.csv';tv=pd.read_csv(top);assert len(tv)==50
assert (a.matched_variants>0).all()
hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'code').glob('*') if p.is_file()}
validation=dict(status='PASS',tests=50,sensitivity_runs=300,independent_ABF_recalculation_max_abs_error=maxerr,
    shared_SNP_posterior_sum_max_abs_error=float(np.max(np.abs(posterior_sums-1))),shared_SNPs_total_records=int(a.matched_variants.sum()),
    matched_fraction_range=[float(a.matched_fraction.min()),float(a.matched_fraction.max())],
    upstream_coloc_version='6.0.3',upstream_source_sha256=hashes,implementation='Unmodified cached upstream R coloc.abf functions; not an installed coloc package.',
    coloc_susie_run=False,reason_susie_not_run='No study-matched dense regional eQTL LD matrix; MASHR sparse covariance cannot substitute.',
    priors_primary={'p1':1e-4,'p2':1e-4,'p12':1e-5},prior_sensitivity=[1e-6,1e-5,1e-4],sdY_sensitivity=['1 (standardized expression)','estimated with per-variant sample sizes'],
    mapped_by='Exact rsID plus compatible REF/ALT (including strand checks); no direct join of GRCh37 and GRCh38 positions.',
    SNP_filter='No association-P threshold and no LD clumping; GWAS INFO >=0.9, finite beta and positive SE, nonmonomorphic eQTL.',
    single_causal_variant_assumption=True)
(out/'validation.json').write_text(json.dumps(validation,indent=2),encoding='utf-8')
report=['# AN 脑组织 TWAS 共定位分析','',f'完成前额叶 BA9 与尾状核共50个显著基因–组织组合的单因果变异共定位分析，涉及{r.gene.nunique()}个基因。',
    '',f'主设置 PP.H4 ≥ 0.80：{len(supports)}个组合，涉及{supports.gene.nunique()}个基因；其中{len(robust)}个组合在全部6组先验/表达尺度设置中均达到0.80。',
    f'PP.H3 ≥ 0.80（更支持两个不同关联信号）：{int((r.PP_H3>=.8).sum())}个组合；其他{int(((r.PP_H4<.8)&(r.PP_H3<.8)).sum())}个组合证据未定。','',counts.to_string(),'',
    '## 分析定义','',
    '- eQTL：eQTL Catalogue 官方导入并协调的 GTEx v8 原始统计量（不是2026年更新的 GTEx v10 重新处理数据）。前额叶最大样本量175，尾状核194；少数 SNP 样本量减少，记录逐 SNP 保留。',
    '- GENCODE v26 GRCh38 基因转录起始位置上下游各1 Mb；不按 P 值过滤，不做LD clumping。区域内全部可共同匹配且通过质量控制的变异用于分析。',
    '- AN：PGC 2019，16,992例、55,525对照，原始 GRCh37；通过 rsID 及等位基因匹配到 eQTL GRCh38 变异，不直接匹配不同版本的坐标。GWAS INFO≥0.9 与此前 TWAS 一致。',
    '- 直接使用上游 coloc 6.0.3 未改动的 coloc.abf R 函数。完整 coloc 包未安装，代码版本及哈希已冻结，不能声称运行了 coloc.susie。',
    '- 默认每 SNP 先验 p1=p2=1e-4、p12=1e-5；p12=1e-6/1e-4 为敏感性，结合标准化表达 sdY=1 和由效应标准误/MAF/逐 SNP N 估计的 sdY，共6种设置。',
    f'- {int((r.p1!=r.p1_used).sum())}个主分析组合因区域SNP数≥10,000触发上游软件的自动先验调整（p1/p2=1/(SNP数+1)）；请求值与实际使用值均保留为p1/p1_used等列。',
    '- H0：均无关联；H1：只有 AN；H2：只有表达；H3：两者有关联但不同信号；H4：共享一个信号。',
    '- PP 是模型条件下的后验概率，不是 P 值，不对 PP 做 BH 校正；PP.H4≥0.8为本分析使用的支持阈值，完整50项与300项敏感性结果全部提供。',
    '', '## 结果边界','',
    '- H4支持共享遗传信号，不证明该基因因果介导AN，不证明某脑区更重要，也不验证膳食保护机制。',
    '- 单因果变异假设尚未被多信号精细定位替代；复杂LD区域（尤其MHC）须谨慎。现有TWAS预测模型的稀疏协方差不是完整区域的eQTL LD。',
    '- PP.H4低可能是H3不同信号，也可能是表达/AN信号不足；分别报告，不能一概当作阴性。',
    '- 50项不是50个独立位点：相关基因可能共享同一GWAS信号，两个组织也来自同一GTEx资源，不属于独立生物学重复。',
    f'- 相比原eQTL全区间的共同变异覆盖率为{a.matched_fraction.min():.1%}–{a.matched_fraction.max():.1%}；50项均因低于80%标记coverage_caution，{int((~a.eqtl_lead_snp_in_shared).sum())}项的最强原始eQTL变异未匹配。结果因此须作为有覆盖限制的探索性共定位，不能宣称完成充分验证。',
    '- C4A位于MHC复杂区域；尾状核C4A最强原始eQTL变异未被共同数据集保留；C4A与SNX27支持均未通过保守先验下的稳定性阈值。',
    '', '## H4支持组合','']
for x in supports.sort_values('PP_H4',ascending=False).itertuples():
    report.append(f'- {x.gene_name} / {x.tissue}: PP.H4={x.PP_H4:.6f}，PP.H3={x.PP_H3:.6f}，共有SNP={x.nsnps:.0f}，敏感性最低PP.H4={x.min_PP_H4_across_prior_sdY_sensitivity:.6f}。')
if not len(supports):report.append('没有组合达到预设0.80阈值。')
report+=['','## 复核','',f'300项结果均用独立 Python ABF 计算复核；最大绝对差={maxerr:.3g}。所有模型PP与共享条件下逐SNP后验之和均为1。未生成图片。',
    '', '## 来源','',
    'https://www.ebi.ac.uk/eqtl/Studies/',
    'https://ftp.ebi.ac.uk/pub/databases/spot/eQTL/imported/GTEx_V8/ge/',
    'https://chr1swallace.github.io/coloc/articles/a02_data.html',
    'https://chr1swallace.github.io/coloc/articles/a03_enumeration.html']
(out/'Analysis_report_CN.md').write_text('\n'.join(report),encoding='utf-8')
method='''Colocalization analysis was performed for all 50 AN-associated TWAS gene-tissue models in the frontal cortex (BA9) or caudate, representing 39 unique genes. Original GTEx v8 cis-eQTL summary statistics, harmonized and distributed by the eQTL Catalogue, were retrieved within 1 Mb of each GENCODE v26 transcription start site. Variants were matched to PGC 2019 AN summary statistics by rsID and compatible alleles, retaining variants with AN imputation INFO >= 0.9 and valid effect estimates and standard errors without association-P filtering or LD clumping. The unmodified upstream coloc.abf implementation (coloc source version 6.0.3) was used under a single causal variant assumption with per-variant priors p1=p2=1e-4 and p12=1e-5. Sensitivity analyses varied p12 from 1e-6 to 1e-4 and compared standardized expression variance with summary-statistic-based expression variance estimates. PP.H4 >= 0.80 was considered evidence supporting a shared signal; PP.H3 and variant coverage were also reported. Posterior probabilities were not treated as frequentist P values. Multi-signal colocalization and causal mediation were not established by this analysis.
'''
result=f'Of the 50 gene-tissue models examined, {len(supports)} showed posterior support for a shared AN and cis-eQTL signal (PP.H4 >= 0.80), involving {supports.gene.nunique()} unique genes. Of these models, {len(robust)} retained PP.H4 >= 0.80 across all prior and expression-scale sensitivity settings. In contrast, {int((r.PP_H3>=.8).sum())} models favored distinct signals (PP.H3 >= 0.80), and the remaining {int(((r.PP_H4<.8)&(r.PP_H3<.8)).sum())} were inconclusive. These findings prioritize gene-tissue associations under the single causal variant assumption and do not establish regional specificity or dietary mediation.\n'
(out/'Methods_Results_EN.txt').write_text(method+'\n'+result,encoding='utf-8')
code=out/'code';code.mkdir(exist_ok=True)
for fn in ['fetch_coloc_eqtl.py','match_coloc_gwas.py','run_coloc_analysis.R','validate_report_coloc.py']:
    shutil.copyfile(Path('work')/fn,code/fn)
up=code/'coloc_upstream';up.mkdir(exist_ok=True)
for p in (root/'code').iterdir():
    if p.is_file():shutil.copyfile(p,up/p.name)
(out/'README.txt').write_text('''AN colocalization outputs; no images generated.
Coloc_primary_results.csv: all 50 primary analyses.
Coloc_prior_sdY_sensitivity.csv: all 300 sensitivity analyses.
Coloc_H4_supported.csv: PP.H4 >=0.80 subset (includes unstable results; inspect sensitivity flag).
Coloc_variant_matching_audit.csv: complete target-variant coverage and exclusions.
Coloc_top_shared_variants.csv: most probable variant conditional on H4 for each model; this is not a causal SNP claim for unsupported models.
Coloc_tissue_summary.csv: two-tissue descriptive summary.
Analysis_report_CN.md and Methods_Results_EN.txt: interpretation and writing draft.
validation.json: independent numeric verification and cached-source hashes.
Full eQTL/AN matching inputs and per-SNP posterior data remain under ./project/Workspaces/AN_colocalization_20261014/.
Upstream functions are sourced verbatim, not a full installed coloc package; coloc.susie has not been run.
Anatomical choice is not validated against the other brain tissues by these two-tissue analyses.
''',encoding='utf-8')
print(counts.to_string());print('Primary H4 supports',len(supports),'unique genes',supports.gene.nunique(),'robust',len(robust));print('Independent calculation error',maxerr)
print(supports[['tissue','gene_name','PP_H3','PP_H4','min_PP_H4_across_prior_sdY_sensitivity']].sort_values('PP_H4',ascending=False).to_string(index=False))
