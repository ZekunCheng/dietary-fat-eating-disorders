from pathlib import Path
import sys,json,csv
sys.path.insert(0,'./project/Workspaces/dietary_fat_AN_MR/runtime/python-deps')
import pandas as pd
import numpy as np
root=Path('./project/Workspaces/AN_colocalization_20261014');out=Path('./project/outputs/AN_colocalization_20261014')
targets=pd.read_csv(out/'Coloc_targets_50.csv')
tables={};ids=set()
for x in targets.itertuples():
    key=x.tissue+'__'+x.gene_stable
    d=pd.read_csv(root/'eqtl'/(key+'.csv.gz'));tables[key]=d;ids.update(d.rsid.dropna().astype(str))
source=Path('./project/Workspaces/dietary_fat_AN_MR/raw/pgcAN2.2019-07.vcf.tsv.gz')
cache=root/'raw/AN_target_eQTL_variants.csv.gz'
if not cache.exists():
    parts=[]
    cols=['CHROM','POS','ID','REF','ALT','BETA','SE','PVAL','IMPINFO','NEFFDIV2','NCAS','NCON']
    for i,c in enumerate(pd.read_csv(source,sep='\t',comment='#',usecols=cols,encoding='utf-8',chunksize=400000)):
        parts.append(c[c.ID.isin(ids)]);print('GWAS scan chunk',i+1,'retained',sum(len(p) for p in parts),flush=True)
    pd.concat(parts).to_csv(cache,index=False,compression='gzip')
gwas=pd.read_csv(cache);gwas=gwas.drop_duplicates('ID',keep=False).set_index('ID')
complement=str.maketrans('ACGT','TGCA');audit=[];excluded=[];manifest=[]
for x in targets.itertuples():
    key=x.tissue+'__'+x.gene_stable;d=tables[key]
    # Variant may have several rsIDs. Retain one match per GRCh38 variant; check concordance below.
    matched=[];reasons={}
    for r in d.itertuples():
        reason=None; sign=None
        if r.rsid not in gwas.index:reason='absent_or_duplicated_GWAS_rsid'
        elif not np.isfinite(r.beta) or not np.isfinite(r.se) or r.se<=0 or not np.isfinite(r.maf) or r.maf<=0:reason='invalid_eQTL_statistics'
        else:
            a=gwas.loc[r.rsid]
            if not np.isfinite(a.BETA) or not np.isfinite(a.SE) or a.SE<=0:reason='invalid_GWAS_statistics'
            elif not np.isfinite(a.IMPINFO) or a.IMPINFO<.9:reason='GWAS_INFO_below_0.9'
            else:
                pair=(str(a.REF),str(a.ALT));target=(str(r.ref),str(r.alt))
                if pair==target:sign=1
                elif pair==target[::-1]:sign=-1
                elif all(len(z)==1 and z in 'ACGT' for z in pair+target):
                    strand=tuple(z.translate(complement) for z in pair)
                    if strand==target:sign=1
                    elif strand==target[::-1]:sign=-1
                    else:reason='allele_mismatch'
                else:reason='allele_mismatch'
        if reason:
            reasons[reason]=reasons.get(reason,0)+1
            excluded.append(dict(tissue=x.tissue,gene=x.gene_stable,variant=r.variant,rsid=r.rsid,reason=reason))
            continue
        matched.append(dict(snp=r.variant,rsid=r.rsid,chrom38=r.chromosome,position38=r.position,
            ref38=r.ref,alt38=r.alt,eqtl_beta=r.beta,eqtl_se=r.se,eqtl_p=r.pvalue,eqtl_maf=r.maf,eqtl_N=r.an/2,
            AN_beta=sign*a.BETA,AN_se=a.SE,AN_p=a.PVAL,AN_INFO=a.IMPINFO,
            AN_position37=a.POS,AN_chrom37=a.CHROM,AN_NCAS=a.NCAS,AN_NCON=a.NCON,AN_NEFFDIV2=a.NEFFDIV2,
            palindromic=set([r.ref,r.alt]) in [set('AT'),set('CG')]))
    m=pd.DataFrame(matched)
    if len(m):
        for _,c in m.groupby('snp'):
            if len(c)>1:
                assert np.ptp(c.AN_beta)<1e-8 and np.ptp(c.AN_se)<1e-8,'discordant GWAS aliases'
        m=m.drop_duplicates('snp').sort_values('position38');m.to_csv(root/'matched'/(key+'.csv'),index=False)
        assert int(m.eqtl_N.max()) in [175,194] and (m.eqtl_N>0).all()
    eqlead=d.loc[d.pvalue.idxmin()] if len(d) else None
    audit.append(dict(tissue=x.tissue,gene=x.gene,gene_stable=x.gene_stable,gene_name=x.gene_name,
        TWAS_Z=x.Z,TWAS_FDR=x.FDR_all_genes_12_tissues,region_chrom38=x.chrom,region_start38=x.region_start,region_end38=x.region_end,
        eQTL_records=len(d),eQTL_unique_variants=d.variant.nunique(),matched_variants=len(m),
        matched_fraction=len(m)/d.variant.nunique() if len(d) else 0,
        eqtl_N_max=float(m.eqtl_N.max()) if len(m) else None,
        eqtl_N_min=float(m.eqtl_N.min()) if len(m) else None,
        eqtl_variants_with_reduced_N=int((m.eqtl_N<m.eqtl_N.max()).sum()) if len(m) else None,
        eqtl_lead_snp_in_shared=eqlead.variant in set(m.snp) if len(m) else False,
        min_all_eqtl_p=d.pvalue.min() if len(d) else None,
        status='ready' if len(m)>=2 else 'insufficient_shared_variants',exclusion_counts=json.dumps(reasons)))
    manifest.append(dict(tissue=x.tissue,gene=x.gene_stable,file=str(root/'matched'/(key+'.csv'))))
pd.DataFrame(audit).to_csv(out/'Coloc_variant_matching_audit.csv',index=False)
pd.DataFrame(excluded).to_csv(root/'audit/Coloc_excluded_variant_records.csv.gz',index=False,compression='gzip')
pd.DataFrame(manifest).to_csv(root/'audit/matched_manifest.csv',index=False)
print(pd.DataFrame(audit)[['tissue','gene_name','matched_variants','matched_fraction']].to_string(index=False),flush=True)
