.libPaths(unique(c("./project/R/win-library/4.4",.libPaths())))
root <- "./project/Workspaces/AN_colocalization_20261014"
out <- "./project/outputs/AN_colocalization_20261014"
# Use the upstream coloc.abf implementation verbatim, with cached source/hash.
# The full coloc package is not installed; no claim is made that coloc.susie ran.
for (f in c("check.R","private.R","claudia.R")) source(file.path(root,"code",f))
audit <- read.csv(file.path(out,"Coloc_variant_matching_audit.csv"),stringsAsFactors=FALSE)
results <- list(); sens <- list(); variants <- list(); warnings <- list()
for (i in seq_len(nrow(audit))) {
  a <- audit[i,,drop=FALSE]
  if (a$status!="ready") next
  d <- read.csv(file.path(root,"matched",paste0(a$tissue,"__",a$gene_stable,".csv")),stringsAsFactors=FALSE)
  # Standardized GTEx quantitative expression; sdY=1 primary, estimated-sdY sensitivity.
  D1 <- list(snp=d$snp,position=d$position38,beta=d$AN_beta,varbeta=d$AN_se^2,type="cc",s=16992/72517)
  D2 <- list(snp=d$snp,position=d$position38,beta=d$eqtl_beta,varbeta=d$eqtl_se^2,
    MAF=d$eqtl_maf,N=max(d$eqtl_N),type="quant",sdY=1)
  # beta/SE-based primary ABFs do not use N. For sdY estimation, retain per-SNP N.
  sd_est <- suppressWarnings(sdY.est(d$eqtl_se^2,d$eqtl_maf,d$eqtl_N))
  primary <- NULL
  for (scale in c("standardized_sdY_1","estimated_sdY")) for (p12 in c(1e-6,1e-5,1e-4)) {
    E <- D2;E$sdY <- if (scale=="standardized_sdY_1") 1 else sd_est
    w <- character()
    fit <- withCallingHandlers(coloc.abf(D1,E,p1=1e-4,p2=1e-4,p12=p12),warning=function(e){w<<-c(w,conditionMessage(e));invokeRestart("muffleWarning")})
    z <- fit$summary
    row <- data.frame(tissue=a$tissue,gene=a$gene,gene_name=a$gene_name,sdY_mode=scale,sdY=E$sdY,
      p1=1e-4,p2=1e-4,p12=p12,p1_used=unname(fit$priors["p1"]),p2_used=unname(fit$priors["p2"]),p12_used=unname(fit$priors["p12"]),nsnps=unname(z["nsnps"]),
      PP_H0=unname(z["PP.H0.abf"]),PP_H1=unname(z["PP.H1.abf"]),PP_H2=unname(z["PP.H2.abf"]),
      PP_H3=unname(z["PP.H3.abf"]),PP_H4=unname(z["PP.H4.abf"]))
    row$H4_given_H3_or_H4 <- row$PP_H4/(row$PP_H3+row$PP_H4)
    row$min_AN_p_shared <- min(2*pnorm(-abs(d$AN_beta/d$AN_se)))
    row$min_eqtl_p_shared <- min(2*pnorm(-abs(d$eqtl_beta/d$eqtl_se)))
    sens[[length(sens)+1]] <- row
    if (length(w)) warnings[[length(warnings)+1]] <- data.frame(tissue=a$tissue,gene=a$gene,mode=scale,p12=p12,warning=paste(unique(w),collapse="; "))
    if (scale=="standardized_sdY_1" && p12==1e-5) {primary <- row; v <- fit$results}
  }
  ss <- do.call(rbind,sens);ss <- ss[ss$tissue==a$tissue & ss$gene==a$gene,,drop=FALSE]
  primary$min_PP_H4_across_prior_sdY_sensitivity <- min(ss$PP_H4)
  primary$max_PP_H4_across_prior_sdY_sensitivity <- max(ss$PP_H4)
  primary$TWAS_Z <- a$TWAS_Z;primary$TWAS_FDR <- a$TWAS_FDR
  primary$matched_fraction <- a$matched_fraction;primary$eqtl_lead_snp_in_shared <- a$eqtl_lead_snp_in_shared
  primary$interpretation <- if (primary$PP_H4>=.8) "shared_signal_supported_single_causal_assumption" else if (primary$PP_H3>=.8) "distinct_signals_supported" else "inconclusive"
  primary$prior_sdY_robust_H4_0.8 <- min(ss$PP_H4)>=.8
  primary$coverage_caution <- a$matched_fraction<.8 || !a$eqtl_lead_snp_in_shared || nrow(d)<100
  results[[length(results)+1]] <- primary
  v <- merge(d,v,by="snp",all.x=TRUE,sort=FALSE);v$tissue <- a$tissue;v$gene <- a$gene;v$gene_name <- a$gene_name
  variants[[length(variants)+1]] <- v
  cat(i,"/",nrow(audit),a$tissue,a$gene_name,"PP.H4",sprintf("%.5f",primary$PP_H4),"\n")
}
r <- do.call(rbind,results);s <- do.call(rbind,sens);v <- do.call(rbind,variants)
stopifnot(all(abs(rowSums(r[c("PP_H0","PP_H1","PP_H2","PP_H3","PP_H4")])-1)<1e-8))
write.csv(r,file.path(out,"Coloc_primary_results.csv"),row.names=FALSE)
write.csv(s,file.path(out,"Coloc_prior_sdY_sensitivity.csv"),row.names=FALSE)
write.csv(r[r$PP_H4>=.8,,drop=FALSE],file.path(out,"Coloc_H4_supported.csv"),row.names=FALSE)
con <- gzfile(file.path(root,"audit","Coloc_SNP_posteriors_all.csv.gz"),"wt");write.csv(v,con,row.names=FALSE);close(con)
if (length(warnings)) write.csv(do.call(rbind,warnings),file.path(out,"Coloc_warnings.csv"),row.names=FALSE)
write.csv(v[order(-v$SNP.PP.H4),][!duplicated(v[order(-v$SNP.PP.H4),c("tissue","gene")]),],file.path(out,"Coloc_top_shared_variants.csv"),row.names=FALSE)
cat("FINISHED:",nrow(r),"tests;",sum(r$PP_H4>=.8),"H4>=0.8;",sum(r$prior_sdY_robust_H4_0.8),"robust across sensitivity;",sum(r$PP_H3>=.8),"H3>=0.8.\n")
