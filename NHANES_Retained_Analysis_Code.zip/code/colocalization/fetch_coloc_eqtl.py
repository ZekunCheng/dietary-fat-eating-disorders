from pathlib import Path
import sys, gzip, struct, zlib, csv, re, json, hashlib, time
from concurrent.futures import ThreadPoolExecutor
sys.path.insert(0,'./project/Workspaces/dietary_fat_AN_MR/runtime/python-deps')
import requests
ROOT=Path('./project/Workspaces/AN_colocalization_20261014')
for folder in ['raw','eqtl','code','audit','matched']: (ROOT/folder).mkdir(parents=True,exist_ok=True)
OUT=Path('./project/outputs/AN_colocalization_20261014');OUT.mkdir(parents=True,exist_ok=True)
def get(url,path):
    if path.exists(): return path.read_bytes()
    r=requests.get(url,timeout=120);r.raise_for_status();path.write_bytes(r.content);return r.content
def writecsv(p,rows):
    if not rows:return
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
signals=list(csv.DictReader(open('./project/outputs/AN_brain_localization_20261013/AN_TWAS_FDR_signals.csv',encoding='utf-8-sig')))
signals=[x for x in signals if x['tissue'] in ['Frontal_Cortex_BA9','Caudate_basal_ganglia']]
assert len(signals)==50
genes={x['gene'].split('.')[0] for x in signals}
url='https://ftp.ebi.ac.uk/pub/databases/gencode/Gencode_human/release_26/gencode.v26.annotation.gtf.gz'
get(url,ROOT/'raw/gencode.v26.annotation.gtf.gz')
coordinates={}
with gzip.open(ROOT/'raw/gencode.v26.annotation.gtf.gz','rt',encoding='utf-8') as f:
    for line in f:
        if line.startswith('#'):continue
        a=line.split('\t')
        if a[2]!='gene':continue
        gid=re.search(r'gene_id "([^"]+)"',a[8]).group(1).split('.')[0]
        if gid in genes:
            start,end=int(a[3]),int(a[4]);tss=start if a[6]=='+' else end
            coordinates[gid]=dict(chrom=a[0].removeprefix('chr'),gene_start=start,gene_end=end,strand=a[6],tss=tss)
assert genes.issubset(coordinates),str(genes-set(coordinates))
targets=[]
for x in signals:
    x=x.copy();x['gene_stable']=x['gene'].split('.')[0];x.update(coordinates[x['gene_stable']]);
    x['region_start']=max(1,x['tss']-1000000);x['region_end']=x['tss']+1000000;targets.append(x)
writecsv(OUT/'Coloc_targets_50.csv',targets)
writecsv(ROOT/'audit/Coloc_targets_50.csv',targets)
for name in ['DESCRIPTION','R/check.R','R/claudia.R','R/private.R']:
    get('https://raw.githubusercontent.com/chr1swallace/coloc/main/'+name,ROOT/'code'/Path(name).name)
get('https://raw.githubusercontent.com/eQTL-Catalogue/eQTL-Catalogue-resources/master/tabix/Columns.md',ROOT/'audit/eqtl_columns.md')
get('https://raw.githubusercontent.com/eQTL-Catalogue/eQTL-Catalogue-resources/master/tabix/tabix_ftp_paths_imported.tsv',ROOT/'audit/tabix_ftp_paths_imported.tsv')
def parse_tbi(data):
    b=gzip.decompress(data);assert b[:4]==b'TBI\x01'
    vals=struct.unpack_from('<8i',b,4);nref,fmt,seq,beg,end,meta,skip,ln=vals
    names=b[36:36+ln].rstrip(b'\0').decode().split('\0');p=36+ln;idx={}
    for name in names:
        nb=struct.unpack_from('<i',b,p)[0];p+=4;bins={}
        for _ in range(nb):
            bn,nc=struct.unpack_from('<Ii',b,p);p+=8
            chunks=[struct.unpack_from('<QQ',b,p+16*j) for j in range(nc)];p+=16*nc;bins[bn]=chunks
        ni=struct.unpack_from('<i',b,p)[0];p+=4
        linear=struct.unpack_from('<'+'Q'*ni,b,p) if ni else ();p+=8*ni
        idx[name]=(bins,linear)
    return idx,dict(nref=nref,format=fmt,seq_col=seq,beg_col=beg,end_col=end,names=names)
def regbins(start,end):
    end-=1
    bins=[0]
    for off,shift in [(1,26),(9,23),(73,20),(585,17),(4681,14)]:bins.extend(range(off+(start>>shift),off+(end>>shift)+1))
    return bins
def ranges(index,chrom,start,end):
    bn,lin=index[chrom];minoff=lin[min(start>>14,len(lin)-1)] if lin else 0;chunks=[]
    for n in regbins(start,end):
        chunks.extend((a,b) for a,b in bn.get(n,[]) if b>minoff)
    spans=sorted((a>>16,(b>>16)+65536) for a,b in chunks)
    merged=[]
    for a,b in spans:
        if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(merged[-1][1],b))
        else:merged.append((a,b))
    return merged
def iter_bgzf(data):
    p=0;tail=b''
    while p+18<=len(data):
        assert data[p:p+2]==b'\x1f\x8b',(p,data[p:p+5])
        xl=struct.unpack_from('<H',data,p+10)[0];q=p+12;size=None
        while q<p+12+xl:
            si=data[q:q+2];sl=struct.unpack_from('<H',data,q+2)[0]
            if si==b'BC':size=struct.unpack_from('<H',data,q+4)[0]+1
            q+=4+sl
        assert size
        if p+size>len(data):break
        dec=zlib.decompress(data[p:p+size],31);p+=size
        lines=(tail+dec).split(b'\n');tail=lines.pop()
        for line in lines:yield line
def fetch_tissue(tissue):
    url='https://ftp.ebi.ac.uk/pub/databases/spot/eQTL/imported/GTEx_V8/ge/Brain_'+tissue+'.tsv.gz'
    tbidata=get(url+'.tbi',ROOT/'raw'/('Brain_'+tissue+'.tsv.gz.tbi'));index,header=parse_tbi(tbidata)
    # GENCODE TSS +/- 1 Mb matches the released GTEx cis-window.
    ts=[x for x in targets if x['tissue']==tissue]
    rowsbygene={x['gene_stable']:{} for x in ts};regions=[]
    for x in ts:
        chrom=x['chrom'] if x['chrom'] in index else 'chr'+x['chrom']
        regions.extend(ranges(index,chrom,x['region_start']-1,x['region_end']))
    merged=[]
    for a,b in sorted(regions):
        if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(merged[-1][1],b))
        else:merged.append((a,b))
    rg=ROOT/'raw'/tissue;rg.mkdir(exist_ok=True)
    h=requests.get(url,headers={'Range':'bytes=0-65535'},timeout=90);h.raise_for_status();assert h.status_code==206
    columns=next(iter_bgzf(h.content)).decode().split('\t');gid_col=columns.index('gene_id')
    downloads=[]
    for i,(a,b) in enumerate(merged,1):
        path=rg/f'{a}_{b}.bgzf.part'
        if path.exists():data=path.read_bytes()
        else:
            for retry in range(4):
                try:
                    res=requests.get(url,headers={'Range':f'bytes={a}-{b-1}'},timeout=120)
                    res.raise_for_status();assert res.status_code==206
                    assert res.headers.get('Content-Range','').startswith(f'bytes {a}-')
                    data=res.content;path.write_bytes(data);break
                except Exception:
                    if retry==3:raise
                    time.sleep(2)
        count=0
        for line in iter_bgzf(data):
            vals=line.decode().split('\t')
            if len(vals)!=len(columns):continue
            gid=vals[gid_col].split('.')[0]
            if gid not in rowsbygene:continue
            row=dict(zip(columns,vals));key=(row['variant'],row['rsid'])
            rowsbygene[gid][key]=row;count+=1
        downloads.append(dict(start=a,end=b,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
        print(tissue,i,'/',len(merged),'range MB',round(len(data)/1e6,2),'selected rows',count,flush=True)
    counts=[]
    for t in ts:
        gene=t['gene_stable'];rows=list(rowsbygene[gene].values())
        rows=[r for r in rows if r['chromosome'].removeprefix('chr')==t['chrom'] and t['region_start']<=int(r['position'])<=t['region_end']]
        path=ROOT/'eqtl'/f'{tissue}__{gene}.csv.gz'
        with gzip.open(path,'wt',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=columns);w.writeheader();w.writerows(rows)
        counts.append(dict(tissue=tissue,gene=gene,rows=len(rows),min_position=min((int(r['position']) for r in rows),default=None),max_position=max((int(r['position']) for r in rows),default=None)))
    (ROOT/'audit'/f'download_{tissue}.json').write_text(json.dumps(dict(url=url,index_header=header,ranges=downloads,counts=counts),indent=2))
    print('DONE',tissue,'total target eQTL records',sum(x['rows'] for x in counts),flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(fetch_tissue,['Frontal_Cortex_BA9','Caudate_basal_ganglia']))
print('ALL eQTL targets fetched.',flush=True)
