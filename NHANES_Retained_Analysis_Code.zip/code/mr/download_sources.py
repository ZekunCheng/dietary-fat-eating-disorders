"""Optional network reconstruction of source files. Existing derived inputs suffice for offline MR reruns."""
from pathlib import Path
import sys,hashlib,time,json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'runtime/python-deps'))
import requests,pandas as pd
RAW=ROOT/'raw';RAW.mkdir(exist_ok=True)
def download(url,path,expected_size=None,md5=None):
 if path.exists() and (expected_size is None or path.stat().st_size==expected_size):
  if md5 is None or digest(path)==md5:return
 part=Path(str(path)+'.part')
 for attempt in range(5):
  try:
   offset=part.stat().st_size if part.exists() else 0
   headers={'Range':f'bytes={offset}-'} if offset else {}
   with requests.get(url,headers=headers,stream=True,timeout=(30,120)) as r:
    r.raise_for_status();append=bool(offset and r.status_code==206)
    with part.open('ab' if append else 'wb') as f:
     for block in r.iter_content(2**20):f.write(block)
   if expected_size and part.stat().st_size!=expected_size:raise IOError('Incomplete source file')
   if md5 and digest(part)!=md5:raise IOError('Official MD5 mismatch')
   part.replace(path);return
  except Exception as e:print(path.name,'attempt',attempt+1,type(e).__name__,flush=True)
 raise RuntimeError(f'Cannot obtain {path.name}')
def digest(path):
 h=hashlib.md5()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
if __name__=='__main__':
 for phenotype,label in [('FatIntake','unadjusted'),('FatIntakeBMIadj','BMIadjusted')]:
  z=requests.get('https://bioindex.hugeamp.org/api/bio/query/dataset-associations',params={'q':f'Merino2022_DietaryIntake_EU,{phenotype}','limit':10000},timeout=90);z.raise_for_status();j=z.json()
  (RAW/f'Merino_{phenotype}_portal_response.json').write_text(z.text,encoding='utf8');df=pd.DataFrame(j['data'])
  if j.get('continuation'):raise ValueError('More portal records available: implement pagination before selecting instruments')
  assert df.pValue.max()>5e-6,'Threshold lies beyond retrieved range; do not assume complete candidate coverage'
  df.to_csv(RAW/f'Merino_FatIntake_{label}_portal.csv',index=False)
  print(phenotype,len(df),'available portal records, not a full GWAS',flush=True)
 z=requests.get('https://api.figshare.com/v2/articles/14671980',timeout=60);z.raise_for_status();j=z.json();(RAW/'PGC_AN2019_metadata.json').write_text(z.text,encoding='utf8')
 target=next(f for f in j['files'] if f['name']=='pgcAN2.2019-07.vcf.tsv.gz')
 download(target['download_url']+'?download=1',RAW/target['name'],target['size'],target['computed_md5'])
 for release in [7,10]:download(f'https://storage.googleapis.com/finngen-public-data-r{release}/summary_stats/R{release}_manifest.tsv',RAW/f'FinnGen_R{release}_manifest.tsv')
 print('Run download_finngen.py separately for complete FinnGen files. Full Merino archive was unavailable in this analysis; see data_sources.csv.')
