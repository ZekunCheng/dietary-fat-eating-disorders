from pathlib import Path
import pandas as pd,subprocess,json,gzip
p=Path(__file__).resolve().parents[1]
plink=p/'runtime/plink/plink.exe'
for label,file in [('unadjusted','Merino_FatIntake_unadjusted_portal.csv'),('BMIadjusted','Merino_FatIntake_BMIadjusted_portal.csv')]:
 d=pd.read_csv(p/'raw'/file);d=d[d.dbSNP.notna() & d.alt.isin(list('ACGT')) & d.reference.isin(list('ACGT'))].drop_duplicates('dbSNP')
 f=p/'analysis'/f'{label}_clump_input.tsv';d.rename(columns={'dbSNP':'SNP','pValue':'P'})[['SNP','P']].to_csv(f,sep='\t',index=False)
 for mode,threshold in [('strict',5e-8),('relaxed',5e-6)]:
  prefix=p/'analysis'/f'clump_{label}_{mode}'
  cmd=[str(plink),'--bfile',str(p/'runtime/ld/EUR'),'--clump',str(f),'--clump-p1',str(threshold),'--clump-p2',str(threshold),'--clump-r2','0.001','--clump-kb','10000','--memory','2048','--threads','2','--out',str(prefix)]
  r=subprocess.run(cmd,capture_output=True,text=True);print(label,mode,r.returncode,flush=True)
  if r.returncode: raise RuntimeError(r.stdout+r.stderr)
  c=pd.read_csv(str(prefix)+'.clumped',sep=r'\s+');print(c[['SNP','P']].to_string(index=False),flush=True)
  d[d.dbSNP.isin(c.SNP)].to_csv(p/'analysis'/f'instruments_{label}_{mode}.csv',index=False)
