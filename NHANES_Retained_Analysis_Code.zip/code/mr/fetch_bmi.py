import sys,json,concurrent.futures
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8');sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime/python-deps'))
import requests,pandas as pd
from scipy.stats import norm
p=Path(__file__).resolve().parents[1];d=pd.read_csv(p/'analysis/instruments_unadjusted_strict.csv')
def get(row):
 vid=row.varId;f=p/'raw'/('variant_'+vid.replace(':','_')+'.json')
 if not f.exists():
  r=requests.get('https://bioindex.hugeamp.org/api/bio/query/variant-dataset-associations',params={'q':vid,'limit':10000},timeout=90);r.raise_for_status();f.write_text(r.text,encoding='utf8')
 dat=json.loads(f.read_text(encoding='utf8'))['data'];hits=[r for r in dat if r['dataset']=='GWAS_UKBiobankGIANT_eu' and r['phenotype']=='BMI']
 if not hits:print(vid,'missing',flush=True);return None
 a=hits[0];print(row.dbSNP,a,flush=True)
 return {'SNP':row.dbSNP,'varId':vid,'effect_allele':row.alt,'other_allele':row.reference,'beta_BMI':a['beta'],'se_BMI_reconstructed':abs(a['beta'])/norm.isf(a['pValue']/2),'p_BMI':a['pValue'],'n_BMI':a['n'],'source':'GWAS_UKBiobankGIANT_eu','SE_method':'abs(beta)/normal.isf(P/2)'}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 rows=list(pool.map(get,[row for _,row in d.iterrows()]))
pd.DataFrame([r for r in rows if r]).to_csv(p/'analysis/BMI_strict_instruments.csv',index=False)
