from pathlib import Path
import shutil,json,hashlib,ast,pandas as pd
p=Path(__file__).resolve().parents[1];out=Path(r'./project/outputs\dietary_fat_AN_MR_20261011')
if out.exists() and not (out/'_generated_by_this_analysis.json').exists():raise RuntimeError('Output directory already exists without this-task marker; preserve it')
out.mkdir(parents=True,exist_ok=True);(out/'_generated_by_this_analysis.json').write_text(json.dumps({'project':'dietary_fat_AN_MR','date':'2026-10-11'}),encoding='utf8')
for folder in ['analysis','raw','scripts/vendor','runtime/plink','runtime/ld','runtime/python-deps','figures','brain_localization/models']:(out/folder).mkdir(parents=True,exist_ok=True)
for f in p.glob('0*.md'):shutil.copy2(f,out/f.name)
for f in (p/'analysis').iterdir():
 if f.is_file() and f.suffix in ['.csv','.json','.txt','.rds','.clumped','.log','.nosex','.tsv']:shutil.copy2(f,out/'analysis'/f.name)
core=['clump.py','harmonize.py','run_mr.R','run_mvmr.R','export_presso_details.R','check_ivw.py','audit_analysis.py','plot_mr.py','build_reports.py','directionality_screen.py','validate_presso.R','download_sources.py','download_finngen.py','extract_outcomes.py','download_reference.py','download_ld_ranges.py','download_brain_models.py','download_brain_expression.py','fetch_bmi.py','reverse_mr_inputs.py','check_an_coordinates.py','export_ld_subset.py','hash_sources.py']
for name in core:
 f=p/'scripts'/name
 if f.suffix=='.py':ast.parse(f.read_text(encoding='utf8'))
 shutil.copy2(f,out/'scripts'/name)
for f in (p/'scripts/vendor').glob('*.R'):shutil.copy2(f,out/'scripts/vendor'/f.name)
for name in ['plink.exe','LICENSE']:shutil.copy2(p/'runtime/plink'/name,out/'runtime/plink'/name)
for ext in ['bed','bim','fam']:shutil.copy2(p/'runtime/ld'/f'EUR_candidates.{ext}',out/'runtime/ld'/f'EUR.{ext}')
for name in ['socks.py','sockshandler.py']:
 f=p/'runtime/python-deps'/name
 if f.exists():shutil.copy2(f,out/'runtime/python-deps'/name)
for f in (p/'runtime/python-deps').glob('PySocks-*.dist-info'):
 shutil.copytree(f,out/'runtime/python-deps'/f.name,dirs_exist_ok=True)
for name in ['Merino_FatIntake_unadjusted_portal.csv','Merino_FatIntake_BMIadjusted_portal.csv','Merino_Supplementary_Tables.xlsx','PGC_AN2019_metadata.json','FinnGen_R7_manifest.tsv','FinnGen_R10_manifest.tsv','README_Merino_PMID34426670.txt']:
 f=p/'raw'/name
 if f.exists():shutil.copy2(f,out/'raw'/name)
for f in (p/'figures').iterdir():shutil.copy2(f,out/'figures'/f.name)
for f in (p/'brain_localization/models').iterdir():shutil.copy2(f,out/'brain_localization/models'/f.name)
for name in ['brain_models_inventory.csv','additional_brain_resources_verified.csv','GSE262138_sample_metadata.csv','GTEx_v8_gene_median_tpm.gct.gz','GTEx_v8_brain_median_TPM.csv','GSE262138_author_TWAS_workflow.md','GSE236077.txt','GSE262138.txt','GSE262138_family.soft.gz']:
 shutil.copy2(p/'brain_localization'/name,out/'brain_localization'/name)
readme='''# 使用说明

先阅读01_MR_Analysis_Report.md（完整分析与限制）、02_MR_Manuscript_Text.md（英文正文/图注）、03_Brain_Region_Resources.md（脑区数据与状态）。

本包含本次冻结数据的复算输入、分析结果、源码、GPL许可的PLINK程序，以及仅覆盖候选工具的欧洲参考基因型子集。完整PGC/FinnGen文件和完整1000G参考保留在原分析项目：./project/Workspaces/dietary_fat_AN_MR。本包的LD子集不能当作完整TWAS/MAGMA参考，不能用于未包含的新GWAS位点。

## 离线复算本次MR

依赖：Python（pandas、numpy、scipy、matplotlib、openpyxl）；R 4.4.2。R分析直接加载包内源函数，只需要base R，不会隐式安装R包。PLINK和本次LD子集已包含。Windows PowerShell在本目录运行：

```powershell
.\\run_analysis.ps1
```

可用-RscriptPath指定另一Rscript.exe路径。复算会写入本目录analysis/figures及报告文件，请先保存自行修改的版本。冻结输入复算已经校核；若更换数据，不能沿用本报告中的固定病例数、工具数或正文结论，需要重新核查报告。

## 图从哪些CSV读取

scripts/plot_mr.py读取analysis/MR_results.csv与analysis/MVMR_results.csv，筛选/组合两面板，并输出figures/MR_forest_panel_a.csv和MR_forest_panel_b.csv供独立作图核对。森林图没有总标题。单独重画：

```powershell
python scripts/plot_mr.py
```

## 重新取得全量源文件（可选，联网）

```powershell
python scripts/download_sources.py
python scripts/download_finngen.py
python scripts/extract_outcomes.py
```

完整Merino压缩包在本次环境无法访问；门户输入是可用候选关联，不是完整GWAS。反向MR未完成，TWAS未执行。不要把候选SNP子集用于完整脂肪TWAS。

GTEx两重点脑区及其他脑组织的模型和协方差已放在brain_localization/models。GTEx基因表达中位TPM亦包含。BrainSeq大文件只核实公开访问，尚未下载，状态和大小在additional_brain_resources_verified.csv。

PGC原始完整文件未重新打包。所有分析只在本地完成，没有向作者发送邮件、申请外部账户或发布数据。
'''
(out/'README.md').write_text(readme,encoding='utf8')
(out/'requirements.txt').write_text('pandas\nnumpy\nscipy\nmatplotlib\nopenpyxl\nrequests[socks]\n',encoding='ascii')
(out/'scripts/vendor/SOURCE_PROVENANCE.md').write_text('''# Algorithm source provenance

Fetched 2026-10-11. Content SHA256 recorded in analysis/source_file_checksums.csv.

- TwoSampleMR_mr.R: https://raw.githubusercontent.com/MRCIEU/TwoSampleMR/master/R/mr.R
- TwoSampleMR_mr_mode.R: https://raw.githubusercontent.com/MRCIEU/TwoSampleMR/master/R/mr_mode.R
- mr_presso.R: https://raw.githubusercontent.com/rondolab/MR-PRESSO/master/R/mr_presso.R
- mr_presso_cached.R: local computational optimization, original retained; same-seed numerical agreement validated. It caches invariant model predictions and uses algebraically equivalent one-exposure leave-one-out formulas. No change to simulated-data law or outlier/distortion definitions.
- MVMR_format_mvmr.R: https://raw.githubusercontent.com/WSpiller/MVMR/master/R/format_function.R
- MVMR_strength_mvmr.R: https://raw.githubusercontent.com/WSpiller/MVMR/master/R/strength_mvmr.R
- MVMR_ivw_mvmr.R: https://raw.githubusercontent.com/WSpiller/MVMR/master/R/ivw_mvmr.R
- MVMR_pleiotropy_mvmr.R: https://raw.githubusercontent.com/WSpiller/MVMR/master/R/pleiotropy_mvmr.R

The complete upstream R packages were not installed. Individual source functions were loaded and called. Upstream repositories provide package licensing/version history. Original algorithm attribution is retained.

PLINK binary: official build 2025-08-19, https://s3.amazonaws.com/plink1-assets/plink_win64_20250819.zip; its GPL license is retained alongside the binary.

LD source: http://fileserve.mrcieu.ac.uk/ld/1kg.v3.tgz, 1000 Genomes Phase 3 European panel, 503 samples. The portable panel is a 2,036-variant subset sufficient for this frozen clumping analysis; it is not genome-wide.
''',encoding='utf8')
print('Output prepared:',out)
