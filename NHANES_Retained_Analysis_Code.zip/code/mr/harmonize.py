from pathlib import Path
import pandas as pd,numpy as np,json
p=Path(__file__).resolve().parents[1]
outcomes={'PGC_AN2019':('ID','ALT','REF','BETA','SE','PVAL',None),'FinnGen_ED_R7':('rsids','alt','ref','beta','sebeta','pval','af_alt'),'FinnGen_BN_R10':('rsids','alt','ref','beta','sebeta','pval','af_alt'),'FinnGen_AN_R10':('rsids','alt','ref','beta','sebeta','pval','af_alt')}
comp=str.maketrans('ACGT','TGCA');allrows=[];audit=[];flow=[]
for label in ['unadjusted','BMIadjusted']:
 for mode in ['strict','relaxed']:
  exp=pd.read_csv(p/'analysis'/f'instruments_{label}_{mode}.csv')
  for name,(sid,ea,oa,b,se,pv,freq) in outcomes.items():
   out=pd.read_csv(p/'analysis'/f'{name}_all_fat_candidates.csv');out=out.drop_duplicates([sid,ea,oa])
   kept=0
   for _,x in exp.iterrows():
    matches=out[out[sid]==x.dbSNP];reason='outcome_missing';result=None
    for _,y in matches.iterrows():
     a,b_=str(x.alt),str(x.reference);c,d=str(y[ea]),str(y[oa]);sign=None;why='allele_mismatch'
     if (c,d)==(a,b_):sign=1
     elif (c,d)==(b_,a):sign=-1
     elif (c.translate(comp),d.translate(comp))==(a,b_):sign=1
     elif (c.translate(comp),d.translate(comp))==(b_,a):sign=-1
     if sign is not None:
      if {a,b_} in [{'A','T'},{'C','G'}]:
       if freq is None:why='palindromic_outcome_EAF_missing';sign=None
       else:
        fx=float(x.eaf);fy=float(y[freq]);same=abs(fx-fy);flipped=abs(fx-(1-fy))
        if min(fx,1-fx)>=.42 or min(fy,1-fy)>=.42:why='palindromic_intermediate_frequency';sign=None
        elif min(same,flipped)>.10:why='palindromic_frequency_mismatch';sign=None
        else:sign=1 if same<flipped else -1
      if sign is not None:
       by=float(y[b])*sign;sy=float(y[se]);bx=float(x.unscaled_beta);sx=float(x.unscaled_stdErr)
       if not np.isfinite([by,sy,bx,sx]).all() or min(sy,sx)<=0:why='invalid_beta_SE';sign=None
       elif (bx/sx)**2<=10:why='weak_instrument_F_le_10';sign=None
       else:
        why='retained';result={'exposure':label,'selection':mode,'outcome':name,'SNP':x.dbSNP,'varId':x.varId,'effect_allele':a,'other_allele':b_,'eaf_exposure':float(x.eaf),'beta_exposure':bx,'se_exposure':sx,'p_exposure':float(x.pValue),'F':(bx/sx)**2,'beta_outcome':by,'se_outcome':sy,'p_outcome':float(y[pv]),'eaf_outcome_aligned':float(y[freq]) if freq and sign==1 else (1-float(y[freq]) if freq else np.nan),'flip_outcome':sign==-1,'n_exposure_portal':x.n}
        break
     reason=why
    if result:allrows.append(result);kept+=1;reason='retained'
    audit.append({'exposure':label,'selection':mode,'outcome':name,'SNP':x.dbSNP,'reason':reason,'outcome_matches':len(matches)})
   flow.append({'exposure':label,'selection':mode,'outcome':name,'clumped':len(exp),'retained':kept})
pd.DataFrame(allrows).to_csv(p/'analysis/harmonized.csv',index=False);pd.DataFrame(audit).to_csv(p/'analysis/harmonization_audit.csv',index=False);pd.DataFrame(flow).to_csv(p/'analysis/instrument_flow.csv',index=False)
print(pd.DataFrame(flow).to_string(index=False))
