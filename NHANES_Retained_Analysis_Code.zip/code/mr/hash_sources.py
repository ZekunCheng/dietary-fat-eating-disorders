from pathlib import Path
import hashlib,json,pandas as pd
p=Path(__file__).resolve().parents[1]
def digest(f):
 h=hashlib.sha256()
 with f.open('rb') as inp:
  for b in iter(lambda:inp.read(2**20),b''):h.update(b)
 return h.hexdigest()
rows=[]
files=['raw/pgcAN2.2019-07.vcf.tsv.gz','raw/finngen_R7_F5_EATING.gz','raw/finngen_R10_F5_BULIMIA.gz','raw/finngen_R10_F5_ANOREX.gz','raw/Merino_FatIntake_unadjusted_portal.csv','raw/Merino_FatIntake_BMIadjusted_portal.csv','raw/Merino_Supplementary_Tables.xlsx','raw/1kg.v3.tgz','brain_localization/mashr_eqtl.tar','brain_localization/GTEx_v8_gene_median_tpm.gct.gz']
for name in files:
 f=p/name
 if f.exists():rows.append({'relative_path':name,'bytes':f.stat().st_size,'sha256':digest(f),'retrieved_on':'2026-10-11'});print('HASH',name,flush=True)
for f in sorted((p/'scripts/vendor').glob('*.R')):rows.append({'relative_path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':digest(f),'retrieved_on':'2026-10-11'})
pd.DataFrame(rows).to_csv(p/'analysis/source_file_checksums.csv',index=False)
