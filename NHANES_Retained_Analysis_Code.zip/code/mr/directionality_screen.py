from pathlib import Path
import pandas as pd,numpy as np
from scipy.stats import norm
p=Path(__file__).resolve().parents[1];d=pd.read_csv(p/'analysis/harmonized.csv').query('exposure=="unadjusted" and selection=="strict"');rows=[]
for out,g in d.groupby('outcome'):
 ks=[.01,.03,.05,.1] if 'ED_' in out else [.001,.005,.01,.02]
 for sd in [6.2,7.2]:
  for k in ks:
   h=2*g.eaf_exposure*(1-g.eaf_exposure);rx=h*(g.beta_exposure/sd)**2;ry=h*(g.beta_outcome*k*(1-k)/norm.pdf(norm.isf(k)))**2
   for snp,x,y in zip(g.SNP,rx,ry):rows.append({'outcome':out,'fat_SD_percentage_points':sd,'assumed_population_prevalence':k,'SNP':snp,'R2_fat_approx':x,'R2_outcome_liability_approx':y,'higher_variance_in_fat':x>y,'caveat':'exploratory variance screen; exposure EAF used as proxy for population EAF; not a formal Steiger test'})
r=pd.DataFrame(rows);r.to_csv(p/'analysis/directionality_variance_screen.csv',index=False)
a=r.groupby(['outcome','fat_SD_percentage_points','assumed_population_prevalence']).agg(nsnp=('SNP','count'),SNPs_favoring_fat=('higher_variance_in_fat','sum'),R2_fat_sum=('R2_fat_approx','sum'),R2_liability_sum=('R2_outcome_liability_approx','sum')).reset_index();a['aggregate_favors_fat']=a.R2_fat_sum>a.R2_liability_sum;a.to_csv(p/'analysis/directionality_screen_summary.csv',index=False);print(a.to_string(index=False))
