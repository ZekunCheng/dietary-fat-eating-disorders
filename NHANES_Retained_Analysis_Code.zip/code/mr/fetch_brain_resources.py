import sys,concurrent.futures
from pathlib import Path
sys.stdout.reconfigure(encoding='utf8');sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime/python-deps'))
import requests
p=(Path(__file__).resolve().parents[1]/'brain_localization');p.mkdir(exist_ok=True)
urls={'GSE236077':'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE236077&targ=self&form=text&view=full','GSE262138':'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE262138&targ=self&form=text&view=full','FUSION':'https://gusevlab.org/projects/fusion/','PredictDB':'https://predictdb.org/post/2021/07/21/gtex-v8-models-on-eqtl-and-sqtl/','PsychENCODE':'https://resource.psychencode.org/','GTEx':'https://gtexportal.org/home/downloads/adult-gtex'}
def get(kv):
 k,u=kv
 try:
  r=requests.get(u,timeout=55);(p/f'{k}.txt').write_text(r.text,encoding='utf8');print(k,r.status_code,len(r.content),flush=True)
  if k.startswith('GSE'):
   for line in r.text.splitlines():
    if any(t in line.lower() for t in ['title =','summary =','overall_design =','cortex','caudate']):print(k,line[:800],flush=True)
 except Exception as e: print(k,type(e).__name__,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(get,urls.items()))
