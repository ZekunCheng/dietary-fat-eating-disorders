from pathlib import Path
import pandas as pd,numpy as np,json,hashlib
p=Path(__file__).resolve().parents[1]
r=pd.read_csv(p/'analysis/MR_results.csv');diag=pd.read_csv(p/'analysis/MR_diagnostics.csv');mv=pd.read_csv(p/'analysis/MVMR_results.csv');corr=pd.read_csv(p/'analysis/MR_PRESSO_corrected.csv')
def table(df):
 cols=list(df.columns);lines=['| '+' | '.join(cols)+' |','|'+'|'.join(['---']*len(cols))+'|']
 for row in df.itertuples(index=False,name=None):lines.append('| '+' | '.join(str(x) for x in row)+' |')
 return '\n'.join(lines)
def fmt(x):return f'{x:.3f}'
main=r.query('exposure=="unadjusted" and selection=="strict" and method=="IVW"').copy();names={'PGC_AN2019':'AN：PGC 2019（主要结局）','FinnGen_ED_R7':'总体 ED：FinnGen R7','FinnGen_BN_R10':'BN：FinnGen R10','FinnGen_AN_R10':'AN：FinnGen R10（外部验证）'}
pretty=pd.DataFrame({'结局':main.outcome.map(names),'SNP数':main.nsnp,'OR（每增加5个百分点脂肪供能）':main.OR_per_5pp.map(fmt),'95% CI':main.apply(lambda x:f'{x.CI_low:.3f}–{x.CI_high:.3f}',axis=1),'双侧P值':main.P.map(fmt)})
main.to_csv(p/'analysis/main_IVW_summary.csv',index=False)
report='''# 膳食总脂肪摄入与进食障碍：重做 MR 分析报告

分析日期：2026-10-11。该报告只覆盖脂肪相关 GWAS/MR 及后续脑区资源核查；没有改动原稿、NHANES、Meta 或 QCA。

## 1. 当前结论

采用目前公开可访问的遗传关联数据后，没有检出脂肪供能比例与 AN、总体 ED 或 BN 的统计学显著关联。主分析和全部预设替代方法的 95% CI 均包含无效值，64 个方法估计均 P>0.05。新结果不能支持“高脂饮食保护 AN”的确定性结论，也不能解释为已经证明不存在作用；尤其 BN 和 MR-Egger 的估计非常不精确。

这次检验的是**总脂肪占总能量的百分比**，不是血清脂质浓度、脂肪酸组成比值、绝对脂肪克数或一次高脂喂养干预。效应统一换算为增加 **5 个百分点**脂肪供能的 OR，例如从 30% 增至 35%，不是相对增加 5%。该指标具有营养组成性质，未指定替代哪一种其他宏量营养素，不能作某一种具体等热量替代的解释。

## 2. 已取得的数据与版本

| 数据 | 用途 | 样本规模 | 实际访问范围 |
|---|---|---|---|
| Merino et al., FatIntake | 主要暴露；BMI未调整 | 原研究总计282,271；门户N字段191,157，存在注释差异 | 官方门户1,501条候选关联，含所用工具位点；不是全量GWAS文件 |
| Merino et al., FatIntakeBMIadj | BMI调整暴露敏感性 | 同上 | 官方门户1,500条候选关联 |
| PGC AN 2019 | 主要结局 | 16,992病例 / 55,525对照 | 完整8,219,102条变异统计，官方MD5校验通过 |
| FinnGen R7 F5_EATING | 总体ED次要结局 | 2,682病例 / 306,472对照 | 完整文件；例数来自官方R7清单 |
| FinnGen R10 F5_BULIMIA | BN次要结局 | 1,126病例 / 400,510对照 | 完整文件；包含非典型BN |
| FinnGen R10 F5_ANOREX | AN外部验证 | 2,115病例 / 400,510对照 | 完整文件；包含非典型AN |
| UKBiobank/GIANT BMI门户关联 | 探索性多变量MR | 各SNP门户注释N不同，未用这些N进行MR计算 | 8个位点的beta/P；FTO有直接SE，其余7个SE由beta和P近似恢复 |

Merino主数据源：[研究与下载说明](https://kp4cd.org/node/1166)，[官方门户](https://t2d.hugeamp.org/dinspector.html?dataset=Merino2022_DietaryIntake_EU)，[原研究](https://doi.org/10.1038/s41562-021-01182-w)。门户BMI调整工具位点的效应值与SE经方向对齐后，7/7与原研究Supplementary Table 10逐项一致。这确认了所用效应的来源及百分比单位，但并未消除门户N字段与原研究总N的注释差异；本次F统计量和MR估计不依赖该N字段，未据此强行计算正式Steiger检验。

PGC：[官方下载页](https://pgc.unc.edu/for-researchers/download-results/)，[2019数据记录](https://figshare.com/articles/dataset/an2019/14671980)。该文件仍可公开取得；采用这一明确临床病例定义的版本，而非将所有新版本自动混合。FinnGen明确使用R7/R10，**不称其为最新版**；各发布版的表型定义和病例数分别记录，没有混合AN、BN、总体ED为一个诊断结局。FinnGen不同结局及不同发布版的受试者存在重叠，没有据此做独立研究的meta合并。

原始全量结局文件保留在项目raw目录；交付包只放复算所需的候选位点子集和分析结果，不重新发布完整PGC数据文件。

## 3. 工具变量与统计方法

主要筛选阈值在检查结局效应前固定为P<5×10⁻⁸，欧洲1000 Genomes Phase 3参考（503人），LD r²<0.001、窗口10,000 kb。参考集含双等位SNP、MAF>1%；缺失于参考集的变异/插入缺失不能参与该流程。P<5×10⁻⁶为放宽阈值的敏感性分析，不能因为出现或未出现显著结果而代替主阈值。

BMI未调整暴露严格筛选得到8个独立位点。PGC AN中rs1229984无匹配统计量，已用同一GRCh37位置再次核查并确认未找到；rs9939609和rs72828544为回文位点，而PGC文件不含EAF，因此保守剔除。主要AN分析保留5个SNP；FinnGen三项分析各保留8个。FinnGen回文位点只有在两侧MAF<0.42、频率可辨认且最小频率差≤0.10时保留。不同基因组版本的FinnGen与暴露以rsID和等位基因核对匹配，没有把GRCh37和GRCh38位置直接相连。

主要AN工具F范围29.900–99.899，中位数33.410；不存在F≤10的保留位点。F=(beta_exposure/SE_exposure)²。所有筛选、LD日志、无法匹配位点和等位基因翻转信息均已保存，没有为获得有利方向而删除工具。

主要估计为乘法随机效应IVW，对残差欠离散作保守校正。替代估计为MR-Egger、加权中位数和加权众数；中位数/众数使用2,000次bootstrap和固定随机种子。异质性采用Cochran Q；水平多效性报告Egger截距和MR-PRESSO（10,000次模拟，必要时检验异常位点与distortion）。同时保存逐SNP Wald比值与leave-one-out。主要AN、总体ED、BN的IVW采用三结局Bonferroni校正；另给出把FinnGen AN验证也纳入的四检验校正。替代模型、BMI调整GWAS和放宽阈值分析均作敏感性分析，不重复定义新的主要阳性结论。

IVW/中位数区间使用正态近似；本报告Egger和众数区间使用与其t检验自由度一致的t分布。Egger的I²GX仅0.718（主要AN），需要考虑NOME偏离和回归稀释，截距不显著不能证明不存在多效性。

算法使用公开TwoSampleMR与MR-PRESSO源函数，未宣称安装了完整TwoSampleMR软件包。MR-PRESSO为避免重复拟合同一数据进行计算缓存，并对单暴露leave-one-out使用代数等价公式；在真实AN输入、相同种子及200次模拟下，原始与优化输出差异小于10⁻¹²。源码、源文件哈希、R会话记录和固定种子均保存。IVW另以Python独立实现交叉核对，所有16组的OR/P差异均小于10⁻¹⁰。

## 4. 主分析

'''+table(pretty)+'''

所有主要IVW比较的Bonferroni校正P均为1.000。方向不能概括为“普遍保护”：PGC AN和BN点估计在1以上，而ED与FinnGen AN在1以下，且区间都很宽。

## 5. 稳健性结果及不能省略的异常情况

主要PGC AN的加权中位数OR=1.009（95% CI 0.532–1.915，P=0.977），加权众数OR=1.741（0.677–4.477，P=0.178），MR-Egger OR=4.684（0.196–111.775，P=0.219）。Egger点估计极不精确，不宜作为机制方向的证据。放宽工具阈值后保留26个AN工具，IVW OR=0.874（0.665–1.150，P=0.337）。BMI调整GWAS保留6个AN工具，IVW OR=0.920（0.539–1.568，P=0.758）。

主要AN未检出明显异质性（Q=5.698，df=4，P=0.223），Egger截距P=0.215，MR-PRESSO全局P=0.2661。主要AN的逐一移除分析没有P<0.05的估计。这些结果是诊断性检查，不代表所有MR假设已被验证。

FinnGen BN有异质性（Q检验P=0.0417），FinnGen AN异质性更明显（P=0.00563）；不能写成“所有结局均无异质性”。FinnGen AN的MR-PRESSO全局P=0.0125，检出rs4420638异常位点（位于APOE附近）。移除后，普通leave-one-out IVW的OR=0.287（0.0856–0.9632，P=0.0433），但四结局校正P=0.1732；仅对该组8次逐一移除校正后P=0.3465，对全部29次主要逐一移除检验校正后P=1.000，且这是异常值驱动后的敏感性结果。MR-PRESSO自身的异常值校正估计使用t检验，P=0.0898，distortion P=0.4729，因此不能据这一删点结果恢复原稿的确定性保护结论。详细校正区间见MR_PRESSO_corrected.csv。

## 6. BMI、多变量分析和方向性

探索性BMI多变量MR使用相同的严格脂肪工具，将fat与BMI的遗传效应共同建模。主要PGC AN的fat直接效应OR=1.072（0.609–1.887，P=0.809）；其他结局亦未检出显著fat效应。这不是把BMI预先调整的fat GWAS当作多变量MR，两种分析分别运行并分别报告。

在跨暴露效应估计误差相关系数rho=-0.5、0、0.5的敏感性设定下，主要AN的fat条件F为53.676、43.215、36.171，BMI条件F为58.928、46.102、37.867，均>10。这仅为条件工具强度对协方差假设的检查；IVW直接效应估计本身没有因为该rho设定重新变化。fat与UKBB/GIANT BMI研究存在样本重叠，真实协方差未知；7个BMI的SE依赖已舍入beta/P的正态近似恢复，因此该多变量结果是探索性敏感性证据，不能称为完全解决BMI相关多效性。

已经对PGC AN的8个独立显著位点尝试反向MR数据提取。门户没有返回这些位点的Merino FatIntake非显著关联；由于完整Merino GWAS压缩包当前连接失败，**未能完成有效的反向MR，也没有用缺失或虚构的beta填补**。没有把该项标为已完成。

另保存一个明确标为探索性的方差方向性筛查：fat原研究SD取6.2或7.2个百分点，AN/BN患病率假定0.1%–2%，ED取1%–10%，并暂以暴露EAF近似人群频率。PGC AN的5个位点在这些设定下均具有较高fat解释方差；FinnGen AN/BN则随患病率和SD设定发生变化。该筛查不是正式Steiger检验，也不能证明因果方向。严格反向MR/Steiger仍需要更完整的数据和更可靠的样本、频率信息。

原研究与结局样本的精确重叠程度无法从现有资料量化，不能写“完全无样本重叠”。主要AN只有5个工具，区间允许明显保护或风险效应；precision_and_detectable_effect.csv给出基于当前SE的近似最小可检出效应，不是观察效应驱动的事后power。

## 7. 对审稿问题的落实情况

| 问题 | 当前落实 | 仍需保留的边界 |
|---|---|---|
| 脂肪暴露定义不清 | 总脂肪供能百分比；每5个百分点统一效应 | 不是绝对克数或固定替代营养素 |
| AN/ED/BN混为同一结局 | 主AN、次ED/BN、FinnGen AN验证分别分析 | NHANES症状与临床诊断不能视为相同 |
| 放宽P阈值、F统计缺失 | 严格主分析+放宽阈值敏感性；逐SNP F、LD日志 | 工具数量有限 |
| 仅IVW、缺多效性/异质性 | 4种MR方法、Q、截距、PRESSO、单SNP、逐一移除 | 阴性诊断检验不验证排除限制 |
| BMI路径 | 预调整GWAS敏感性及探索性MVMR分别完成 | SE恢复、样本重叠与协方差不确定 |
| 多重检验 | 三结局及四比较Bonferroni明确报告 | 删点的名义信号不能升级为主要结论 |
| 反向关系 | 已尝试提取，保存缺失记录与探索方差筛查 | 正式反向MR/Steiger未完成 |
| 脑区定位 | 已找到并下载匹配脑区GTEx预测模型 | TWAS未运行；资源可用不等于脑区富集已证实 |

## 8. 文件索引

- MR_results.csv：所有64个MR方法估计，含OR/CI/P与主检验校正。
- main_IVW_summary.csv：4项严格阈值主要/验证IVW。
- harmonized.csv、harmonization_audit.csv、instrument_flow.csv：工具、F、效应方向、剔除与纳入数量。
- MR_diagnostics.csv、MR_PRESSO_summary.csv、MR_PRESSO_outliers.csv、MR_PRESSO_corrected.csv：诊断与异常值校正。
- MR_leave_one_out.csv、MR_single_SNP.csv：逐一移除和逐SNP作图数据。
- MVMR_results.csv、MVMR_conditional_F.csv、BMI_strict_instruments.csv：BMI分析与输入来源。
- directionality_variance_screen.csv、reverse_AN_fat_harmonized.csv：方向性探索和反向提取失败记录。
- data_sources.csv、Merino_published_table10_validation.csv、analysis_QA.json：来源、版本及校核。
- figures/MR_forest_panel_a.csv、MR_forest_panel_b.csv：合并森林图所读取的数据；scripts/plot_mr.py为绘图代码。
- 02_MR_Manuscript_Text.md：可供正文替换的精简英文方法、结果及图注。
- 03_Brain_Region_Resources.md：匹配DLPFC/尾状核的资源、已下载文件与下一阶段分析边界。
'''
(p/'01_MR_Analysis_Report.md').write_text(report,encoding='utf8')
english='''# Revised MR manuscript text

## Methods

Two-sample Mendelian randomization was used to assess the association between genetically predicted total fat intake, expressed as a percentage of total energy, and anorexia nervosa (AN). Dietary associations were obtained from Merino et al. through the public knowledge portal, and AN associations were obtained from the PGC 2019 GWAS. Registry-defined eating disorders and bulimia nervosa from FinnGen were examined as secondary outcomes, with FinnGen AN used for external validation. Instruments were selected at P<5×10⁻⁸ and clumped using a European reference panel (r²<0.001; 10-Mb window). After allele harmonization, variants with F≤10 and unresolved palindromic variants were excluded. Multiplicative random-effects IVW was the primary estimator; MR-Egger, weighted-median and weighted-mode analyses, Cochran Q, the Egger intercept, MR-PRESSO and leave-one-out analyses assessed robustness. Results were expressed as ORs per 5-percentage-point increase in energy from total fat. Bonferroni correction was applied across the three main outcome comparisons. Sensitivity analyses used a relaxed instrument threshold and BMI-adjusted dietary GWAS associations. Exploratory multivariable MR additionally modeled BMI, with conditional instrument strength assessed under alternative cross-exposure covariance assumptions.

Data-access note for the Methods/Supplement: the complete outcome GWAS files were downloaded. Dietary instruments came from available portal associations rather than a complete GWAS archive. The source study reports up to 282,271 participants, whereas the portal N annotation is 191,157; beta/SE values for seven BMI-adjusted instruments were verified against the published supplementary table. Seven BMI SEs for multivariable MR were approximately reconstructed from reported beta and P, and the FTO SE was directly reported. Formal reverse MR was not completed because the required dietary associations at AN lead variants were unavailable. The portal N annotation was not used to estimate MR effects or instrument F statistics.

## Results

Eight independent instruments were selected for total fat intake, of which five were retained for the primary AN analysis after harmonization (F=29.9–99.9). Genetically predicted fat intake was not significantly associated with AN (OR per 5-percentage-point increase=1.030, 95% CI 0.581–1.828; P=0.918). Associations with overall eating disorders (OR=0.918, 95% CI 0.412–2.047; P=0.834), bulimia nervosa (OR=1.357, 95% CI 0.231–7.981; P=0.735) and FinnGen AN (OR=0.533, 95% CI 0.117–2.425; P=0.416) were also not significant. Alternative estimators and sensitivity analyses using relaxed selection, BMI-adjusted dietary associations and exploratory BMI multivariable MR did not yield significant fat-intake effects.

The primary AN analysis showed no statistically significant heterogeneity (Q-test P=0.223) or directional pleiotropy (Egger-intercept P=0.215; MR-PRESSO global P=0.266). However, heterogeneity was detected for FinnGen bulimia nervosa and AN. MR-PRESSO identified rs4420638 as an outlier in FinnGen AN; the outlier-corrected MR-PRESSO estimate remained non-significant (P=0.090). A nominal association in the corresponding leave-one-out IVW analysis did not survive correction across four comparisons. These findings provide no conclusive genetic evidence for a protective association, although imprecision prevents exclusion of meaningful effects.

## Figure legend

**Figure 4. Mendelian randomization estimates for total dietary fat intake and eating disorder outcomes.** (A) Multiplicative random-effects IVW estimates for AN in PGC 2019, AN in FinnGen R10, overall eating disorders in FinnGen R7, and bulimia nervosa in FinnGen R10. (B) Primary AN estimates across alternative MR methods, relaxed instrument selection (P<5×10⁻⁶), BMI-adjusted exposure GWAS, and exploratory BMI multivariable MR. Points indicate ORs per 5-percentage-point increase in energy from total fat; horizontal lines indicate two-sided 95% CIs. The dashed line indicates OR=1. Logarithmic horizontal ranges differ between panels to accommodate the imprecise MR-Egger estimate. Primary AN uses five instruments; panel-B relaxed and BMI-adjusted analyses use 26 and six, respectively. See source-data CSVs for method-specific intervals, SNP counts and P values. BMI multivariable results should be interpreted in light of approximate SE reconstruction and unquantified cross-exposure covariance.
'''
(p/'02_MR_Manuscript_Text.md').write_text(english,encoding='utf8')
brain='''# 用于DLPFC和尾状核定位的公开数据

核查日期：2026-10-11。**已完成资源核查与下载，没有运行TWAS或宣称发现脑区富集。**

## 原转录组脑区和疾病定义

GSE236077是小鼠禁食/高脂饮食研究，包含前额叶、下丘脑、海马等脑区；它不是人类AN转录组。[GEO](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE236077)

GSE262138是人类进食障碍/OCD尸后脑组织，包含**DLPFC和尾状核**。[GEO](https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE262138)。下载的SOFT共有338份样本，两脑区各169份：每脑区57 ED、27 OCD、85对照；研究文字称86对照，故后续以实际样本清单与矩阵对应关系为准，不能把两脑区样本数直接当成独立供者数。

原文描述57例ED中8例AN-R、14例AN-BP、11例BN，其余为未明确ED；GEO逐样本标签只有ED/OCD/control，当前公开SOFT中没有AN亚型到GSM的映射，作者代码仓库也未附临床映射表。因此不能把全部57 ED称为AN，不能仅凭样本标题反推亚型。相关研究已于2026年发表：[Cell Reports记录](https://pubmed.ncbi.nlm.nih.gov/42295976/)。亚型数字在[公开方法全文](https://pmc.ncbi.nlm.nih.gov/articles/PMC11623724/)中可核查；正式稿与预印本版本需明确区分。

## 已下载、可用于下一步分析的数据

| 数据 | 精确脑区/文件 | 本地核查结果 | 用途 |
|---|---|---|---|
| GTEx v8 MASHR eQTL模型 | mashr_Brain_Frontal_Cortex_BA9.db + 同名.txt.gz | 14,091个有模型基因；SQLite与协方差文件均存在 | 对应人类额叶BA9、与DLPFC解剖匹配；用AN全量GWAS运行S-PrediXcan |
| GTEx v8 MASHR eQTL模型 | mashr_Brain_Caudate_basal_ganglia.db + 同名.txt.gz | 14,118个有模型基因；SQLite与协方差文件均存在 | 尾状核的AN遗传表达关联 |
| GTEx v8其他脑组织模型 | Cortex、BA24、海马、下丘脑、杏仁核、小脑、伏隔核、壳核、黑质等 | 共13个Brain命名组织的成对文件；其中脊髓不作为脑区 | 12个实际脑组织作为比较背景，避免只选两个区域后声称脑区特异 |
| GTEx v8组织表达中位TPM | GTEx_v8_brain_median_TPM.csv | 56,200个基因，13个Brain命名组织列 | 表达定位/热图与MAGMA基因表达属性分析的输入；不是GWAS富集结果 |

模型由[PredictDB官方发布](https://predictdb.org/post/2021/07/21/gtex-v8-models-on-eqtl-and-sqtl/)，原始mashr_eqtl.tar来自[Zenodo 3518299](https://zenodo.org/records/3518299)，262,092,800字节，MD5=87f3470bf2676043c748b684fb35fa7d，与官方一致。只提取脑组织模型。每个组织的.db是预测权重，.txt.gz是相应SNP协方差；还不能把它们当作已经计算好的AN TWAS结果。

表达中位数来自[GTEx官方公开文件](https://storage.googleapis.com/adult-gtex/bulk-gex/v8/rna-seq/GTEx_Analysis_2017-06-05_v8_RNASeQCv1.1.9_gene_median_tpm.gct.gz)。原始压缩文件和脑组织提取CSV均已保存。Gene ID保留原始Ensembl版本，后续与差异基因表匹配时需要统一ID。

## 已确认公开可访问，但尚未下载的大文件

| 数据 | 实际文件/可访问性 | 与本研究的关系 |
|---|---|---|
| BrainSeq Phase II DLPFC TWAS权重 | [DLPFC_weights.tar.gz](https://s3.us-east-2.amazonaws.com/libd-brainseq2/DLPFC_weights.tar.gz)，HTTP 200，953,965,905字节 | 明确的背外侧前额叶模型，可作为独立于GTEx来源的验证资源；具体模型训练样本/祖源仍需逐模型核查 |
| BrainSeq Phase III 尾状核祖源分层eQTL | [BrainSeq_eQTL_ancestry_caudate.tar.gz](https://caudate-eqtl.s3.us-west-2.amazonaws.com/BrainSeq_eQTL_ancestry_caudate.tar.gz)，HTTP 200，约54.24GB | 欧洲祖源部分适配当前AN GWAS，用于尾状核共定位或SMR/HEIDI；不是已生成的AN TWAS |
| BrainSeq Phase III 尾状核mash eQTL | [BrainSeq_caudate_4features_mash_associations.tar.gz](https://caudate-eqtl.s3.us-west-2.amazonaws.com/BrainSeq_caudate_4features_mash_associations.tar.gz)，HTTP 200，约17.47GB | 基因、转录本、外显子和剪接连接点调控证据 |
| BrainSeq脑区交互eQTL | [Brainseq_LIBD_brainregions_allpairs_genes.txt.gz](https://caudate-eqtl.s3.us-west-2.amazonaws.com/Brainseq_LIBD_brainregions_allpairs_genes.txt.gz)，HTTP 200，约2.24GB | 比较尾状核、DLPFC、海马的调控差异，比只取两个脑区的TWAS显著基因更接近脑区特异性问题 |

提供方：[BrainSeq Phase II](https://eqtl.brainseq.org/phase2/)，[尾状核数据浏览器](https://erwinpaquolalab.libd.org/caudate_eqtl/)，[2022研究和数据说明](https://pmc.ncbi.nlm.nih.gov/articles/PMC10599288/)。该尾状核资源含443人、233欧洲祖源和210非洲祖源；包含精神分裂症/双相障碍及对照，不是AN病例数据。可利用其正常遗传表达调控关系整合AN GWAS，但不能把其现成精神分裂症TWAS结果当作AN结果。未自动下载17–54GB文件，下载状态在additional_brain_resources_verified.csv中明确列出。

BrainSeq与GSE262138均可能涉及LIBD供者；后续须核查供者重叠，不能默认它们是完全独立的验证队列。

PsychENCODE/CMC亦有额叶调控/预测资源，但本次其旧下载门户连接不稳定，未把无法核实的旧地址标为已取得模型。首选已完成校验的GTEx模型，BrainSeq作为解剖匹配的补充资源。

## 建议的下一阶段证据链

1. 使用完整PGC AN GWAS，对GTEx可用的12个脑组织统一运行S-PrediXcan，而不是只使用5个MR工具位点。BA9和尾状核是预先指定的重点脑区，其余作为比较背景；跨所有实际检验的基因×脑区组合进行多重校正。
2. 输出基因×脑区TWAS Z、P、FDR、模型SNP数、匹配SNP数和覆盖率；热图保留不显著的重点脑区结果，用标记显示校正显著性，不能只画能支持预设脑区的条目。
3. 模型基于GRCh38，AN统计为GRCh37。先以rsID和等位基因核对；无法rsID匹配的模型变异需要可靠build转换/GTEx变异对齐。细粒度模型常有老GWAS缺失SNP，需按官方最佳实践报告覆盖，必要时使用经过验证的summary imputation或Elastic Net替代，不能按“未匹配=beta为0”直接填补。
4. 重点信号再用同脑区完整cis-eQTL做共定位（例如coloc/多信号方法），并检查LD、多基因模型相关和模型训练/测试重叠。一个TWAS关联可能来自共享调控或LD，不能直接称“AN作用只发生于前额叶”。GTEx MASHR会跨组织借力，模型组织名不等于该基因只在此区调控。
5. DLPFC遗传候选与GSE262138 DLPFC ED差异基因对应；尾状核候选与其尾状核差异基因对应。高脂小鼠前额叶候选与人类DLPFC对应需先做一对一同源基因映射并说明物种/区域边界。当前没有匹配的高脂尾状核干预证据，不能把小鼠前额叶结果直接当作尾状核高脂效应。
6. 这些筛选产生“多来源支持的候选基因”，不是仅凭交集就确认稳健的因果机制。当前MR未检出脂肪到AN的显著效应；AN脑区TWAS可独立探索AN遗传机制，但不能据此绕过MR阴性结果宣称已经证明脂肪通过该脑区保护AN。

还可以用GTEx表达中位数结合MAGMA基因属性分析评估全组织/脑区表达富集；这需要完整AN GWAS、祖源匹配LD及基因注释。直接表达TPM热图只是表达定位，不能替代GWAS富集统计。

## 文件与状态

- brain_localization/models：已下载的GTEx模型与协方差。
- brain_models_inventory.csv：逐组织模型数、文件名、参考版本及分析优先级。
- GTEx_v8_gene_median_tpm.gct.gz、GTEx_v8_brain_median_TPM.csv：表达定位输入。
- GSE262138_sample_metadata.csv：实际338样本的脑区、ED/OCD/control标签；没有伪造AN亚型。
- additional_brain_resources_verified.csv：BrainSeq大文件的URL、大小及HTTP核查状态。
- GSE262138_author_TWAS_workflow.md：作者已公开的TWAS流程；它不是已下载的逐基因权重，也不代表此处已复算TWAS。
'''
(p/'03_Brain_Region_Resources.md').write_text(brain,encoding='utf8')
print('Written analysis report, English manuscript text and brain-region resource report')
