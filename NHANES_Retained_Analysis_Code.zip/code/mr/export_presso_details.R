args<-commandArgs(trailingOnly=TRUE);root<-if(length(args))args[1] else './project/Workspaces/dietary_fat_AN_MR'
dat<-read.csv(file.path(root,'analysis/harmonized.csv'));raw<-readRDS(file.path(root,'analysis/MR_PRESSO_raw.rds'));outlier<-list();corrected<-list()
for(tag in names(raw)){
 k<-strsplit(tag,'__',fixed=TRUE)[[1]];a<-raw[[tag]];d<-subset(dat,exposure==k[1]&selection==k[2]&outcome==k[3]);o<-a[['MR-PRESSO results']][['Outlier Test']]
 if(!is.null(o)){
  pv<-suppressWarnings(as.numeric(sub('^<','',as.character(o$Pvalue))))
  outlier[[length(outlier)+1]]<-data.frame(exposure=k[1],selection=k[2],outcome=k[3],SNP=d$SNP,RSS=o$RSSobs,P_Bonferroni_as_reported=as.character(o$Pvalue),outlier=pv<=.05)
  idx<-a[['MR-PRESSO results']][['Distortion Test']][['Outliers Indices']]
  if(is.numeric(idx)&&length(idx)){
   rr<-a[['Main MR results']][2,];b<-rr[['Causal Estimate']];s<-rr[['Sd']];df<-nrow(d)-length(idx)-1;crit<-qt(.975,df)
   corrected[[length(corrected)+1]]<-data.frame(exposure=k[1],selection=k[2],outcome=k[3],outlier_SNPs=paste(d$SNP[idx],collapse=';'),nsnp=nrow(d)-length(idx),beta_per_pp=b,se_per_pp=s,OR_per_5pp=exp(5*b),CI_low=exp(5*(b-crit*s)),CI_high=exp(5*(b+crit*s)),P=rr[['P-value']],P_distortion=as.character(a[['MR-PRESSO results']][['Distortion Test']][['Pvalue']]),CI_reference='Student t, df = retained SNPs minus 1')
  }
 }
}
if(length(outlier))write.csv(do.call(rbind,outlier),file.path(root,'analysis/MR_PRESSO_outliers.csv'),row.names=FALSE)
if(length(corrected))write.csv(do.call(rbind,corrected),file.path(root,'analysis/MR_PRESSO_corrected.csv'),row.names=FALSE)
