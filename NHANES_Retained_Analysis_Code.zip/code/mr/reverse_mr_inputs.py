from pathlib import Path
import pandas as pd,subprocess,sys,json,concurrent.futures
from scipy.stats import norm
sys.stdout.reconfigure(encoding='utf8');sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime/python-deps'))
import requests
p=Path(__file__).resolve().parents[1];a=pd.read_csv(p/'analysis/PGC_AN2019_genomewide_significant.csv');f=p/'analysis/reverse_AN_clump_input.tsv';a.rename(columns={'ID':'SNP','PVAL':'P'})[['SNP','P']].to_csv(f,sep='\t',index=False)
cmd=[str(p/'runtime/plink/plink.exe'),'--bfile',str(p/'runtime/ld/EUR'),'--clump',str(f),'--clump-p1','5e-8','--clump-p2','5e-8','--clump-r2','0.001','--clump-kb','10000','--memory','2048','--threads','2','--out',str(p/'analysis/clump_reverse_AN')]
r=subprocess.run(cmd,capture_output=True,text=True);print('clump',r.returncode,flush=True)
if r.returncode:raise RuntimeError(r.stdout+r.stderr)
c=pd.read_csv(p/'analysis/clump_reverse_AN.clumped',sep=r'\s+');d=a[a.ID.isin(c.SNP)].copy();d.to_csv(p/'analysis/reverse_AN_instruments.csv',index=False);print(d[['ID','REF','ALT','BETA','SE','PVAL']].to_string(index=False),flush=True)
def get(row):
 vid=f'{row.CHROM}:{row.POS}:{row.REF}:{row.ALT}';f=p/'raw'/('reverse_variant_'+vid.replace(':','_')+'.json')
 if not f.exists():
  z=requests.get('https://bioindex.hugeamp.org/api/bio/query/variant-dataset-associations',params={'q':vid,'limit':10000},timeout=90);z.raise_for_status();f.write_text(z.text,encoding='utf8')
 hits=[r for r in json.loads(f.read_text())['data'] if r['dataset']=='Merino2022_DietaryIntake_EU' and r['phenotype']=='FatIntake']
 if not hits:return {'SNP':row.ID,'status':'fat_association_missing'}
 if {row.REF,row.ALT} in [{'A','T'},{'C','G'}]:return {'SNP':row.ID,'status':'palindromic_AN_EAF_missing'}
 r=hits[0];pval=r['pValue'];beta=r['beta']
 if pval<=1e-250 or beta==0:return {'SNP':row.ID,'status':'SE_reconstruction_unreliable'}
 return {'SNP':row.ID,'status':'retained','varId':vid,'effect_allele':row.ALT,'other_allele':row.REF,'beta_exposure':row.BETA,'se_exposure':row.SE,'p_exposure':row.PVAL,'beta_outcome':beta,'se_outcome':abs(beta)/norm.isf(pval/2),'p_outcome':pval,'fat_SE_method':'reconstructed from portal beta and P','fat_outcome_unit':'portal-scaled FatIntake GWAS unit','F':(row.BETA/row.SE)**2}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(get,[r for _,r in d.iterrows()]))
pd.DataFrame(rows).to_csv(p/'analysis/reverse_AN_fat_harmonized.csv',index=False);print(pd.DataFrame(rows).to_string(index=False),flush=True)
