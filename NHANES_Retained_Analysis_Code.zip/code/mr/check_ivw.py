from pathlib import Path
import pandas as pd,numpy as np
from scipy.stats import norm,chi2
p=Path(__file__).resolve().parents[1];d=pd.read_csv(p/'analysis/harmonized.csv');rows=[]
for k,g in d.groupby(['exposure','selection','outcome']):
 x=g.beta_exposure.to_numpy();y=g.beta_outcome.to_numpy();w=1/g.se_outcome.to_numpy()**2;b=sum(w*x*y)/sum(w*x*x);q=sum(w*(y-b*x)**2);se=(max(1,q/(len(x)-1))/sum(w*x*x))**.5
 rows.append(dict(zip(['exposure','selection','outcome'],k))|{'n':len(g),'OR':np.exp(5*b),'low':np.exp(5*(b-1.96*se)),'high':np.exp(5*(b+1.96*se)),'P':2*norm.sf(abs(b/se)),'Q_P':chi2.sf(q,len(g)-1)})
pd.DataFrame(rows).to_csv(p/'analysis/IVW_independent_python_check.csv',index=False)
