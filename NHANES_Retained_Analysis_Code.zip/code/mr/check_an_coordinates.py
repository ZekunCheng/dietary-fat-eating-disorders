from pathlib import Path
import pandas as pd
p=Path(__file__).resolve().parents[1];fat=pd.concat([pd.read_csv(p/'raw/Merino_FatIntake_unadjusted_portal.csv'),pd.read_csv(p/'raw/Merino_FatIntake_BMIadjusted_portal.csv')]).drop_duplicates('varId');pos=set(fat.position.astype(int));rows=[]
for c in pd.read_csv(p/'raw/pgcAN2.2019-07.vcf.tsv.gz',sep='\t',comment='#',chunksize=400000,dtype={'CHROM':str,'ID':str,'REF':str,'ALT':str}):
 rows.append(c[c.POS.isin(pos)])
d=pd.concat(rows,ignore_index=True);d.to_csv(p/'analysis/PGC_AN2019_coordinate_candidates.csv',index=False)
print(d[(d.CHROM=='4')&(d.POS==100239319)].to_string(index=False))
