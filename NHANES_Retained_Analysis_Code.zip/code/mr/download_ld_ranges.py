import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'runtime'/'python-deps'))
import requests,concurrent.futures,time,hashlib
URL='http://fileserve.mrcieu.ac.uk/ld/1kg.v3.tgz'
TOTAL=1567805147
PART=100000000
D=ROOT/'raw'/'LD_chunks';D.mkdir(exist_ok=True)
def getchunk(i):
 lo=i*PART;hi=min(TOTAL-1,lo+PART-1);p=D/f'{i:03d}.part'
 for attempt in range(8):
  done=p.stat().st_size if p.exists() else 0
  if done==hi-lo+1:return i,done
  try:
   with requests.get(URL,headers={'Range':f'bytes={lo+done}-{hi}'},stream=True,timeout=(30,45)) as r:
    if r.status_code!=206:raise RuntimeError(f'Range not honored: {r.status_code}')
    with p.open('ab') as f:
     for block in r.iter_content(1048576):f.write(block)
  except Exception as e:print('LD chunk',i,'retry',attempt,type(e).__name__,flush=True)
 raise RuntimeError(f'Chunk {i} incomplete')
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=6) as e:
  for i,n in e.map(getchunk,range((TOTAL+PART-1)//PART)):print('LD chunk complete',i,n,flush=True)
 p=ROOT/'raw'/'1kg.v3.tgz'
 with p.open('wb') as f:
  for i in range((TOTAL+PART-1)//PART):
   with (D/f'{i:03d}.part').open('rb') as g:
    while b:=g.read(1048576):f.write(b)
 assert p.stat().st_size==TOTAL
 print('LD complete',p.stat().st_size,flush=True)
