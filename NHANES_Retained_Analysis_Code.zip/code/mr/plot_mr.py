from pathlib import Path
import pandas as pd,numpy as np,matplotlib as mpl,matplotlib.pyplot as plt,json
p=Path(__file__).resolve().parents[1]
d=pd.read_csv(p/'analysis/MR_results.csv');m=pd.read_csv(p/'analysis/MVMR_results.csv')
mpl.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':7,'axes.labelsize':7,'xtick.labelsize':7,'ytick.labelsize':7,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7})
fig,axs=plt.subplots(1,2,figsize=(7.2,3.9),gridspec_kw={'width_ratios':[1,1.25]});fig.subplots_adjust(left=.19,right=.98,bottom=.17,top=.92,wspace=.82)
a=d.query('exposure=="unadjusted" and selection=="strict" and method=="IVW"').copy();order=['PGC_AN2019','FinnGen_AN_R10','FinnGen_ED_R7','FinnGen_BN_R10'];a=a.set_index('outcome').loc[order].reset_index();labels=['AN: PGC 2019','AN: FinnGen R10','ED: FinnGen R7','BN: FinnGen R10']
b=[]
for label,exp,sel,method in [('Primary IVW','unadjusted','strict','IVW'),('Weighted median','unadjusted','strict','Weighted_median'),('Weighted mode','unadjusted','strict','Weighted_mode'),('MR-Egger','unadjusted','strict','MR_Egger'),('Relaxed threshold IVW','unadjusted','relaxed','IVW'),('BMI-adjusted GWAS IVW','BMIadjusted','strict','IVW')]:
 r=d[(d.outcome=='PGC_AN2019')&(d.exposure==exp)&(d.selection==sel)&(d.method==method)].iloc[0].to_dict();r['display_label']=label;b.append(r)
r=m[m.outcome=='PGC_AN2019'].iloc[0].to_dict();r['display_label']='BMI multivariable IVW';b.append(r);b=pd.DataFrame(b)
for ax,frame,labs,panel,lim in [(axs[0],a,labels,'a',(.08,12)),(axs[1],b,b.display_label.tolist(),'b',(.1,200))]:
 assert np.isfinite(frame[['OR_per_5pp','CI_low','CI_high']].to_numpy()).all()
 assert (frame[['OR_per_5pp','CI_low','CI_high']].to_numpy()>0).all()
 y=np.arange(len(frame))[::-1]
 ax.axvline(1,color='.65',lw=.8,ls='--',zorder=0)
 colors=['#264E68' if i==0 else '#687A86' for i in range(len(frame))]
 for i,(_,row) in enumerate(frame.iterrows()):
  ax.errorbar(row.OR_per_5pp,y[i],xerr=np.array([[row.OR_per_5pp-row.CI_low],[row.CI_high-row.OR_per_5pp]]),fmt='o',ms=4,color=colors[i],elinewidth=1,capsize=2)
 ax.set_yticks(y,labs);ax.set_ylim(-.65,len(frame)-.35);ax.set_xscale('log');ax.set_xlim(*lim);ax.set_xlabel('Odds ratio per 5 percentage points\nof energy from total fat');ax.tick_params(axis='y',length=0);ax.text(-.48,1.03,panel,transform=ax.transAxes,fontweight='bold',fontsize=9)
axs[0].set_xticks([.1,1,10],['0.1','1','10']);axs[1].set_xticks([.1,1,10,100],['0.1','1','10','100'])
f=p/'figures';f.mkdir(exist_ok=True)
fig.savefig(f/'MR_forest.svg')
fig.savefig(f/'MR_forest.pdf')
fig.savefig(f/'MR_forest.png',dpi=300)
fig.savefig(f/'MR_forest.tiff',dpi=600)
a.assign(display_label=labels).to_csv(f/'MR_forest_panel_a.csv',index=False);b.to_csv(f/'MR_forest_panel_b.csv',index=False)
plt.close(fig)
