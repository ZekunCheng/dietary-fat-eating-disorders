import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'runtime'/'python-deps'))
import requests,concurrent.futures,hashlib,time
JOBS=[('http://fileserve.mrcieu.ac.uk/ld/1kg.v3.tgz','1kg.v3.tgz'),('https://s3.amazonaws.com/plink1-assets/plink_win64_20250819.zip','plink_win64_20250819.zip')]
def download(job):
 url,name=job;p=ROOT/'raw'/name
 if p.exists() and p.stat().st_size>0:return name,'exists',p.stat().st_size
 for attempt in range(4):
  try:
   with requests.get(url,stream=True,timeout=(30,120)) as resp:
    resp.raise_for_status();total=int(resp.headers.get('Content-Length','0'));n=0;last=time.monotonic()
    with p.with_suffix(p.suffix+'.part').open('wb') as f:
     for block in resp.iter_content(1048576):
      f.write(block);n+=len(block)
      if time.monotonic()-last>30: print(name,round(n/1e6,1),'MB/',round(total/1e6,1),flush=True);last=time.monotonic()
    if total and n!=total:raise IOError('Incomplete download')
    p.with_suffix(p.suffix+'.part').replace(p)
    return name,'downloaded',n
  except Exception as e:print(name,'retry',attempt,str(e),flush=True)
 raise RuntimeError(name+' failed')
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for result in pool.map(download,JOBS):print(result,flush=True)
