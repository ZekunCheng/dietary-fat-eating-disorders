args<-commandArgs(trailingOnly=TRUE);root<-if(length(args))args[1] else './project/Workspaces/dietary_fat_AN_MR'
for(f in c('MVMR_format_mvmr.R','MVMR_strength_mvmr.R','MVMR_ivw_mvmr.R','MVMR_pleiotropy_mvmr.R'))source(file.path(root,'scripts/vendor',f))
dat<-read.csv(file.path(root,'analysis/harmonized.csv'));bmi<-read.csv(file.path(root,'analysis/BMI_strict_instruments.csv'));rr<-list();strength<-list();raw<-list()
for(out in unique(dat$outcome)){
 d<-merge(subset(dat,exposure=='unadjusted' & selection=='strict' & outcome==out),bmi,by='SNP')
 d<-d[is.finite(d$se_BMI)&d$se_BMI>0,]
 x<-format_mvmr(BXGs=as.matrix(d[,c('beta_exposure','beta_BMI')]),BYG=d$beta_outcome,seBXGs=as.matrix(d[,c('se_exposure','se_BMI')]),seBYG=d$se_outcome,RSID=d$SNP)
 a<-ivw_mvmr(x);m<-summary(lm(beta_outcome ~ -1+beta_exposure+beta_BMI,weights=1/se_outcome^2,data=d));bb<-a[1,1];ss<-a[1,2]/min(1,m$sigma)
 rr[[length(rr)+1]]<-data.frame(outcome=out,nsnp=nrow(d),beta_per_pp=bb,se_per_pp=ss,OR_per_5pp=exp(5*bb),CI_low=exp(5*(bb-1.96*ss)),CI_high=exp(5*(bb+1.96*ss)),P=2*pnorm(-abs(bb/ss)),covariance_note='unknown cross-exposure covariance; rho sensitivity -0.5,0,0.5',BMI_SE_note='SE reconstructed from reported beta and P except FTO reported SE')
 for(rho in c(-.5,0,.5)){
  covs<-lapply(seq_len(nrow(d)),function(j)matrix(c(d$se_exposure[j]^2,rho*d$se_exposure[j]*d$se_BMI[j],rho*d$se_exposure[j]*d$se_BMI[j],d$se_BMI[j]^2),2,2))
  z<-strength_mvmr(x,gencov=covs);raw[[paste(out,rho)]]<-z
  strength[[length(strength)+1]]<-data.frame(outcome=out,nsnp=nrow(d),rho=rho,F_conditional_fat=as.numeric(z[1,1]),F_conditional_BMI=as.numeric(z[1,2]))
 }
}
write.csv(do.call(rbind,rr),file.path(root,'analysis/MVMR_results.csv'),row.names=FALSE);write.csv(do.call(rbind,strength),file.path(root,'analysis/MVMR_conditional_F.csv'),row.names=FALSE);saveRDS(raw,file.path(root,'analysis/MVMR_strength_raw.rds'))
