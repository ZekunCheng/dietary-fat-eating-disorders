from pathlib import Path
import pandas as pd,gzip,concurrent.futures
p=Path(__file__).resolve().parents[1]
fat=pd.concat([pd.read_csv(p/'raw/Merino_FatIntake_unadjusted_portal.csv'),pd.read_csv(p/'raw/Merino_FatIntake_BMIadjusted_portal.csv')])
ids=set(fat.dbSNP.dropna());print('Candidate rsIDs',len(ids),flush=True)
def extract(pair):
 label,name=pair; out=p/'analysis'/f'{label}_all_fat_candidates.csv'
 if out.exists(): return (label,'cached')
 rows=[];n=0
 for c in pd.read_csv(p/'raw'/name,sep='\t',compression='gzip',usecols=['#chrom','pos','ref','alt','rsids','pval','beta','sebeta','af_alt'],chunksize=300000,dtype={'#chrom':str,'rsids':str,'ref':str,'alt':str}):
  n+=len(c)
  m=c[c.rsids.isin(ids)].copy()
  multi=c[c.rsids.str.contains(',',na=False)|c.rsids.str.contains(';',na=False)]
  for _,r in multi.iterrows():
   for sid in str(r.rsids).replace(';',',').split(','):
    if sid in ids:
     rr=r.copy();rr.rsids=sid;m=pd.concat([m,rr.to_frame().T],ignore_index=True)
  rows.append(m)
 pd.concat(rows,ignore_index=True).to_csv(out,index=False)
 print(label,n,'variants;',sum(len(r) for r in rows),'matched',flush=True)
 return label
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 list(pool.map(extract,[('FinnGen_ED_R7','finngen_R7_F5_EATING.gz'),('FinnGen_BN_R10','finngen_R10_F5_BULIMIA.gz'),('FinnGen_AN_R10','finngen_R10_F5_ANOREX.gz')]))
# PGC extraction, covering both exposure versions.
out=p/'analysis/PGC_AN2019_all_fat_candidates.csv'
rows=[]
for c in pd.read_csv(p/'raw/pgcAN2.2019-07.vcf.tsv.gz',sep='\t',comment='#',chunksize=300000,dtype={'CHROM':str,'ID':str,'REF':str,'ALT':str}):
 rows.append(c[c.ID.isin(ids)])
pd.concat(rows,ignore_index=True).to_csv(out,index=False)
print('PGC matches',sum(len(r) for r in rows),flush=True)
