from pathlib import Path
import pandas as pd,subprocess
p=Path(__file__).resolve().parents[1];a=pd.concat([pd.read_csv(p/'raw/Merino_FatIntake_unadjusted_portal.csv').dbSNP,pd.read_csv(p/'raw/Merino_FatIntake_BMIadjusted_portal.csv').dbSNP,pd.read_csv(p/'analysis/PGC_AN2019_genomewide_significant.csv').ID]).dropna().drop_duplicates();f=p/'analysis/LD_candidate_ids.txt';f.write_text('\n'.join(a)+'\n',encoding='ascii')
cmd=[str(p/'runtime/plink/plink.exe'),'--bfile',str(p/'runtime/ld/EUR'),'--extract',str(f),'--make-bed','--keep-allele-order','--memory','2048','--threads','2','--out',str(p/'runtime/ld/EUR_candidates')]
r=subprocess.run(cmd,capture_output=True,text=True);print(r.returncode,r.stdout[-900:]);
if r.returncode:raise RuntimeError(r.stderr)
