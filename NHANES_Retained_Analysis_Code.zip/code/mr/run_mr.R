args <- commandArgs(trailingOnly=TRUE)
root <- if(length(args)) args[1] else './project/Workspaces/dietary_fat_AN_MR'
for(f in c('TwoSampleMR_mr.R','TwoSampleMR_mr_mode.R','mr_presso_cached.R')) source(file.path(root,'scripts/vendor',f))
dat <- read.csv(file.path(root,'analysis/harmonized.csv'))
par <- default_parameters();par$nboot <- 2000
keys <- unique(dat[,c('exposure','selection','outcome')]);res<-list();diag<-list();loo<-list();single<-list();press<-list();raw<-list()
methods <- list(IVW=mr_ivw,MR_Egger=mr_egger_regression,Weighted_median=mr_weighted_median,Weighted_mode=mr_weighted_mode)
for(i in seq_len(nrow(keys))){
 k<-keys[i,];d<-subset(dat,exposure==k$exposure & selection==k$selection & outcome==k$outcome);tag<-paste(unlist(k),collapse='__');cat('RUN',tag,nrow(d),'SNPs\n');flush.console()
 for(m in names(methods)){
  set.seed(20261011+i*100+match(m,names(methods)))
  a<-methods[[m]](d$beta_exposure,d$beta_outcome,d$se_exposure,d$se_outcome,par)
  crit<-if(m %in% c('MR_Egger','Weighted_mode')) qt(.975,nrow(d)-if(m=='MR_Egger')2 else 1) else qnorm(.975)
  res[[length(res)+1]]<-cbind(k,data.frame(method=m,nsnp=nrow(d),beta_per_pp=a$b,se_per_pp=a$se,OR_per_5pp=exp(5*a$b),CI_low=exp(5*(a$b-crit*a$se)),CI_high=exp(5*(a$b+crit*a$se)),P=a$pval))
  if(m=='IVW')ivw<-a
  if(m=='MR_Egger')egger<-a
 }
 # I2GX calculated after orienting all SNPs toward increased exposure, with inverse-SE weighting.
 xb<-abs(d$beta_exposure);ww<-1/d$se_exposure^2;qx<-sum(ww*(xb-weighted.mean(xb,ww))^2)
 diag[[length(diag)+1]]<-cbind(k,data.frame(nsnp=nrow(d),F_min=min(d$F),F_median=median(d$F),F_max=max(d$F),Q_IVW=ivw$Q,Q_df=ivw$Q_df,Q_P=ivw$Q_pval,Q_Egger=egger$Q,Q_Egger_P=egger$Q_pval,Egger_intercept=egger$b_i,Egger_intercept_SE=egger$se_i,Egger_intercept_P=egger$pval_i,I2_GX=max(0,(qx-(nrow(d)-1))/qx)))
 for(j in seq_len(nrow(d))){
  a<-mr_ivw(d$beta_exposure[-j],d$beta_outcome[-j],d$se_exposure[-j],d$se_outcome[-j],par)
  loo[[length(loo)+1]]<-cbind(k,data.frame(removed_SNP=d$SNP[j],nsnp=nrow(d)-1,beta_per_pp=a$b,se_per_pp=a$se,OR_per_5pp=exp(5*a$b),CI_low=exp(5*(a$b-1.96*a$se)),CI_high=exp(5*(a$b+1.96*a$se)),P=a$pval))
  b<-d$beta_outcome[j]/d$beta_exposure[j];s<-d$se_outcome[j]/abs(d$beta_exposure[j])
  single[[length(single)+1]]<-cbind(k,data.frame(SNP=d$SNP[j],beta_per_pp=b,se_per_pp=s,OR_per_5pp=exp(5*b),CI_low=exp(5*(b-1.96*s)),CI_high=exp(5*(b+1.96*s)),P=2*pnorm(-abs(b/s))))
 }
 if(k$exposure=='unadjusted' && nrow(d)>3){
  cat('PRESSO',tag,'10000 simulations\n');flush.console()
  a<-tryCatch(mr_presso(BetaOutcome='beta_outcome',BetaExposure='beta_exposure',SdOutcome='se_outcome',SdExposure='se_exposure',data=d,OUTLIERtest=TRUE,DISTORTIONtest=TRUE,NbDistribution=10000,seed=20261011+i),error=function(e)list(error=conditionMessage(e)))
  raw[[tag]]<-a;saveRDS(raw,file.path(root,'analysis/MR_PRESSO_raw.rds'))
  capture.output(print(a),file=file.path(root,'analysis',paste0('PRESSO_',tag,'.txt')))
  if(is.null(a$error)){
   g<-a[['MR-PRESSO results']][['Global Test']];ot<-a[['MR-PRESSO results']][['Outlier Test']]
   press[[length(press)+1]]<-cbind(k,data.frame(global_RSS=g$RSSobs,global_P=as.character(g$Pvalue),simulations=10000,outlier_SNPs=if(!is.null(ot))paste(d$SNP[which(suppressWarnings(as.numeric(sub('^<','',as.character(ot$Pvalue))))<=.05)],collapse=';') else ''))
  }else press[[length(press)+1]]<-cbind(k,data.frame(global_RSS=NA,global_P=a$error,simulations=10000,outlier_SNPs=''))
 }
 write.csv(do.call(rbind,res),file.path(root,'analysis/MR_results.csv'),row.names=FALSE)
 write.csv(do.call(rbind,diag),file.path(root,'analysis/MR_diagnostics.csv'),row.names=FALSE)
 write.csv(do.call(rbind,loo),file.path(root,'analysis/MR_leave_one_out.csv'),row.names=FALSE)
 write.csv(do.call(rbind,single),file.path(root,'analysis/MR_single_SNP.csv'),row.names=FALSE)
 if(length(press))write.csv(do.call(rbind,press),file.path(root,'analysis/MR_PRESSO_summary.csv'),row.names=FALSE)
}
r<-do.call(rbind,res);r$P_Bonferroni_3<-NA_real_;r$P_Bonferroni_4<-NA_real_
main<-r$exposure=='unadjusted' & r$selection=='strict' & r$method=='IVW'
r$P_Bonferroni_4[main]<-pmin(1,4*r$P[main]);primary<-main & r$outcome!='FinnGen_AN_R10';r$P_Bonferroni_3[primary]<-pmin(1,3*r$P[primary])
write.csv(r,file.path(root,'analysis/MR_results.csv'),row.names=FALSE)
l<-do.call(rbind,loo);grp<-interaction(l$exposure,l$selection,l$outcome,drop=TRUE);l$P_Bonferroni_within_LOO_group<-pmin(1,l$P*ave(l$P,grp,FUN=length));mainloo<-l$exposure=='unadjusted'&l$selection=='strict';l$P_Bonferroni_all_main_LOO<-NA_real_;l$P_Bonferroni_all_main_LOO[mainloo]<-pmin(1,l$P[mainloo]*sum(mainloo));write.csv(l,file.path(root,'analysis/MR_leave_one_out.csv'),row.names=FALSE)
capture.output(sessionInfo(),file=file.path(root,'analysis/R_sessionInfo.txt'))
cat('MR COMPLETE\n')
