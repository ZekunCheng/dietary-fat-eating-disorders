from pathlib import Path
import sys
sys.stdout.reconfigure(encoding='utf8');sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime/python-deps'))
import requests,pandas as pd
p=(Path(__file__).resolve().parents[1]/'brain_localization')
u='https://storage.googleapis.com/adult-gtex/bulk-gex/v8/rna-seq/GTEx_Analysis_2017-06-05_v8_RNASeQCv1.1.9_gene_median_tpm.gct.gz';r=requests.get(u,timeout=60);r.raise_for_status();f=p/'GTEx_v8_gene_median_tpm.gct.gz';f.write_bytes(r.content)
d=pd.read_csv(f,sep='\t',skiprows=2);cols=[c for c in d if c.startswith('Brain')];d[['Name','Description']+cols].to_csv(p/'GTEx_v8_brain_median_TPM.csv',index=False);print(f.stat().st_size,len(d),cols)
