import sys,json,gzip,tarfile,hashlib,concurrent.futures,time
from pathlib import Path
sys.stdout.reconfigure(encoding='utf8');sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'runtime/python-deps'))
import requests
p=(Path(__file__).resolve().parents[1]/'brain_localization')
urls={'mashr_eqtl.tar':'https://zenodo.org/records/3518299/files/mashr_eqtl.tar?download=1','GSE262138_family.soft.gz':'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE262nnn/GSE262138/soft/GSE262138_family.soft.gz','PubMed39649579.xml':'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=39649579&retmode=xml','FUSION_github.html':'https://gusevlab.github.io/projects/fusion/'}
def get(kv):
 name,url=kv;f=p/name
 if f.exists() and f.stat().st_size>1000:return name
 try:
  with requests.get(url,timeout=(30,90),stream=True) as r:
   r.raise_for_status()
   with open(str(f)+'.part','wb') as out:
    for c in r.iter_content(1024*1024):out.write(c)
  Path(str(f)+'.part').replace(f);print(name,f.stat().st_size,flush=True)
 except Exception as e: print(name,type(e).__name__,flush=True)
 return name
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(get,urls.items()))
f=p/'mashr_eqtl.tar'
if f.exists():
 md5=hashlib.md5(f.read_bytes()).hexdigest();print('mashr MD5',md5,flush=True)
 if md5!='87f3470bf2676043c748b684fb35fa7d':raise ValueError('Zenodo MD5 mismatch')
 (p/'models').mkdir(exist_ok=True)
 with tarfile.open(f) as t:
  for m in t:
   if 'Brain_' in m.name and m.isfile():
    target=p/'models'/Path(m.name).name
    target.write_bytes(t.extractfile(m).read());print(m.name,m.size,flush=True)
