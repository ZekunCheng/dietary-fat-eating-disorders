from pathlib import Path
import pandas as pd,numpy as np,json,hashlib,zipfile,ast
p=Path(r'./project/Workspaces\dietary_fat_AN_MR');out=Path(r'./project/outputs\dietary_fat_AN_MR_20261011')
# Verify independent rerun from portable LD subset against original project results.
checks={}
for name in ['MR_results.csv','MR_diagnostics.csv','MR_PRESSO_summary.csv','MVMR_results.csv','MVMR_conditional_F.csv','MR_leave_one_out.csv']:
 a=pd.read_csv(p/'analysis'/name);b=pd.read_csv(out/'analysis'/name);assert list(a.columns)==list(b.columns),(name,'columns differ');assert len(a)==len(b),(name,'row counts differ')
 for c in a:
  if pd.api.types.is_numeric_dtype(a[c]):assert np.allclose(a[c].astype(float),b[c].astype(float),rtol=1e-11,atol=1e-12,equal_nan=True),(name,c)
  else:assert a[c].fillna('').astype(str).equals(b[c].fillna('').astype(str)),(name,c)
 checks[name]='PASS; rerun agrees with original project'
checks['offline_pipeline']='Completed all stages from delivered candidate-statistic inputs and 2,036-variant European LD subset'
checks['brain_model_md5']='Full source model archive previously matched official Zenodo MD5'
(out/'analysis/portable_reproduction_QA.json').write_text(json.dumps(checks,indent=2),encoding='utf8')
# Retain an explicit research boundary for reuse of region-matched validation cohorts.
for root in [p,out]:
 f=root/'scripts/build_reports.py';s=f.read_text(encoding='utf8');s=s.replace('PsychENCODE/CMC亦有额叶调控/预测资源，','BrainSeq与GSE262138均可能涉及LIBD供者；后续须核查供者重叠，不能默认它们是完全独立的验证队列。\n\nPsychENCODE/CMC亦有额叶调控/预测资源，');f.write_text(s,encoding='utf8')
 for code in (root/'scripts').glob('*.py'):ast.parse(code.read_text(encoding='utf-8-sig'))
 f=root/'03_Brain_Region_Resources.md';s=f.read_text(encoding='utf8');s=s.replace('PsychENCODE/CMC亦有额叶调控/预测资源，','BrainSeq与GSE262138均可能涉及LIBD供者；后续须核查供者重叠，不能默认它们是完全独立的验证队列。\n\nPsychENCODE/CMC亦有额叶调控/预测资源，');f.write_text(s,encoding='utf8')
# Artifact hashes and compressed package. Do not include full GWAS or the full LD archive.
rows=[]
for f in sorted(out.rglob('*')):
 if not f.is_file() or '__pycache__' in f.parts or f.name=='deliverable_sha256.csv':continue
 h=hashlib.sha256()
 with f.open('rb') as inp:
  for block in iter(lambda:inp.read(2**20),b''):h.update(block)
 rows.append({'relative_path':str(f.relative_to(out)),'bytes':f.stat().st_size,'sha256':h.hexdigest()})
pd.DataFrame(rows).to_csv(out/'deliverable_sha256.csv',index=False)
zip_path=Path(r'./project/outputs\dietary_fat_AN_MR_20261011.zip')
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(out.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts:z.write(f,arcname=str(Path(out.name)/f.relative_to(out)))
with zipfile.ZipFile(zip_path) as z:
 assert z.testzip() is None
 for name in ['01_MR_Analysis_Report.md','02_MR_Manuscript_Text.md','03_Brain_Region_Resources.md','analysis/MR_results.csv','run_analysis.ps1','brain_localization/models/mashr_Brain_Frontal_Cortex_BA9.db','brain_localization/models/mashr_Brain_Caudate_basal_ganglia.db']:assert out.name+'/'+name in z.namelist()
print(json.dumps(checks,indent=2));print('ZIP',zip_path,zip_path.stat().st_size,'bytes');print('Deliverable files',len(rows))
