from pathlib import Path
import sys,json,time,hashlib,concurrent.futures,os
sys.path.append('./project/Workspaces/dietary_fat_AN_MR/runtime/python-deps')
import requests
root=Path('./project/Workspaces/AN_singlecell_spatial_validation_20261015')
for p in ['raw','audit','results','scripts']: (root/p).mkdir(parents=True,exist_ok=True)
url='https://api.cellxgene.cziscience.com/curation/v1/collections/283d65eb-dd53-496d-adb7-7570c7caa443'
r=requests.get(url,timeout=60);r.raise_for_status();j=r.json()
(root/'audit/collection_metadata.json').write_text(json.dumps(j,indent=2),encoding='utf8')
targets={'DLPFC_A46':'db1d2c1b-2ee1-45d5-9d53-69a327cd77e6','Caudate_body':'529bb209-9d7b-44da-bfa4-f6e4745c46c2'}
def fetch(item):
 region,ident=item;ds=next(x for x in j['datasets'] if x['dataset_id']==ident)
 asset=next(x for x in ds['assets'] if x['filetype']=='H5AD')
 print(region,json.dumps(asset),flush=True)
 dest=root/'raw'/f'Siletti_{region}.h5ad';size=int(asset['filesize'])
 if not dest.exists() or dest.stat().st_size!=size:
  u=asset['url'];tmp=dest.with_suffix('.part')
  for attempt in range(4):
   try:
    with requests.get(u,stream=True,timeout=(30,120)) as rr:
     rr.raise_for_status();done=0;tick=time.time()
     with tmp.open('wb') as f:
      for chunk in rr.iter_content(2**20):
       f.write(chunk);done+=len(chunk)
       if time.time()-tick>20:print(region,round(done/2**20,1),'MiB',flush=True);tick=time.time()
    assert tmp.stat().st_size==size,(tmp.stat().st_size,size)
    tmp.replace(dest);break
   except Exception as e:
    print(region,'retry',attempt,str(e),flush=True)
    if attempt==3:raise
    time.sleep(3)
 h=hashlib.sha256()
 with dest.open('rb') as f:
  for b in iter(lambda:f.read(2**22),b''):h.update(b)
 record=dict(region=region,dataset=ds,download_bytes=size,sha256=h.hexdigest(),source_collection=url)
 (root/'audit'/f'{region}_download.json').write_text(json.dumps(record,indent=2),encoding='utf8')
 print('Downloaded',region,size,flush=True)
with concurrent.futures.ThreadPoolExecutor(2) as pool:list(pool.map(fetch,targets.items()))
print('Both reference datasets downloaded',flush=True)
