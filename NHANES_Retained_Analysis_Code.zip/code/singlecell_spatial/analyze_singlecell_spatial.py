from pathlib import Path
import os,json,gc,hashlib,itertools,time
os.environ['OMP_NUM_THREADS']='2';os.environ['OPENBLAS_NUM_THREADS']='2'
import h5py,numpy as np,pandas as pd,scipy.sparse as sp
from scipy.stats import spearmanr
root=Path('./project/Workspaces/AN_singlecell_spatial_validation_20261015');out=root/'results'
classes=['Astrocytes','Microglia','Neurons','Oligodendrocytes','OPCs']
regions={'DLPFC':'Siletti_DLPFC_A46.h5ad','Caudate':'Siletti_Caudate_body.h5ad'}
union=pd.read_csv('./project/outputs/AN_TWAS_HFD_union_20261013/Union_candidates_all_evidence.csv')
cand=union[union.HFD_testable].drop_duplicates('gene_id')[['gene_id','gene_name']]
excluded=set(union.gene_name.dropna())|set(union.human_gene_name.dropna())
def readv(g):
 if isinstance(g,h5py.Group):
  cat=g['categories'];cats=cat.asstr()[:] if cat.dtype.kind in 'OSU' else cat[:]
  return np.asarray(pd.Categorical.from_codes(g['codes'][:],cats).astype(str))
 return g.asstr()[:] if g.dtype.kind in 'OSU' else g[:]
def sparse_chunk(g,start,end):
 ip=g['indptr'][start:end+1];lo=int(ip[0]);hi=int(ip[-1])
 return sp.csr_matrix((g['data'][lo:hi],g['indices'][lo:hi],ip-lo),shape=(end-start,int(g.attrs['shape'][1])))
def read_sparse(g):return sparse_chunk(g,0,int(g.attrs['shape'][0]))
def obs_index(f):return readv(f['obs'][f['obs'].attrs['_index']])
def var_index(f):return readv(f['var'][f['var'].attrs['_index']])
def assign_class(cell,supercluster):
 if supercluster in ['Splatter','Miscellaneous']:return 'Excluded_ambiguous'
 if cell=='astrocyte':return 'Astrocytes'
 if cell=='microglial cell':return 'Microglia'
 if cell=='oligodendrocyte':return 'Oligodendrocytes'
 if cell in ['oligodendrocyte precursor cell','committed oligodendrocyte precursor']:return 'OPCs'
 if 'neuron' in cell.lower():return 'Neurons'
 return 'Excluded_other_or_sparse'
def select_markers(profile,detect,allowed,n=50):
 genes=profile.index.to_numpy();v=profile.to_numpy();det=detect.reindex(genes).to_numpy()
 good=np.array([g in allowed and g not in excluded and not g.startswith(('MT-','RPL','RPS')) for g in genes])
 records=[]
 for k,ct in enumerate(classes):
  spec=np.log2((v[:,k]+1)/(np.max(np.delete(v,k,axis=1),axis=1)+1))
  valid=good&(det[:,k]>=.2)&(v[:,k]>=5)&(spec>=.5)
  ix=np.flatnonzero(valid);ix=ix[np.lexsort((genes[ix],-spec[ix]))][:n]
  if len(ix)<min(n,30):raise ValueError((ct,'insufficient markers',len(ix)))
  for i in ix:records.append(dict(gene=genes[i],cell_type=ct,specificity_log2=spec[i],detection=det[i,k],mean_CPM=v[i,k]))
 return pd.DataFrame(records)
def fit_nnls(A,Y):
 # Exact nonnegative least squares by enumeration of all active sets (five columns).
 G=A.T@A;b=A.T@Y;k=A.shape[1];best=np.zeros(Y.shape[1]);coef=np.zeros((k,Y.shape[1]))
 for n in range(1,k+1):
  for subset in itertools.combinations(range(k),n):
   ix=np.array(subset);sol=np.linalg.solve(G[np.ix_(ix,ix)],b[ix])
   valid=(sol>=-1e-10).all(axis=0);gain=np.sum(sol*b[ix],axis=0)
   win=valid&(gain>best+1e-10)
   if win.any():
    coef[:,win]=0;coef[np.ix_(ix,np.flatnonzero(win))]=np.maximum(sol[:,win],0);best[win]=gain[win]
 total=coef.sum(axis=0);rel=np.divide(coef,total,out=np.zeros_like(coef),where=total>0)
 ss=np.sum(Y*Y,axis=0);relative_error=np.sqrt(np.maximum(ss-best,0)/np.maximum(ss,1e-20))
 return rel.T,relative_error
all_counts=[];all_dots=[];all_donor_dots=[];all_cellmeta=[];cvrecords=[];bulk_records=[];references={};marker_records=[]
for region,filename in regions.items():
 print('Reference aggregation',region,flush=True)
 with h5py.File(root/'raw'/filename,'r') as f:
  meta=pd.DataFrame({k:readv(f['obs'][k]) for k in ['donor_id','cell_type','supercluster_term','disease','sex','tissue']})
  meta['cell_id']=obs_index(f);meta['brain_region']=region
  meta['broad_type']=[assign_class(c,s) for c,s in zip(meta.cell_type,meta.supercluster_term)]
  meta['UMAP_1']=f['obsm/X_UMAP'][:,0];meta['UMAP_2']=f['obsm/X_UMAP'][:,1]
  assert set(meta.disease)=={'normal'}
  genes=readv(f['var/feature_name']);gids=var_index(f)
  unique_symbol=~pd.Index(genes).duplicated(keep=False)
  donors=sorted(meta.donor_id.unique());groups=[(d,c) for d in donors for c in classes]
  groupid=np.array([groups.index((d,c)) if c in classes else -1 for d,c in zip(meta.donor_id,meta.broad_type)])
  sums=np.zeros((len(groups),len(genes)));detected=np.zeros_like(sums);ns=np.zeros(len(groups),dtype=int)
  for start in range(0,len(meta),1024):
   end=min(start+1024,len(meta));X=sparse_chunk(f['X'],start,end)
   assert np.all(X.data>=0) and np.all(X.data==np.rint(X.data))
   lib=np.asarray(X.sum(axis=1)).ravel();ok=(lib>0)&(groupid[start:end]>=0)
   ci=np.flatnonzero(ok);gi=groupid[start:end][ci]
   H=sp.csr_matrix((np.ones(len(ci)),(gi,ci)),shape=(len(groups),end-start))
   norm=sp.diags(np.divide(1e6,lib,out=np.zeros_like(lib,dtype=float),where=lib>0))@X
   sums+=(H@norm).toarray();detected+=(H@(X>0)).toarray();ns+=np.bincount(gi,minlength=len(groups))
  assert (ns>=20).all(),list(zip(groups,ns))
  donor_mean=sums/ns[:,None];donor_det=detected/ns[:,None]
  prof=pd.DataFrame(donor_mean.reshape(len(donors),len(classes),-1).mean(axis=0).T,index=genes,columns=classes)
  detect=pd.DataFrame(donor_det.reshape(len(donors),len(classes),-1).mean(axis=0).T,index=genes,columns=classes)
  prof=prof.iloc[np.flatnonzero(unique_symbol)];detect=detect.iloc[np.flatnonzero(unique_symbol)]
  prof.to_csv(out/f'Reference_{region}_donor_balanced_mean_CPM.csv.gz',index_label='gene')
  detect.to_csv(out/f'Reference_{region}_donor_balanced_detection_fraction.csv.gz',index_label='gene')
  ref_counts=meta.groupby(['brain_region','donor_id','broad_type'],observed=True).size().reset_index(name='n_nuclei');all_counts.append(ref_counts)
  for row in cand.itertuples():
   idx=np.flatnonzero(gids==row.gene_id)
   for k,ct in enumerate(classes):
    i=int(idx[0]) if len(idx) else None
    vals=donor_mean[k::len(classes),i] if i is not None else np.array([])
    all_dots.append(dict(brain_region=region,gene_id=row.gene_id,gene_name=row.gene_name,cell_type=ct,
      present_in_reference=bool(len(idx)),mean_CPM=float(vals.mean()) if len(vals) else np.nan,
      detection_fraction=float(donor_det[k::len(classes),i].mean()) if i is not None else np.nan,n_reference_donors=len(donors)))
    for di,donor in enumerate(donors):
     all_donor_dots.append(dict(brain_region=region,donor_id=donor,gene_id=row.gene_id,gene_name=row.gene_name,cell_type=ct,
       n_nuclei=int(ns[di*len(classes)+k]),mean_CPM=float(donor_mean[di*len(classes)+k,i]) if i is not None else np.nan,
       detection_fraction=float(donor_det[di*len(classes)+k,i]) if i is not None else np.nan))
  all_cellmeta.append(meta)
 # Select reference-only markers shared with the corresponding bulk and spatial data.
 bulk=pd.read_csv(root/'inputs'/f'Bulk_{region}_linear_CPM.csv.gz',index_col=0)
 spatial_path=Path('./project/Workspaces/AN_gsMap/inputs/spatial/Br2743_mid/Br2743_mid.h5ad') if region=='DLPFC' else Path('./project/Workspaces/Caudate_gsMap_20261014/inputs/BG14_64um.h5ad')
 with h5py.File(spatial_path) as f:spgenes=var_index(f)
 allowed=set(bulk.index)&set(spgenes)
 refs={}
 for nmarker in [50,100]:
  mk=select_markers(prof,detect,allowed,nmarker);mk['brain_region']=region;mk['model']=f'{nmarker}_markers_per_type';marker_records.append(mk)
  selected=list(dict.fromkeys(mk.gene));S=prof.loc[selected].to_numpy()
  weight=1/np.sqrt(np.mean(S,axis=1)+1)
  A=S*weight[:,None];Y=bulk.loc[selected].to_numpy()*weight[:,None]
  weights,err=fit_nnls(A,Y)
  for j,sample in enumerate(bulk.columns):
   bulk_records.append(dict(brain_region=region,sample_id=sample,model=f'{nmarker}_markers_per_type',relative_fit_error=err[j],**dict(zip(classes,weights[j]))))
  refs[nmarker]=dict(genes=selected,A=A,weight=weight)
 references[region]=refs
 # Leave-one-reference-donor-out calibration uses marker selection from training donors only.
 rng=np.random.default_rng(20261015)
 for di,donor in enumerate(donors):
  train=[j for j in range(len(donors)) if j!=di]
  tr=donor_mean.reshape(len(donors),len(classes),-1)[train].mean(axis=0).T
  td=donor_det.reshape(len(donors),len(classes),-1)[train].mean(axis=0).T
  mk=select_markers(pd.DataFrame(tr,index=genes,columns=classes),pd.DataFrame(td,index=genes,columns=classes),allowed,50)
  sel=list(dict.fromkeys(mk.gene));ix=pd.Index(genes).get_indexer_for(sel)
  truth=rng.dirichlet(np.ones(len(classes)),size=50)
  held=donor_mean.reshape(len(donors),len(classes),-1)[di,:,ix]
  if held.shape!=(len(ix),len(classes)):held=held.T
  ref=tr[ix];w=1/np.sqrt(ref.mean(axis=1)+1)
  pred,err=fit_nnls(ref*w[:,None],held@truth.T*w[:,None])
  for j in range(50):
   for k,ct in enumerate(classes):cvrecords.append(dict(brain_region=region,heldout_donor=donor,mixture=j,cell_type=ct,true_weight=truth[j,k],estimated_weight=pred[j,k],relative_fit_error=err[j]))
 print('Reference complete',region,'counts',ns.tolist(),flush=True)
pd.concat(all_counts).to_csv(out/'Reference_nuclei_counts_by_donor.csv',index=False)
pd.DataFrame(all_dots).to_csv(out/'Candidate67_single_nucleus_celltype_expression.csv',index=False)
pd.DataFrame(all_donor_dots).to_csv(out/'Candidate67_single_nucleus_donor_expression.csv',index=False)
pd.concat(all_cellmeta).to_csv(out/'Reference_cell_metadata_UMAP.csv.gz',index=False)
pd.concat(marker_records).to_csv(out/'Reference_marker_selection.csv',index=False)
pd.DataFrame(cvrecords).to_csv(out/'Leave_one_donor_out_synthetic_mixtures.csv',index=False)
pd.DataFrame(bulk_records).to_csv(out/'Bulk_reference_NNLS_contributions.csv',index=False)
# Validate the enumerated solver against an independent scipy implementation.
from scipy.optimize import nnls
testref=references['DLPFC'][50];B=pd.read_csv(root/'inputs/Bulk_DLPFC_linear_CPM.csv.gz',index_col=0).loc[testref['genes']].to_numpy()*testref['weight'][:,None]
v,_=fit_nnls(testref['A'],B[:,:10]);ind=[]
for j in range(10):
 co,_=nnls(testref['A'],B[:,j]);ind.append(co/co.sum())
assert np.max(np.abs(v-np.array(ind)))<1e-8
(root/'audit/NNLS_solver_validation.json').write_text(json.dumps({'scipy_nnls_max_absolute_error':float(np.max(np.abs(v-np.array(ind))))},indent=2))
print('Bulk and single-nucleus outputs complete',flush=True)
# Spatial localization in all existing normal sections, using the primary 50-marker reference.
spatial_paths=[('DLPFC',p.parent.name,p) for p in sorted(Path('./project/Workspaces/AN_gsMap/inputs/spatial').glob('*/*.h5ad'))]
spatial_paths.append(('Caudate','BG14',Path('./project/Workspaces/Caudate_gsMap_20261014/inputs/BG14_64um.h5ad')))
spot_tables=[];domain_rows=[];author_rows=[];spatialaudit=[];rank_corr=[]
exprdir=out/'spatial_candidate_expression';exprdir.mkdir(exist_ok=True)
for region,sample,path in spatial_paths:
 with h5py.File(path) as f:
  X=read_sparse(f['X']);sg=var_index(f);idx=pd.Index(sg)
  lib=np.asarray(X.sum(axis=1)).ravel();assert (lib>0).all()
  ref=references[region][50];sel=idx.get_indexer(ref['genes']);assert (sel>=0).all()
  Y=X[:,sel].toarray()/lib[:,None]*1e6
  weights,err=fit_nnls(ref['A'],Y.T*ref['weight'][:,None])
  assigned=weights.sum(axis=1)>0
  weights[~assigned]=np.nan
  coords=f['obsm/spatial'][:];obsid=obs_index(f)
  domain=readv(f['obs/domain']) if region=='DLPFC' else readv(f['obs/spatial_domain'])
  donor=readv(f['obs/subject']) if region=='DLPFC' else np.repeat('BG14',len(lib))
  st=pd.DataFrame(dict(brain_region=region,sample_id=sample,donor_id=donor,spatial_unit=obsid,x=coords[:,0],y=coords[:,1],domain=domain,n_counts=lib,relative_fit_error=err,reference_assigned=assigned))
  for k,ct in enumerate(classes):st[ct]=weights[:,k]
  if region=='DLPFC':
   for ct,code in [('Astrocytes','astro'),('Microglia','micro'),('Oligodendrocytes','oligo'),('OPCs','opc')]:
    a=readv(f[f'obs/broad_cell2location_{code}']).astype(float)
    author_rows.append(dict(sample_id=sample,donor_id=donor[0],cell_type=ct,n_spots=len(lib),n_assigned=int(assigned.sum()),rho=spearmanr(weights[assigned,classes.index(ct)],a[assigned]).statistic))
   neu=readv(f['obs/broad_cell2location_excit']).astype(float)+readv(f['obs/broad_cell2location_inhib']).astype(float)
   author_rows.append(dict(sample_id=sample,donor_id=donor[0],cell_type='Neurons',n_spots=len(lib),n_assigned=int(assigned.sum()),rho=spearmanr(weights[assigned,classes.index('Neurons')],neu[assigned]).statistic))
  loc=idx.get_indexer(cand.gene_name);found=loc>=0
  expression=np.full((len(lib),len(cand)),np.nan)
  expression[:,found]=np.log1p(X[:,loc[found]].toarray()/lib[:,None]*1e4)
  ex=pd.DataFrame(expression,columns=cand.gene_name.to_list());ex.insert(0,'spatial_unit',obsid)
  ex.to_csv(exprdir/f'{sample}_candidate_log1p_CP10K.csv.gz',index=False)
  for gene in ['SNX27','MYO5A','WDR6','CLIC1']:
   if gene in ex:st['expr_'+gene]=ex[gene].to_numpy()
  spot_tables.append(st)
  for dom in sorted(set(domain)):
   dm=domain==dom
   for j,gene in enumerate(cand.gene_name):
    for k,ct in enumerate(classes):
     # One domain row per gene with all contribution means, avoiding redundant gene-cell rows.
     pass
    domain_rows.append(dict(brain_region=region,sample_id=sample,donor_id=donor[0],domain=dom,n_spots=int(dm.sum()),gene_name=gene,
      mean_log1p_CP10K=float(np.mean(expression[dm,j])) if found[j] else np.nan,
      detection_fraction=float(np.mean(expression[dm,j]>0)) if found[j] else np.nan,
      **{ct:float(np.nanmean(weights[dm,k])) for k,ct in enumerate(classes)}))
  spatialaudit.append(dict(brain_region=region,sample_id=sample,n_spots=len(lib),n_assigned=int(assigned.sum()),n_genes=len(sg),candidate_genes_detectable=int(found.sum()),median_relative_fit_error=float(np.median(err))))
 print('Spatial complete',sample,len(lib),flush=True)
pd.concat(spot_tables).to_csv(out/'Spatial_reference_contributions_and_selected_genes.csv.gz',index=False)
pd.DataFrame(domain_rows).to_csv(out/'Spatial_domain_candidate_and_cell_summary.csv',index=False)
pd.DataFrame(author_rows).to_csv(out/'DLPFC_concordance_with_author_cell2location.csv',index=False)
pd.DataFrame(spatialaudit).to_csv(out/'Spatial_localization_QC.csv',index=False)
(root/'audit/reference_scope_amendment.json').write_text(json.dumps({'reason':'metadata inspection showed fewer than20 vascular nuclei per donor; endothelial and other rare classes not used as reference','included_classes':classes,'ambiguous_clusters_excluded':['Splatter','Miscellaneous'],'group_test_family_primary':10,'group_test_family_sensitivity':10,'not_absolute_cell_fractions':True},indent=2))
print('All reference and spatial analyses complete',flush=True)
