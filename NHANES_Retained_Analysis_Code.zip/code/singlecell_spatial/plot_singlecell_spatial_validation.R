.libPaths(unique(c('./project/R/win-library/4.4',.libPaths())))
suppressPackageStartupMessages({library(ggplot2);library(patchwork)})
root<-'./project/Workspaces/AN_singlecell_spatial_validation_20261015';data_dir<-file.path(root,'results')
out<-'./project/outputs/AN_singlecell_spatial_validation_20261015/figures';dir.create(out,recursive=TRUE,showWarnings=FALSE)
cells<-c('Astrocytes','Microglia','Neurons','Oligodendrocytes','OPCs')
palette<-c(Astrocytes='#9E84B5',Microglia='#C58369',Neurons='#5687AA',Oligodendrocytes='#589E96',OPCs='#C6AA5B',Excluded='#CCCCCC')
th<-theme_classic(base_size=8,base_family='Arial')+theme(axis.text=element_text(size=7,colour='#333333'),strip.background=element_blank(),strip.text=element_text(size=8,face='bold'),legend.position='bottom',legend.title=element_text(size=7),legend.text=element_text(size=7),plot.margin=margin(5,5,5,5))
save_fig<-function(p,name,w,h){
 svglite::svglite(file.path(out,paste0(name,'.svg')),width=w/25.4,height=h/25.4);print(p);dev.off()
 grDevices::cairo_pdf(file.path(out,paste0(name,'.pdf')),width=w/25.4,height=h/25.4,family='Arial');print(p);dev.off()
 ggsave(file.path(out,paste0(name,'.png')),p,device=ragg::agg_png,width=w,height=h,units='mm',dpi=300,bg='white')
 ggsave(file.path(out,paste0(name,'.tiff')),p,device=ragg::agg_tiff,width=w,height=h,units='mm',dpi=600,compression='lzw',bg='white')
}
m<-read.csv(file.path(data_dir,'Reference_cell_metadata_UMAP.csv.gz'))
m$brain_region<-factor(m$brain_region,levels=c('DLPFC','Caudate'))
m$display_type<-ifelse(startsWith(m$broad_type,'Excluded'),'Excluded',m$broad_type)
p<-ggplot(m,aes(UMAP_1,UMAP_2,colour=display_type))+geom_point(size=.08,alpha=.6)+facet_wrap(~brain_region,scales='free',nrow=1)+
 scale_colour_manual(values=palette,name=NULL)+guides(colour=guide_legend(override.aes=list(size=2,alpha=1),nrow=2))+
 labs(x='UMAP 1',y='UMAP 2')+th+theme(axis.text=element_blank(),axis.ticks=element_blank())
save_fig(p,'Single_nucleus_reference_UMAP',183,105)
dot<-read.csv(file.path(data_dir,'Candidate67_single_nucleus_celltype_expression.csv'))
dot$brain_region<-factor(dot$brain_region,levels=c('DLPFC','Caudate'))
selected<-c('SNX27','MYO5A','SYNCRIP','RBM5','ETV1','CELSR3','SLC25A12','WDR6','CLIC1','BDNF','SST','VGF')
dot$cell_type<-factor(dot$cell_type,levels=cells)
dot$log_mean<-log1p(dot$mean_CPM)
dot$gene_scaled<-ave(dot$log_mean,paste(dot$brain_region,dot$gene_id),FUN=function(x)if(sd(x)>0)as.numeric(scale(x)) else rep(0,length(x)))
dot$display_percent<-100*dot$detection_fraction
write.csv(dot,file.path(data_dir,'Candidate67_single_nucleus_dotplot_data.csv'),row.names=FALSE)
dotplot<-function(genes){
 x<-dot[dot$gene_name%in%genes,];x$gene_name<-factor(x$gene_name,levels=rev(genes))
 ggplot(x,aes(cell_type,gene_name,size=display_percent,colour=gene_scaled))+geom_point()+facet_grid(.~brain_region)+
 scale_size_continuous(name='Detected nuclei (%)',range=c(0,4),limits=c(0,100),breaks=c(10,50,100))+
 scale_colour_gradient2(low='#5186AA',mid='#F4F4F4',high='#BB7563',midpoint=0,name='Gene-wise expression Z')+
 labs(x=NULL,y=NULL)+th+theme(axis.text.x=element_text(angle=35,hjust=1))
}
save_fig(dotplot(selected),'Candidate_genes_celltype_dotplot',183,125)
save_fig(dotplot(sort(unique(dot$gene_name))),'Candidate67_celltype_dotplot_full',183,265)
old<-read.csv('./project/outputs/AN_functional_regulatory_20261013/Brain_cell_composition_group_comparisons.csv')
old<-old[old$cell_type%in%cells,];old$method<-'BRETIGEA';old$q<-old$FDR_12_brain_cell_tests
nn<-read.csv(file.path(data_dir,'Bulk_NNLS_group_comparisons.csv'));nn<-nn[nn$model=='50_markers_per_type',];nn$method<-'Direct NNLS';nn$q<-nn$FDR_10_region_cell_tests
bi<-read.csv(file.path(data_dir,'Bisque_group_comparisons.csv'));bi<-bi[bi$model=='50_markers_per_type',];bi$method<-'BisqueRNA';bi$q<-bi$FDR_10_region_cell_tests
fields<-c('brain_region','cell_type','method','effect_SD','CI_low','CI_high','P','q')
z<-rbind(old[,fields],nn[,fields],bi[,fields]);z$cell_type<-factor(z$cell_type,levels=rev(cells));z$method<-factor(z$method,levels=c('BRETIGEA','Direct NNLS','BisqueRNA'))
z$brain_region<-factor(z$brain_region,levels=c('DLPFC','Caudate'))
pd<-position_dodge(width=.65)
p<-ggplot(z,aes(effect_SD,cell_type,colour=method,group=method))+geom_vline(xintercept=0,linetype=2,colour='grey65',linewidth=.3)+
 geom_errorbar(aes(xmin=CI_low,xmax=CI_high),position=pd,width=.12,orientation='y',linewidth=.4)+geom_point(position=pd,size=1.8)+facet_wrap(~brain_region,nrow=1)+
 scale_colour_manual(values=c(BRETIGEA='#5687AA','Direct NNLS'='#A8A8A8',BisqueRNA='#C58369'),name=NULL)+labs(x='Adjusted AN - control difference (SD; 95% CI)',y=NULL)+th
save_fig(p,'Bulk_deconvolution_method_comparison',183,110)
write.csv(z,file.path(data_dir,'Bulk_three_method_comparison_plot_data.csv'),row.names=FALSE)
spatial<-read.csv(file.path(data_dir,'Spatial_reference_contributions_and_selected_genes.csv.gz'))
for(sample in c('Br2743_mid','BG14')){
 x<-spatial[spatial$sample_id==sample,]
 features<-c('Microglia','Oligodendrocytes','OPCs','expr_SNX27','expr_MYO5A','expr_CLIC1');plots<-list()
 for(feature in features){
  lab<-sub('expr_','',feature);isgene<-startsWith(feature,'expr_')
  dd<-data.frame(x=x$x,y=x$y,value=x[[feature]])
  # Direct expression maps are measured counts; contribution maps are exploratory projections.
  plots[[feature]]<-ggplot(dd,aes(x,y,colour=value))+geom_point(size=if(sample=='BG14').18 else .38,shape=15)+
   scale_y_reverse()+coord_equal()+scale_colour_gradientn(colours=c('#17204D','#367AA1','#A6D9D3','#F1D275','#C85C44'),
   limits=if(isgene)c(0,max(spatial[[feature]][spatial$sample_id%in%c('Br2743_mid','BG14')],na.rm=TRUE))else c(0,1),
   name=if(isgene)'log1p(CP10K)'else'Relative contribution')+
   labs(title=lab)+theme_void(base_size=8,base_family='Arial')+
   theme(plot.title=element_text(size=8,hjust=.5),legend.position='bottom',legend.title=element_text(size=6.5),legend.text=element_text(size=6.5),
   legend.key.height=grid::unit(2,'mm'),legend.key.width=grid::unit(4,'mm'),plot.margin=margin(4,4,4,4))
 }
 save_fig(wrap_plots(plots,ncol=3),paste0('Spatial_cell_and_gene_localization_',sample),210,160)
}
spcheck<-read.csv(file.path(data_dir,'DLPFC_concordance_with_author_cell2location.csv'))
spcheck$cell_type<-factor(spcheck$cell_type,levels=cells)
p<-ggplot(spcheck,aes(cell_type,rho))+geom_hline(yintercept=0,linetype=2,colour='grey65',linewidth=.3)+geom_boxplot(fill='#B6CCD7',width=.5,outlier.shape=NA,linewidth=.4)+
 geom_point(position=position_jitter(width=.1,height=0,seed=20261015),size=1,alpha=.6,colour='#44718C')+
 labs(x=NULL,y='Correlation with author cell2location estimates')+th+theme(axis.text.x=element_text(angle=25,hjust=1))
save_fig(p,'Spatial_projection_concordance_QC',140,95)
cat('All figures exported:',out,'\n')
