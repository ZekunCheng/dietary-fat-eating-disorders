.libPaths(unique(c('./project/R/win-library/4.4',.libPaths())))
suppressPackageStartupMessages({library(BisqueRNA);library(Biobase);library(Matrix)})
root<-'./project/Workspaces/AN_singlecell_spatial_validation_20261015';out<-file.path(root,'results')
mk<-read.csv(file.path(out,'Reference_marker_selection.csv'))
old<-read.csv('./project/outputs/AN_functional_regulatory_20261013/Brain_cell_surrogate_scores_all_samples.csv')
code<-c(Astrocytes='ast',Microglia='mic',Neurons='neu',Oligodendrocytes='oli',OPCs='opc')
allweights<-list();stats<-list();cc<-list();audit<-list()
for(reg in c('DLPFC','Caudate')) {
 sc<-as.matrix(readMM(file.path(root,'inputs',paste0('Bisque_',reg,'_marker_counts.mtx'))))
 gn<-read.csv(file.path(root,'inputs',paste0('Bisque_',reg,'_genes.csv')))$gene
 sm<-read.csv(file.path(root,'inputs',paste0('Bisque_',reg,'_metadata.csv')))
 rownames(sc)<-gn;colnames(sc)<-sm$cell_id;rownames(sm)<-sm$cell_id
 sce<-ExpressionSet(sc,phenoData=AnnotatedDataFrame(sm))
 b<-as.matrix(read.csv(file.path(root,'inputs',paste0('Bulk_',reg,'_linear_CPM.csv.gz')),row.names=1,check.names=FALSE))
 be<-ExpressionSet(b)
 m<-read.csv(file.path(root,'inputs',paste0('Bulk_',reg,'_metadata.csv')),check.names=FALSE)
 m<-m[match(colnames(b),m$sample_id),];stopifnot(identical(m$sample_id,colnames(b)))
 m$group<-factor(ifelse(m$AN_case==1,'AN','Control'),levels=c('Control','AN'));m$Sex<-factor(m$Sex);m$Race<-factor(m$Race)
 oo<-old[old$brain_region==reg,];oo<-oo[match(m$sample_id,oo$sample_id),]
 for(model in c('50_markers_per_type','100_markers_per_type')) {
  marks<-unique(mk$gene[mk$brain_region==reg & mk$model==model])
  # CountsToCPM must precede marker subsetting; the library-total row preserves the complete original library.
  res<-ReferenceBasedDecomposition(be,sce,markers=marks,cell.types='broad_type',subject.names='donor_id',use.overlap=FALSE,old.cpm=FALSE,verbose=TRUE)
  saveRDS(res,file.path(out,paste0('Bisque_',reg,'_',model,'.rds')))
  x<-t(res$bulk.props);stopifnot(max(abs(rowSums(x)-1))<1e-5,min(x)>-1e-5)
  Y<-res$transformed.bulk;reference<-res$sc.props
  audit[[length(audit)+1]]<-data.frame(brain_region=reg,model=model,n_reference_nuclei=ncol(sc),n_genes_used=length(res$genes.used),
   n_reference_donors=length(unique(sm$donor_id)),mean_residual_norm=mean(res$rnorm),n_negative_transformed_values=sum(Y<0))
  for(ct in colnames(x)) {
   dd<-m;dd$score<-as.numeric(scale(x[,ct]));fit<-lm(score~group+Age+Sex+Race+RIN+Perc.Intronic+Perc.rRNA,data=dd)
   cf<-summary(fit)$coefficients['groupAN',];ci<-confint(fit,'groupAN')
   stats[[length(stats)+1]]<-data.frame(brain_region=reg,model=model,cell_type=ct,effect_SD=cf[1],P=cf[4],CI_low=ci[1],CI_high=ci[2],n_AN=22,n_control=85)
   cc[[length(cc)+1]]<-data.frame(brain_region=reg,model=model,cell_type=ct,rho_with_BRETIGEA=cor(x[,ct],oo[[code[ct]]],method='spearman'))
   allweights[[length(allweights)+1]]<-data.frame(brain_region=reg,model=model,sample_id=rownames(x),donor_id=m$donor_id,group=m$group,cell_type=ct,estimate=x[,ct],estimate_Z=dd$score)
  }
 }
}
ss<-do.call(rbind,stats);ss$FDR_10_region_cell_tests<-ave(ss$P,ss$model,FUN=function(x)p.adjust(x,'BH'))
write.csv(ss,file.path(out,'Bisque_group_comparisons.csv'),row.names=FALSE)
write.csv(do.call(rbind,cc),file.path(out,'Bisque_BRETIGEA_concordance.csv'),row.names=FALSE)
write.csv(do.call(rbind,allweights),file.path(out,'Bisque_cell_estimates_plot_data.csv'),row.names=FALSE)
write.csv(do.call(rbind,audit),file.path(out,'Bisque_algorithm_audit.csv'),row.names=FALSE)
capture.output(sessionInfo(),file=file.path(out,'Bisque_R_sessionInfo.txt'))
print(ss)
