from pathlib import Path
import h5py,numpy as np,pandas as pd,scipy.sparse as sp
from scipy.io import mmwrite
root=Path('./project/Workspaces/AN_singlecell_spatial_validation_20261015')
meta=pd.read_csv(root/'results/Reference_cell_metadata_UMAP.csv.gz')
markers=pd.read_csv(root/'results/Reference_marker_selection.csv')
def rv(g):return np.asarray(pd.Categorical.from_codes(g['codes'][:],g['categories'].asstr()[:]).astype(str)) if isinstance(g,h5py.Group) else g.asstr()[:]
for region,file in [('DLPFC','Siletti_DLPFC_A46.h5ad'),('Caudate','Siletti_Caudate_body.h5ad')]:
 m=meta[(meta.brain_region==region)&~meta.broad_type.str.startswith('Excluded')].copy()
 with h5py.File(root/'raw'/file,'r') as f:
  g=f['X'];genes=rv(f['var/feature_name']);allids=rv(f['obs'][f['obs'].attrs['_index']])
  keep=np.isin(allids,m.cell_id);sel=list(dict.fromkeys(markers[(markers.brain_region==region)&(markers.model=='100_markers_per_type')].gene))
  unique={name:i for i,name in enumerate(genes) if list(genes).count(name)==1} if False else None
  counts=pd.Series(genes).value_counts();ix=np.array([np.flatnonzero(genes==x)[0] for x in sel]);assert all(counts[sel]==1)
  chunks=[]
  for start in range(0,len(allids),1024):
   end=min(start+1024,len(allids));ip=g['indptr'][start:end+1];lo=int(ip[0]);hi=int(ip[-1])
   X=sp.csr_matrix((g['data'][lo:hi],g['indices'][lo:hi],ip-lo),shape=(end-start,len(genes)))
   X=X[keep[start:end]];sub=X[:,ix];remaining=np.asarray(X.sum(axis=1)-sub.sum(axis=1))
   assert (remaining>=0).all();chunks.append(sp.hstack([sub,sp.csr_matrix(remaining)]).tocsr())
  X=sp.vstack(chunks).T.tocoo();mmwrite(root/'inputs'/f'Bisque_{region}_marker_counts.mtx',X)
  pd.Series(sel+['NON_MARKER_LIBRARY_TOTAL']).to_csv(root/'inputs'/f'Bisque_{region}_genes.csv',index=False,header=['gene'])
  m=m.set_index('cell_id').loc[allids[keep]].reset_index();m.to_csv(root/'inputs'/f'Bisque_{region}_metadata.csv',index=False)
 print('Bisque input',region,X.shape,flush=True)
