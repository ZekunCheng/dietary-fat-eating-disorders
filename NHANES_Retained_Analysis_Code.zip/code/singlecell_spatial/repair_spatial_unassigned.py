from pathlib import Path
import pandas as pd,numpy as np,h5py,json
from scipy.stats import spearmanr
root=Path('./project/Workspaces/AN_singlecell_spatial_validation_20261015');r=root/'results'
cells=['Astrocytes','Microglia','Neurons','Oligodendrocytes','OPCs']
d=pd.read_csv(r/'Spatial_reference_contributions_and_selected_genes.csv.gz',low_memory=False)
d['reference_assigned']=d[cells].sum(axis=1)>0;d.loc[~d.reference_assigned,cells]=np.nan
d.to_csv(r/'Spatial_reference_contributions_and_selected_genes.csv.gz',index=False)
means=d.groupby(['sample_id','domain'],dropna=False)[cells].mean().reset_index();means['domain']=means.domain.astype(str)
dom=pd.read_csv(r/'Spatial_domain_candidate_and_cell_summary.csv',dtype={'domain':str})
dom=dom.drop(columns=cells).merge(means,on=['sample_id','domain'],how='left',validate='many_to_one');dom.to_csv(r/'Spatial_domain_candidate_and_cell_summary.csv',index=False)
q=pd.read_csv(r/'Spatial_localization_QC.csv');q['n_assigned']=q.sample_id.map(d.groupby('sample_id').reference_assigned.sum());q.to_csv(r/'Spatial_localization_QC.csv',index=False)
def rv(g):
 if isinstance(g,h5py.Group):return np.asarray(pd.Categorical.from_codes(g['codes'][:],g['categories'].asstr()[:]).astype(str))
 return g[:]
rows=[]
for sample,x in d[d.brain_region=='DLPFC'].groupby('sample_id',sort=False):
 valid=x.reference_assigned.to_numpy()
 with h5py.File(Path('./project/Workspaces/AN_gsMap/inputs/spatial')/sample/(sample+'.h5ad')) as f:
  for ct,code in [('Astrocytes','astro'),('Microglia','micro'),('Neurons','neurons'),('Oligodendrocytes','oligo'),('OPCs','opc')]:
   a=rv(f['obs/broad_cell2location_excit']).astype(float)+rv(f['obs/broad_cell2location_inhib']).astype(float) if code=='neurons' else rv(f[f'obs/broad_cell2location_{code}']).astype(float)
   rows.append(dict(sample_id=sample,donor_id=x.donor_id.iloc[0],cell_type=ct,n_spots=len(x),n_assigned=int(valid.sum()),rho=spearmanr(x.loc[valid,ct],a[valid]).statistic))
pd.DataFrame(rows).to_csv(r/'DLPFC_concordance_with_author_cell2location.csv',index=False)
(root/'audit/spatial_unassigned_audit.json').write_text(json.dumps({'total_spots':len(d),'unassigned_no_selected_marker_signal':int((~d.reference_assigned).sum()),'rule':'retain units and measured candidate expression; cell contribution fields NA, never biological zeros; section-method concordance uses assigned units only'},indent=2))
print('Unassigned sparse units marked NA:',int((~d.reference_assigned).sum()))
