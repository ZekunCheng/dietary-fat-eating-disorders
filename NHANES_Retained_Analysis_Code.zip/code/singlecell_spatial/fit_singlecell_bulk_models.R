.libPaths(unique(c('./project/R/win-library/4.4',.libPaths())))
root <- './project/Workspaces/AN_singlecell_spatial_validation_20261015'
out <- file.path(root,'results')
d <- read.csv(file.path(out,'Bulk_reference_NNLS_contributions.csv'),check.names=FALSE)
old <- read.csv('./project/outputs/AN_functional_regulatory_20261013/Brain_cell_surrogate_scores_all_samples.csv')
cells <- c('Astrocytes','Microglia','Neurons','Oligodendrocytes','OPCs')
code <- c(Astrocytes='ast',Microglia='mic',Neurons='neu',Oligodendrocytes='oli',OPCs='opc')
models <- unique(d$model);stats <- list();correlations<-list();plotdata<-list()
for(reg in c('DLPFC','Caudate')) {
 meta <- read.csv(file.path(root,'inputs',paste0('Bulk_',reg,'_metadata.csv')),check.names=FALSE)
 meta$group <- factor(ifelse(meta$AN_case==1,'AN','Control'),levels=c('Control','AN'))
 meta$Sex <- factor(meta$Sex);meta$Race<-factor(meta$Race)
 for(model in models) {
  x <- d[d$brain_region==reg & d$model==model,]
  m <- meta[match(x$sample_id,meta$sample_id),];stopifnot(identical(m$sample_id,x$sample_id),nrow(m)==107)
  oo <- old[old$brain_region==reg,];oo<-oo[match(x$sample_id,oo$sample_id),]
  for(ct in cells) {
   dd <- m;dd$score<-as.numeric(scale(x[[ct]]))
   fit <- lm(score~group+Age+Sex+Race+RIN+Perc.Intronic+Perc.rRNA,data=dd)
   cf<-summary(fit)$coefficients['groupAN',];ci<-confint(fit,'groupAN')
   stats[[length(stats)+1]]<-data.frame(brain_region=reg,model=model,cell_type=ct,effect_SD=cf[1],SE=cf[2],P=cf[4],CI_low=ci[1],CI_high=ci[2],
       n_AN=sum(dd$group=='AN'),n_control=sum(dd$group=='Control'),zero_estimates=sum(x[[ct]]==0),residual_df=df.residual(fit))
   correlations[[length(correlations)+1]]<-data.frame(brain_region=reg,model=model,cell_type=ct,rho_with_BRETIGEA=cor(x[[ct]],oo[[code[ct]]],method='spearman'))
   plotdata[[length(plotdata)+1]]<-data.frame(brain_region=reg,sample_id=x$sample_id,donor_id=m$donor_id,group=m$group,model=model,cell_type=ct,
       reference_contribution=x[[ct]],reference_Z=dd$score,BRETIGEA_score=oo[[code[ct]]])
  }
 }
}
stats<-do.call(rbind,stats)
stats$FDR_10_region_cell_tests<-ave(stats$P,stats$model,FUN=function(x)p.adjust(x,'BH'))
write.csv(stats,file.path(out,'Bulk_NNLS_group_comparisons.csv'),row.names=FALSE)
write.csv(do.call(rbind,correlations),file.path(out,'Bulk_NNLS_BRETIGEA_concordance.csv'),row.names=FALSE)
write.csv(do.call(rbind,plotdata),file.path(out,'Bulk_cell_estimates_plot_data.csv'),row.names=FALSE)
oldstats <- read.csv('./project/outputs/AN_functional_regulatory_20261013/Brain_cell_composition_group_comparisons.csv')
oldstats <- oldstats[oldstats$cell_type%in%cells,]
oldstats$method <- 'BRETIGEA';oldstats$q<-oldstats$FDR_12_brain_cell_tests
nn<-stats[stats$model=='50_markers_per_type',];nn$method<-'Single-nucleus reference NNLS';nn$q<-nn$FDR_10_region_cell_tests
fields<-c('brain_region','cell_type','method','effect_SD','CI_low','CI_high','P','q')
write.csv(rbind(oldstats[,fields],nn[,fields]),file.path(out,'Bulk_method_comparison_plot_data.csv'),row.names=FALSE)
capture.output(sessionInfo(),file=file.path(out,'R_sessionInfo.txt'))
print(stats[,c('brain_region','model','cell_type','effect_SD','P','FDR_10_region_cell_tests')])
