.libPaths(unique(c('./project/R/win-library/4.4',.libPaths())))
suppressPackageStartupMessages({library(edgeR);library(data.table)})
root <- './project/Workspaces/AN_singlecell_spatial_validation_20261015'
dir.create(file.path(root,'inputs'),recursive=TRUE,showWarnings=FALSE)
meta <- fread('./project/outputs/GSE262138_AN_sample_mapping_20261013/GSE262138_AN_and_controls_verified_mapping.csv',data.table=FALSE)
rc <- fread('./project/Workspaces/AN_diet_transcriptome_20261013/raw/GSE262138_Raw_count_data.txt',data.table=FALSE)
counts <- rowsum(as.matrix(rc[,-1]),sub('\\..*$','',rc[[1]]),reorder=FALSE)
ann <- fread('./project/Workspaces/AN_functional_regulatory_20261013/raw/human_gene_annotation.tsv',data.table=FALSE)
colnames(ann) <- c('gene_id','symbol','gene_type','entrez');ann<-unique(ann[,1:3])
stopifnot(!anyDuplicated(ann$gene_id))
for(reg in c('DLPFC','Caudate')) {
 m <- meta[meta$brain_region==reg,]
 keep <- fread(paste0('./project/Workspaces/AN_diet_transcriptome_20261013/results/AN_vs_control_',reg,'_primary.csv'))$gene_id
 y <- calcNormFactors(DGEList(counts[keep,m$sample_id]))
 x <- cpm(y,log=FALSE)
 symbols <- ann$symbol[match(rownames(x),ann$gene_id)]
 ok <- !is.na(symbols)&nzchar(symbols)
 x <- rowsum(x[ok,],symbols[ok],reorder=FALSE)
 fwrite(data.frame(gene=rownames(x),x,check.names=FALSE),file.path(root,'inputs',paste0('Bulk_',reg,'_linear_CPM.csv.gz')))
 fwrite(m,file.path(root,'inputs',paste0('Bulk_',reg,'_metadata.csv')))
 cat(reg,dim(x),'\n')
}
