from pathlib import Path
import json,hashlib,shutil,sys
import numpy as np,pandas as pd
from scipy.stats import false_discovery_control,spearmanr
root=Path('./project/Workspaces/AN_singlecell_spatial_validation_20261015');r=root/'results'
dest=Path('./project/outputs/AN_singlecell_spatial_validation_20261015');dest.mkdir(parents=True,exist_ok=True)
checks={}
for name in ['Bulk_NNLS_group_comparisons.csv','Bisque_group_comparisons.csv']:
 d=pd.read_csv(r/name)
 for model,x in d.groupby('model'):
  assert len(x)==10
  err=np.max(abs(false_discovery_control(x.P.to_numpy())-x.FDR_10_region_cell_tests.to_numpy()))
  assert err<1e-12;checks[name+'_'+model]=dict(n_tests=len(x),BH_max_error=float(err),significant_FDR05=int((x.FDR_10_region_cell_tests<.05).sum()))
nodes=pd.read_csv(r/'Reference_nuclei_counts_by_donor.csv');dots=pd.read_csv(r/'Candidate67_single_nucleus_celltype_expression.csv')
assert len(dots)==670 and dots.present_in_reference.all()
markers=pd.read_csv(r/'Reference_marker_selection.csv')
u=pd.read_csv('./project/outputs/AN_TWAS_HFD_union_20261013/Union_candidates_all_evidence.csv')
ex=set(u.gene_name.dropna())|set(u.human_gene_name.dropna());assert not(set(markers.gene)&ex)
assert not markers.gene.str.startswith(('MT-','RPL','RPS')).any()
qc=pd.read_csv(r/'Spatial_localization_QC.csv');assert len(qc)==31
assert int(qc[qc.brain_region=='DLPFC'].n_spots.sum())==113927
assert int(qc[qc.brain_region=='Caudate'].n_spots.sum())==10891
spatial=pd.read_csv(r/'Spatial_reference_contributions_and_selected_genes.csv.gz',low_memory=False)
assert len(spatial)==124818 and not spatial.duplicated(['sample_id','spatial_unit']).any()
ct=['Astrocytes','Microglia','Neurons','Oligodendrocytes','OPCs']
assigned=spatial.reference_assigned
assert np.max(abs(spatial.loc[assigned,ct].sum(axis=1)-1))<1e-8
assert spatial.loc[~assigned,ct].isna().all().all()
bulk=pd.read_csv(r/'Bulk_reference_NNLS_contributions.csv');assert len(bulk)==428
assert np.max(abs(bulk[ct].sum(axis=1)-1))<1e-8
bi=pd.read_csv(r/'Bisque_group_comparisons.csv');nn=pd.read_csv(r/'Bulk_NNLS_group_comparisons.csv')
cv=pd.read_csv(r/'Leave_one_donor_out_synthetic_mixtures.csv')
cv['absolute_error']=abs(cv.true_weight-cv.estimated_weight)
cvs=cv.groupby(['brain_region','cell_type']).absolute_error.agg(['mean','median','max']).reset_index()
cvs.to_csv(r/'Synthetic_mixture_recovery_summary.csv',index=False)
author=pd.read_csv(r/'DLPFC_concordance_with_author_cell2location.csv')
authors=author.groupby('cell_type').rho.agg(['min','median','max']).reset_index()
authors.to_csv(r/'Spatial_author_concordance_summary.csv',index=False)
checks.update(candidate_genes=67,reference_region_gene_cell_records=len(dots),spatial_sections=31,spatial_units=len(spatial),markers_exclude_prior_candidate84=True)
(root/'audit/numerical_validation.json').write_text(json.dumps(checks,indent=2),encoding='utf8')
def fmt(x):return f'{x:.3g}'
lines=['# 单核参考检验与空间转录组整合',
'', '**主要结论：完成细胞类型定位，但未独立验证 AN 中胶质细胞减少。新参考方法的组间比较均未通过多重校正；OPCs 对方法敏感。空间参考投射存在明显平台/稀疏性误差，不能作为定量细胞比例验证。**',
'', '## 1. 数据和范围',
'', '- Siletti 等成人健康脑单核图谱：BA46（中额回）31,065 个细胞核；尾状核体部32,678 个。两个子集均来自同3位正常男性供者。不是AN病例单核数据。',
'- 保留具有明确细胞标签和每位供者至少20个细胞核的五类：神经元、星形胶质细胞、小胶质细胞、少突胶质细胞、OPCs。排除Splatter/Miscellaneous模糊标签；血管等稀少类型不做独立参考估计。最终分别使用30,932和29,999个细胞核。',
'- BA46可支持DLPFC定位；尾状核体部不是整个尾状核，更不能直接代表尾状核所有亚区。3名健康男性供者参考不能取代包含女性的AN病例验证。',
'- 原有bulk：每区22 AN、85对照；空间：30张正常DLPFC切片、10位供者、113,927 spots；正常尾状核BG14单供者、10,891个64μm聚合单位。两种空间技术不能直接比较单位表达或空间分辨率。',
'', '## 2. 候选基因的细胞定位',
'', '全部67个预先定义候选mRNA在参考基因列表中存在。每个基因的表达量及检出率先按供者和细胞类别计算，再对3位供者等权平均。气泡大小是检出率，颜色是每个基因在五类细胞间的表达Z值；不表示疾病差异或富集显著性。',
'', '| 脑区 | 基因 | 神经元检出率 | 小胶质细胞检出率 |', '|---|---|---:|---:|']
for reg in ['DLPFC','Caudate']:
 for gene in ['SNX27','MYO5A','WDR6','CLIC1']:
  a=dots[(dots.brain_region==reg)&(dots.gene_name==gene)].set_index('cell_type')
  lines.append(f'|{reg}|{gene}|{a.loc["Neurons","detection_fraction"]*100:.1f}%|{a.loc["Microglia","detection_fraction"]*100:.1f}%|')
lines+=['','SNX27跨多类细胞表达，神经元检出率较高，不能称为神经元特异。CLIC1在小胶质细胞中相对较高，但检出率只有约6%，不适宜据此宣称强而普遍的细胞特异表达。单核RNA的低检出/未检出不等于绝对不表达。',
'', '## 3. 参考解卷积与原BRETIGEA结果比较',
'', '直接NNLS：先计算每位供者、每细胞类型的全库CPM平均值，再进行供者等权；每类从参考中选50个特异标记，100个作敏感性。候选84、MT和核糖体标记排除，避免候选表达与其自身参与的参考构建直接循环。',
'', '直接投射的拟合相对残差较高，bulk中位数约0.78–0.89，空间约0.85–0.97，不能将其权重当成校准细胞比例。随后增加BisqueRNA 1.0.5作为跨平台敏感性检验：use.overlap=FALSE、old.cpm=FALSE，先全库CPM归一化再截取标记。500个标记的原始计数加未入选基因的总计数行以精确保留原库大小，该总计数行不参与拟合。按官方算法使用全部已标注参考核的均值和供者组成，不宣称其参考是供者等权。',
'', '全部组间模型调整年龄、性别、种族、RIN、intronic/rRNA read fractions；每个方法/标记模型的10个脑区×细胞比较统一BH。没有按结果显著性选方法；所有模型均完整保留。',
'', '| 脑区 | 细胞 | Bisque效应（SD） | P | FDR（10项） |', '|---|---|---:|---:|---:|']
for row in bi[bi.model=='50_markers_per_type'].itertuples():
 lines.append(f'|{row.brain_region}|{row.cell_type}|{row.effect_SD:.3f}|{row.P:.3f}|{row.FDR_10_region_cell_tests:.3f}|')
lines+=['', 'DLPFC小胶质细胞、少突胶质细胞在新参考方法中仍多为负向，但未达校正后显著。OPCs：原BRETIGEA负向；直接NNLS正向；Bisque50标记接近零的负向，100标记接近零的正向。因此OPCs减少不稳定。不能将这些结果写成独立单细胞验证了三类胶质细胞减少。',
'', '## 4. 空间整合',
'', '完成全部31张切片的参考投射与67候选基因的直接表达定位。代表性DLPFC保持此前预设Br2743_mid，不按新信号挑图；尾状核为唯一BG14切片。空间表达CSV保留所有单位和候选基因，空间域汇总保留全部切片。',
'', '| 细胞 | DLPFC 30切片与作者cell2location的相关中位数 |', '|---|---:|']
for row in authors.itertuples():lines.append(f'|{row.cell_type}|{row.median:.3f}|')
lines+=['', '少突胶质细胞和神经元映射表现优于星形胶质细胞；后者相关中位数接近零甚至负向，提示直接单核参考投射不能作为可靠定量验证。空间图前三个面板是探索性贡献权重，后三个是直接观测基因表达，二者必须在图注中区分。',
'', '453个空间单位没有入选参考标记的信号，细胞贡献标记为NA，不作为细胞缺失的零值；所有单位及其直接测量的候选基因表达均保留。空间参考与单核参考没有AN病例分组，不能用来重复AN病例—对照的疾病效应。细胞/基因在正常组织的空间共现也不能证明ceRNA竞争、细胞间相互作用或HFD保护作用。',
'', '## 5. 验证、代码与交付',
'', '留一参考供者的合成线性混合物误差较小，但这是理想线性混合物的校准检查，不是实际bulk跨平台性能验证。公开健康供者细胞丰度也不等同于真实组织细胞计数。',
'', '数值核验：所有BH重新计算一致；自写5变量NNLS与scipy.optimize.nnls最大差2.8e-16；全部候选和空间单位数量核验；病例供者是统计单位，不将细胞核、spot当独立病例重复。',
'', '数据出处：',
'- Siletti官方数据与代码：https://github.com/linnarsson-lab/adult-human-brain',
'- CELLxGENE集合：https://cellxgene.cziscience.com/collections/283d65eb-dd53-496d-adb7-7570c7caa443',
'- Bisque论文：https://doi.org/10.1038/s41467-020-15816-6',
'- Bisque官方代码：https://github.com/cozygene/bisque',
'', '完整原始H5AD与标记计数保存在D盘工作区，交付目录保留结果CSV、图、代码、来源元数据和校验记录。']
(dest/'Analysis_report_CN.md').write_text('\n'.join(lines),encoding='utf8')
(dest/'Methods_EN.txt').write_text('Cell-type localization was examined using publicly available single-nucleus RNA-seq data from healthy adult BA46 and caudate body (Siletti et al.). Donor-level expression and detection fractions were summarized across five adequately represented cell classes. All 67 predefined candidate genes were assessed. Reference markers excluded the previous 84 candidate genes, mitochondrial and ribosomal genes. Reference-based decomposition of the existing AN and control bulk samples was evaluated using direct NNLS and BisqueRNA (use.overlap = FALSE), with 50 markers per class and a 100-marker sensitivity analysis. Covariate-adjusted AN-control comparisons were corrected across ten region-cell tests within each method and marker model. Candidate expression and exploratory reference projections were mapped to all 30 existing normal DLPFC sections and one normal caudate section; DLPFC projections were compared with author-provided cell2location estimates. These analyses provide cellular and spatial context rather than independent case-control validation.\n',encoding='utf8')
(dest/'Results_EN.txt').write_text('Healthy-brain single-nucleus data provided cell-type expression profiles for all 67 candidate genes. SNX27 was detected across multiple cell classes, with higher detection frequencies in neurons, supporting cellular localization rather than cell-type specificity. Reference-based decomposition did not independently substantiate the inferred reductions in glial populations: none of the five-cell-class comparisons in either region remained significant after multiple-testing correction using direct NNLS or BisqueRNA. OPC estimates were particularly sensitive to the method and marker set. Spatial expression maps provided additional anatomical context, but reference-projection fit and agreement with existing cell2location estimates varied across cell classes. Accordingly, these results were interpreted as exploratory cellular and spatial localization, without evidence for replicated AN-associated cell loss.\n',encoding='utf8')
(dest/'Figure_legends_EN.txt').write_text('Single-nucleus cellular localization and reference-based sensitivity analyses. UMAP panels retain all 31,065 BA46 and 32,678 caudate-body nuclei from three normal male donors; grey denotes excluded ambiguous or rare classes. Candidate-gene dot plots summarize donor-balanced mean CPM and detection fractions for five adequately represented cell classes. Dot area reflects the fraction of nuclei with detected expression; color denotes within-gene, within-region Z-scored log1p mean CPM. The compact panel displays twelve prespecified manuscript-related genes, with all 67 candidates provided separately. These data represent normal-brain localization, not AN-control differential expression.\n\nBulk decomposition method comparison. Points and lines indicate covariate-adjusted AN-control differences in SD units and 95% confidence intervals from 22 AN cases and 85 controls per region. BRETIGEA scores, direct single-nucleus-reference NNLS contributions and BisqueRNA estimates are displayed separately; no absolute cell-number interpretation is intended. Reference models use fifty markers per class, with one hundred assessed separately. Models adjust for age, sex, race, RIN and intronic/rRNA read fractions. No group comparison is significant after BH correction within the relevant region-cell testing family. All methods use the same bulk donors and therefore do not constitute independent disease-cohort replication.\n\nSpatial cellular and gene localization. Representative normal DLPFC section Br2743_mid and the available normal caudate BG14 section are shown separately. Upper panels depict exploratory direct NNLS reference contributions for microglia, oligodendrocytes and OPCs; these projections have substantial platform-related fit error and are not calibrated cell proportions. Lower panels display measured SNX27, MYO5A and CLIC1 expression as log1p counts per 10,000 total counts. Every retained spatial unit is shown; units without selected-marker signal have missing contribution estimates, not biological zero values. Gene maps share gene-specific color limits across the two illustrated sections. DLPFC Visium spots and caudate 64-um aggregates differ in technology and sampling. Complete results cover 30 DLPFC sections from ten donors and one caudate section from one donor. Spatial concordance with author-provided cell2location estimates is descriptive; sections from the same donor are not independent subjects.\n',encoding='utf8')
for p in r.iterdir():
 if p.is_file():shutil.copy2(p,dest/p.name)
# Keep the complete per-section gene matrices, without duplicate raw H5AD downloads.
shutil.copytree(r/'spatial_candidate_expression',dest/'spatial_candidate_expression',dirs_exist_ok=True)
shutil.copytree(root/'audit',dest/'audit',dirs_exist_ok=True)
scripts=['fetch_siletti_regions.py','export_singlecell_bulk_inputs.R','analyze_singlecell_spatial.py','fit_singlecell_bulk_models.R','export_bisque_markers.py','run_bisque_validation.R','plot_singlecell_spatial_validation.R','repair_spatial_unassigned.py','finalize_singlecell_spatial_validation.py']
(dest/'scripts').mkdir(exist_ok=True)
for filename in scripts:
 p=Path('./author_inputs/REQUIRED_LOCAL_INPUT')/filename
 shutil.copy2(p,dest/'scripts'/filename);shutil.copy2(p,root/'scripts'/filename)
status=dict(complete=True,independent_AN_singlecell_cohort=False,reference_regions=2,reference_donors=3,candidate_genes=67,spatial_sections=31,spatial_units=124818,
 no_FDR_significant_group_differences=True,platform_projection_limitations_disclosed=True)
(dest/'analysis_status.json').write_text(json.dumps(status,indent=2),encoding='utf8')
manifest=[]
for p in dest.rglob('*'):
 if p.is_file() and p.name!='output_manifest.csv':
  h=hashlib.sha256(p.read_bytes()).hexdigest();manifest.append(dict(file=p.relative_to(dest).as_posix(),bytes=p.stat().st_size,sha256=h))
pd.DataFrame(manifest).to_csv(dest/'output_manifest.csv',index=False)
print('Validated and packaged',len(manifest),'files',dest,flush=True)
